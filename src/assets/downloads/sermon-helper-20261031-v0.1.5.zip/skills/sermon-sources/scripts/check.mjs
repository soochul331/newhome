#!/usr/bin/env node
// sermon-sources 확인 도구 — Node 18 이상, 다른 패키지 없음.
//
//   node check.mjs span <url> "<인용 구절>"        원문을 다시 받아 구절이 글자 그대로 있는지 (found / not-found / unreachable)
//   node check.mjs add <설교폴더> --url U --quote Q --claim doctrine|fact|history|language|illustration
//                      [--site S] [--author A] [--published D] [--quoted-from W] [--note N]
//                                                  확인한 결과를 sources.json에 웹 출처로 더한다 (상태·교리 등급은 이 도구가 정한다)
//                                                  X(합동 총회 이단 결의) 출처는 종료 코드 2로 거부, doctrine 주장에 R이 아니면 거부
//   node check.mjs bible <설교폴더> <책> <장> <절> [끝절] [--wording ai-recall|user-paste|none]
//                                                  성경 구절 출처를 더한다 (대한성서공회 읽기 링크, version=GAE)
//   node check.mjs link <책> <장> [절]              읽기 링크만 만든다
//   node check.mjs tier <url> [--author A]          사이트 등급 (A 믿을 만한 곳 / B 참고만)과 교리 등급 (R / E / N / X)
//   node check.mjs migrate <설교폴더> --claims w1=history,w2=doctrine,…
//                                                  예전 웹 출처에 교리 등급과 주장 종류를 적는다 (DOCTRINE.md)
//   node check.mjs stage <단계.json>                단계 파일의 모양·분량 검사
//   node check.mjs sermon <설교폴더> [--offline]    설교 폴더 전체 점검 (웹 출처를 모두 다시 받아 확인)
//                                                  주석 출처(kind commentary, sermon-commentary의 commentary.mjs add)는
//                                                  인용이 그 쪽의 뽑아 둔 글에 있는지 다시 확인 (.local/commentary, 서재 파일은 열지 않음)
//
// 원칙: 요약이 아니라 원문 바이트에서 찾는다. 구절은 300자 이하. 개역한글(version=HAN)은 거부한다.
//       교리·해석 주장은 개혁주의(R) 출처만, 이단·사이비(X)는 어디에도 쓰지 않는다 (DOCTRINE.md).

import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, readdirSync, realpathSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
export const BIBLE = JSON.parse(readFileSync(join(HERE, 'bible.json'), 'utf8'));
export const SITES = JSON.parse(readFileSync(join(HERE, 'sites.json'), 'utf8'));
export const AUTHORS = JSON.parse(readFileSync(join(HERE, 'authors.json'), 'utf8'));
export const BLOCK = JSON.parse(readFileSync(join(HERE, 'blocklist.json'), 'utf8'));
export const CLAIMS = ['doctrine', 'fact', 'history', 'language', 'illustration'];
export const DOCTRINE_CLASSES = ['R', 'E', 'N', 'X'];
/** What the page shows next to a footnote of this class. */
export const CLASS_LABEL = { E: '비개혁주의 자료', N: '비기독교 자료' };
export const QUOTE_MAX = 300;
export const MIN_READABLE_CHARS = 200;
const READER = BIBLE.reader;
const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 sermon-sources-check';

// ---------------------------------------------------------------- text
const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', middot: '·', hellip: '…', ldquo: '“', rdquo: '”', lsquo: '‘', rsquo: '’', ndash: '–', mdash: '—', laquo: '«', raquo: '»', bull: '•', copy: '©', reg: '®', trade: '™', shy: '' };
export function decodeEntities(s) {
  return s.replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
    if (e[0] === '#') {
      const n = e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
      try { return String.fromCodePoint(n); } catch { return m; }
    }
    return ENTITIES[e.toLowerCase()] ?? m;
  });
}

/** Visible text of an HTML page: scripts, styles and markup removed. */
export function htmlToText(html) {
  return decodeEntities(
    html
      .replace(/<!--[\s\S]*?-->/g, ' ')
      .replace(/<(script|style|noscript|template|svg|head)\b[\s\S]*?<\/\1\s*>/gi, ' ')
      .replace(/<br\s*\/?>/gi, '\n')
      // block-level tags break text; inline tags (b, i, a, span, em, strong, sup …) vanish without a space, as a browser renders them
      .replace(/<\/?(p|div|li|ul|ol|dl|dt|dd|h[1-6]|tr|td|th|table|thead|tbody|blockquote|section|article|header|footer|nav|aside|main|figure|figcaption|pre|hr|form|option|select)\b[^>]*>/gi, '\n')
      .replace(/<[^>]+>/g, ''),
  );
}

/** The ONLY normalisation applied before comparing (both sides): NFC, quote marks unified, whitespace collapsed. */
export function norm(s) {
  return s
    .normalize('NFC')
    .replace(/[‘’‚‛′`´]/g, "'")
    .replace(/[“”„‟″「」『』]/g, '"')
    .replace(/[  -​　\s]+/g, ' ')
    .trim();
}

export function quoteLength(q) {
  return [...norm(q)].length;
}

function titleOf(html) {
  const og = html.match(/<meta[^>]+property=["']og:title["'][^>]*content=["']([^"']+)["']/i) ?? html.match(/<meta[^>]+content=["']([^"']+)["'][^>]*property=["']og:title["']/i);
  const t = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return norm(decodeEntities((t?.[1] || og?.[1] || '').replace(/<[^>]+>/g, '')));
}

function charsetOf(contentType, bytes) {
  const fromHeader = /charset=([\w-]+)/i.exec(contentType ?? '')?.[1];
  if (fromHeader) return fromHeader;
  const head = new TextDecoder('latin1').decode(bytes.slice(0, 4096));
  return /<meta[^>]+charset=["']?([\w-]+)/i.exec(head)?.[1] ?? 'utf-8';
}

// ---------------------------------------------------------------- fetch
/** Fetch the raw bytes of a page (no summarising). Returns {ok, status, finalUrl, html, contentType, reason}. `fetchImpl` is for tests. */
export async function fetchRaw(url, { timeoutMs = 20000, fetchImpl = fetch } = {}) {
  let res;
  try {
    res = await fetchImpl(url, { redirect: 'follow', headers: { 'User-Agent': UA, 'Accept': 'text/html,application/xhtml+xml', 'Accept-Language': 'ko,en;q=0.8' }, signal: AbortSignal.timeout(timeoutMs) });
  } catch (e) {
    return { ok: false, status: 0, finalUrl: url, reason: `network: ${e?.cause?.code ?? e?.name ?? 'error'}` };
  }
  const contentType = res.headers.get('content-type') ?? '';
  const bytes = new Uint8Array(await res.arrayBuffer());
  if (!res.ok) return { ok: false, status: res.status, finalUrl: res.url || url, contentType, reason: `HTTP ${res.status}` };
  if (!/html|xml|text\/plain/i.test(contentType) && contentType) return { ok: false, status: res.status, finalUrl: res.url || url, contentType, reason: `not a web page (${contentType.split(';')[0]})` };
  let html;
  try { html = new TextDecoder(charsetOf(contentType, bytes)).decode(bytes); } catch { html = new TextDecoder('utf-8').decode(bytes); }
  return { ok: true, status: res.status, finalUrl: res.url || url, contentType, html };
}

/**
 * Re-fetch the page and look for the quote verbatim (after norm()).
 * found       — the quote is in the page's visible text
 * not-found   — the page was read, the quote is not in it
 * unreachable — the page could not be read as text (network, HTTP error, bot check, JS-only page, not HTML)
 */
export async function checkSpan(url, quote, opts = {}) {
  const checkedAt = new Date().toISOString();
  if (!quote || !norm(quote)) return { status: 'invalid', reason: 'empty quote', checkedAt };
  if (quoteLength(quote) > QUOTE_MAX) return { status: 'invalid', reason: `quote longer than ${QUOTE_MAX} chars (${quoteLength(quote)})`, checkedAt };
  if (hasHan(url)) return { status: 'invalid', reason: '개역한글(version=HAN) link rejected', checkedAt };
  const r = await fetchRaw(url, opts);
  if (!r.ok) return { status: 'unreachable', reason: r.reason, httpStatus: r.status, finalUrl: r.finalUrl, checkedAt };
  const text = norm(htmlToText(r.html));
  const title = titleOf(r.html);
  if ([...text].length < MIN_READABLE_CHARS) return { status: 'unreachable', reason: `no readable text without JavaScript (${[...text].length} chars)`, httpStatus: r.status, finalUrl: r.finalUrl, title, checkedAt };
  if (/just a moment|checking your browser|client challenge|attention required/i.test(title)) return { status: 'unreachable', reason: 'bot check page', httpStatus: r.status, finalUrl: r.finalUrl, title, checkedAt };
  const found = text.includes(norm(quote));
  return { status: found ? 'found' : 'not-found', httpStatus: r.status, finalUrl: r.finalUrl, title, checkedAt };
}

// ---------------------------------------------------------------- sites
function hostMatches(host, domain) {
  return host === domain || host.endsWith('.' + domain);
}
/** Site-list entry for a URL: the most specific listed domain wins. {domain, tier, doctrine, group, note} or null. */
export function siteOf(url) {
  let host;
  try { host = new URL(url).hostname.toLowerCase(); } catch { return null; }
  let best = null;
  for (const [domain, e] of Object.entries(SITES.domains)) if (hostMatches(host, domain) && (!best || domain.length > best.domain.length)) best = { domain, ...e };
  return best;
}
/** Tier of a URL: {tier:'A'|'B', group}. Unlisted sites are B. */
export function tierOf(url) {
  try { new URL(url); } catch { return { tier: 'B', group: 'invalid-url' }; }
  const s = siteOf(url);
  return s ? { tier: s.tier, group: s.group } : { tier: 'B', group: 'unlisted' };
}

// ---------------------------------------------------------------- doctrine (DOCTRINE.md §2)
const lower = (v) => norm(String(v ?? '')).toLowerCase();
/** Does a free-text name (author, site) name this alias? Exact for short one-word aliases, contained otherwise. */
function names(text, alias) {
  const t = lower(text);
  const a = lower(alias);
  if (!t || !a) return false;
  if (t === a) return true;
  const multiWord = /\s/.test(a) || /[^\x00-\x7f]/.test(a);
  if (!multiWord || [...a].length < 3) return false;
  // contained, but not as the front of a longer word: "통일교" names "통일교 한국협회", not "통일교육원"
  for (let i = t.indexOf(a); i >= 0; i = t.indexOf(a, i + 1)) if (!/[\p{L}\p{N}]/u.test(t[i + a.length] ?? '')) return true;
  return false;
}
/** Blocklist entries (level block = X, caution) named by an author or site field, or listed by domain. */
export function blockMatches({ url, author, site } = {}) {
  const out = [];
  let host = '';
  try { host = new URL(url).hostname.toLowerCase(); } catch {}
  for (const d of BLOCK.domains ?? []) if (host && hostMatches(host, d.domain ?? d)) out.push({ name: d.name ?? d.domain ?? d, level: 'block', via: 'domain' });
  for (const e of BLOCK.entries) {
    const all = [e.name.replace(/\(.*\)/, '').trim(), e.name, ...e.aliases];
    for (const [field, v] of [['author', author], ['site', site]])
      if (v && all.some((a) => names(v, a))) { out.push({ name: e.name, level: e.level, via: field, page: e.page }); break; }
  }
  return out;
}
export function authorOf(name, url) {
  for (const a of AUTHORS.authors) if (name && [a.name, ...a.aliases].some((x) => names(name, x))) return a;
  if (!name) for (const a of AUTHORS.authors) if ((a.urlPatterns ?? []).some((p) => new RegExp(p).test(url))) return a;
  return null;
}
/**
 * Doctrine class of a source (DOCTRINE.md §2): blocklist → X; authors.json; sites.json; unlisted → E.
 * A multi-author host with an unknown author is E at best (never R).
 */
export function classOf({ url, author = null, site = null } = {}) {
  const blocked = blockMatches({ url, author, site }).filter((b) => b.level === 'block');
  if (blocked.length) return { doctrine: 'X', by: 'blocklist', detail: blocked.map((b) => `${b.name} (${b.via})`).join(', ') };
  const s = siteOf(url);
  if (s?.doctrine === 'X') return { doctrine: 'X', by: 'site', detail: s.domain };
  const a = authorOf(author, url);
  if (a) return { doctrine: a.class, by: 'author', detail: a.name };
  if (s) {
    const multi = AUTHORS.hosts.some((h) => s.domain === h || s.domain.endsWith('.' + h));
    if (multi) return { doctrine: s.doctrine === 'R' ? 'E' : s.doctrine, by: 'host', detail: `${s.domain} (author unknown)` };
    return { doctrine: s.doctrine, by: 'site', detail: s.domain };
  }
  return { doctrine: 'E', by: 'default', detail: 'unlisted site' };
}
/** Is this class allowed to back this claim type? (DOCTRINE.md §3) */
export function claimAllowed(cls, claim) {
  if (cls === 'X') return false;
  if (claim === 'doctrine') return cls === 'R';
  if (claim === 'illustration') return cls === 'R' || cls === 'E';
  return CLAIMS.includes(claim);
}
export class RefusedError extends Error {
  constructor(message, code) { super(message); this.code = code; }
}
/** Cult-signature phrases (DOCTRINE.md §6) in a text: [{id, label, match}]. */
export function signatureHits(text) {
  const out = [];
  for (const s of BLOCK.signatures ?? []) for (const p of s.patterns) {
    const m = new RegExp(p).exec(String(text));
    if (m) { out.push({ id: s.id, label: s.label, match: m[0] }); break; }
  }
  return out;
}

// ---------------------------------------------------------------- bible
export function hasHan(s) {
  return /version=HAN\b/i.test(s) || /개역\s*한글/.test(s);
}
export function findBook(q) {
  const k = String(q).trim().toLowerCase();
  return BIBLE.books.find((b) => b.code === k || b.name === q.trim() || b.abbrevs.includes(q.trim()) || String(b.id) === k);
}
export function readerLink(book, chap, verse) {
  const q = new URLSearchParams({ version: 'GAE', book: book.code });
  if (chap) q.set('chap', String(chap));
  if (chap && verse) q.set('sec', String(verse));
  return `${READER}?${q.toString()}`;
}
/** Address exists in the verse-count index (KJV versification; see bible.json note). */
export function addressOk(book, chap, v1, v2) {
  const n = book?.chapters?.[chap - 1];
  if (!n) return false;
  if (!(v1 >= 1 && v1 <= n)) return false;
  if (v2 != null && !(v2 >= v1 && v2 <= n)) return false;
  return true;
}
export function bibleLabel(book, chap, v1, v2) {
  return `${book.name} ${chap}:${v1}${v2 && v2 !== v1 ? `-${v2}` : ''}`;
}

// ---------------------------------------------------------------- commentary (owner's PDF library, skills/sermon-commentary)
// The catalog and extracted page text live outside git (.local/commentary, or $SERMON_COMMENTARY_HOME).
export function commentaryHome() {
  return process.env.SERMON_COMMENTARY_HOME || join(HERE, '..', '..', '..', '.local', 'commentary');
}
/**
 * Cache file of one extracted PDF, keyed by catalog key + size + mtime (a changed file gets a new cache).
 * variant: 'js' = text layer read by pdf.js (every OS, the current reader) · true / 'ocr' = text recognition ·
 * false = text layer read by macOS PDFKit (older caches, still read so earlier quotes keep verifying).
 */
export function commentaryCachePath(key, size, mtime, variant = false, home = commentaryHome()) {
  const h = createHash('sha1').update(`${key}\u0000${size}\u0000${mtime}`).digest('hex').slice(0, 16);
  const suffix = variant === 'js' ? '-js' : variant ? '-ocr' : '';
  return join(home, 'text', `${key}-${h}${suffix}.json`);
}
/** Text of one page of a catalog file from the cache (pdf.js text, older PDFKit text, then OCR); null when not extracted. */
export function commentaryPageText(key, page, { home = commentaryHome() } = {}) {
  const cp = join(home, 'catalog.json');
  if (!existsSync(cp)) return null;
  const e = JSON.parse(readFileSync(cp, 'utf8')).entries.find((x) => x.key === key);
  if (!e) return null;
  for (const variant of ['js', false, 'ocr']) {
    const f = commentaryCachePath(key, e.size, e.mtime, variant, home);
    if (!existsSync(f)) continue;
    const pg = JSON.parse(readFileSync(f, 'utf8')).pages.find((x) => x.page === page);
    if (pg && pg.text.replace(/\s/g, '').length) return pg.text;
  }
  return null;
}
/** Quote found in a page's text after normalisation: norm() plus line-end hyphenation joined; PDF text often breaks
 *  lines inside a Korean word, so a match with all whitespace removed also counts. */
export function quoteInPage(pageText, quote) {
  const prep = (t) => norm(String(t).normalize('NFC').replace(/\u00ad/g, '').replace(/(\p{L})-[ \t]*\r?\n[ \t]*(\p{L})/gu, '$1$2'));
  const a = prep(pageText), q = prep(quote);
  if (!q) return false;
  return a.includes(q) || a.replace(/\s/g, '').includes(q.replace(/\s/g, ''));
}

// ---------------------------------------------------------------- ledger
const MARK = /\[\^(w\d+|c\d+|b\d+|u\d+|\?|d\?)\]/g;
export const STAGE_FILES = ['exegesis.json', 'angles.json', 'outline.json', 'manuscript.json', 'illustration.json', 'application.json'];
export function emptyLedger(slug) {
  return { version: 1, sermon: slug, sources: [] };
}
function readLedger(dir) {
  const p = join(dir, 'sources.json');
  return existsSync(p) ? JSON.parse(readFileSync(p, 'utf8')) : emptyLedger(dir.split('/').filter(Boolean).at(-1));
}
function writeLedger(dir, ledger) {
  writeFileSync(join(dir, 'sources.json'), JSON.stringify(ledger, null, 2) + '\n');
}
function nextId(ledger, prefix) {
  const ns = ledger.sources.filter((s) => s.id.startsWith(prefix)).map((s) => Number(s.id.slice(1)));
  return `${prefix}${ns.length ? Math.max(...ns) + 1 : 1}`;
}
const kstDate = (iso) => new Date(new Date(iso).getTime() + 9 * 3600e3).toISOString().slice(0, 10);

function gate(url, o) {
  const c = classOf({ url, author: o.author ?? null, site: o.site ?? null });
  if (c.doctrine === 'X') throw new RefusedError(`refused: ${url} is X (합동 총회 이단·사이비 결의: ${c.detail}) — never use it as a source (DOCTRINE.md §5)`, 2);
  if (!claimAllowed(c.doctrine, o.claim)) throw new RefusedError(`refused: a ${o.claim} claim needs ${o.claim === 'doctrine' ? 'a Reformed (R)' : 'an R or E'} source; ${url} is ${c.doctrine} (${c.by}: ${c.detail}) (DOCTRINE.md §3)`, 3);
  return c;
}
export async function addWeb(dir, o, opts = {}) {
  if (!CLAIMS.includes(o.claim)) throw new Error(`--claim must be ${CLAIMS.join(' | ')} (DOCTRINE.md §3)`);
  gate(o.url, o);
  const ledger = readLedger(dir);
  const r = await checkSpan(o.url, o.quote, opts);
  if (r.status === 'invalid') throw new Error(r.reason);
  const c = gate(r.finalUrl ?? o.url, o); // a redirect may land somewhere else
  const t = tierOf(r.finalUrl ?? o.url);
  const src = {
    id: nextId(ledger, 'w'),
    kind: 'web',
    url: o.url,
    finalUrl: r.finalUrl ?? o.url,
    title: r.title || null,
    site: o.site ?? null,
    author: o.author ?? null,
    publishedAt: o.published ?? null,
    accessedAt: kstDate(r.checkedAt),
    quote: o.quote,
    ...(o.quotedFrom ? { quotedFrom: o.quotedFrom } : {}),
    tier: t.tier,
    tierGroup: t.group,
    doctrine: c.doctrine,
    doctrineBy: `${c.by}: ${c.detail}`,
    claim: o.claim,
    status: r.status,
    ...(r.reason ? { reason: r.reason } : {}),
    checkedAt: r.checkedAt,
    ...(o.note ? { note: o.note } : {}),
  };
  ledger.sources.push(src);
  writeLedger(dir, ledger);
  return src;
}

/** Give older web sources their doctrine class and claim type (claims: {w1: 'history', …}). Nothing is re-fetched. */
export function migrateLedger(dir, claims) {
  const ledger = readLedger(dir);
  const done = [];
  for (const s of ledger.sources.filter((x) => x.kind === 'web')) {
    const claim = claims[s.id] ?? s.claim;
    if (!CLAIMS.includes(claim)) throw new Error(`${s.id}: claim must be ${CLAIMS.join(' | ')}`);
    const c = classOf({ url: s.finalUrl ?? s.url, author: s.author, site: s.site });
    const old = { doctrine: s.doctrine ?? null, claim: s.claim ?? null };
    Object.assign(s, { doctrine: c.doctrine, doctrineBy: `${c.by}: ${c.detail}`, claim });
    done.push({ id: s.id, author: s.author, old, doctrine: c.doctrine, by: s.doctrineBy, claim, allowed: claimAllowed(c.doctrine, claim) });
  }
  writeLedger(dir, ledger);
  return done;
}

export function addBible(dir, bookQ, chap, v1, v2, wording = 'none') {
  const book = findBook(bookQ);
  if (!book) throw new Error(`unknown book: ${bookQ}`);
  if (!addressOk(book, chap, v1, v2)) throw new Error(`address not in the verse index: ${book.name} ${chap}:${v1}${v2 ? '-' + v2 : ''}`);
  if (!['ai-recall', 'user-paste', 'none'].includes(wording)) throw new Error(`wording must be ai-recall | user-paste | none`);
  const ledger = readLedger(dir);
  const label = bibleLabel(book, chap, v1, v2);
  const same = ledger.sources.find((s) => s.kind === 'bible' && s.label === label && s.wording === wording);
  if (same) return same;
  const src = { id: nextId(ledger, 'b'), kind: 'bible', bookId: book.id, chap, v1, ...(v2 && v2 !== v1 ? { v2 } : {}), label, readerUrl: readerLink(book, chap, v1), wording };
  ledger.sources.push(src);
  writeLedger(dir, ledger);
  return src;
}

// ---------------------------------------------------------------- stages
const isStr = (v) => typeof v === 'string';
function str(errs, path, v, { min = 0, max = Infinity, nullable = false } = {}) {
  if (v === null && nullable) return;
  if (!isStr(v)) return errs.push(`${path}: expected text`);
  const n = [...v.replace(MARK, '')].length;
  if (n < min) errs.push(`${path}: empty`);
  if (n > max) errs.push(`${path}: ${n} chars > ${max}`);
}
function arr(errs, path, v, min, max) {
  if (!Array.isArray(v)) return errs.push(`${path}: expected a list`) && false;
  if (v.length < min || v.length > max) errs.push(`${path}: ${v.length} items, expected ${min}-${max}`);
  return true;
}
function bool(errs, path, v) {
  if (typeof v !== 'boolean') errs.push(`${path}: expected true/false`);
}
function quoteList(errs, path, v, max) {
  if (!arr(errs, path, v, 0, max)) return;
  v.forEach((q, i) => {
    str(errs, `${path}[${i}].refText`, q?.refText, { min: 1, max: 40 });
    str(errs, `${path}[${i}].text`, q?.text, { min: 1, max: 300 });
    if (!['ai-recall', 'user-paste'].includes(q?.wording)) errs.push(`${path}[${i}].wording: ai-recall | user-paste`);
  });
}
export const STAGES = ['exegesis', 'angles', 'outline', 'manuscript', 'illustration', 'application'];
export const ILLUSTRATION_KINDS = ['story', 'statistic', 'quote', 'history'];
const FITS_AT = /^(intro|point[1-4]|development|climax|conclusion)$/;
/** 개요 in four parts, in this order (sermon-outline SKILL.md): kind + its Korean label. */
export const MOVEMENTS = [['intro', '도입'], ['development', '전개'], ['climax', '절정'], ['conclusion', '결말']];
const hasBible = (r) => isStr(r) && /\[\^b\d+\]/.test(r);
export const DOCTRINE_STAGES = ['exegesis', 'outline', 'manuscript', 'application'];
/** Names of the standards a doctrine item may cite (DOCTRINE.md §4). */
export const STANDARD = /^(WCF \d{1,2}\.\d{1,2}(-\d{1,2})?|대요리문답 \d{1,3}문|소요리문답 \d{1,3}문|사도신경|니케아 신경|칼케돈 신경|벨직 \d{1,2}조|하이델베르크 \d{1,3}문|도르트 \d장 \d{1,2}항)(; (WCF \d{1,2}\.\d{1,2}(-\d{1,2})?|대요리문답 \d{1,3}문|소요리문답 \d{1,3}문|사도신경|니케아 신경|칼케돈 신경|벨직 \d{1,2}조|하이델베르크 \d{1,3}문|도르트 \d장 \d{1,2}항))*$/;
function doctrineList(errs, warns, doc) {
  if (doc.doctrine == null) {
    if (DOCTRINE_STAGES.includes(doc.stage)) warns.push('doctrine: no 신앙고백 대조 list yet (DOCTRINE.md §4)');
    return;
  }
  if (!arr(errs, 'doctrine', doc.doctrine, 0, 12)) return;
  doc.doctrine.forEach((d, i) => {
    str(errs, `doctrine[${i}].assertion`, d?.assertion, { min: 1, max: 80 });
    if (d?.standard === null) str(errs, `doctrine[${i}].note`, d?.note, { min: 1, max: 160 });
    else {
      if (!isStr(d?.standard) || !STANDARD.test(d.standard)) errs.push(`doctrine[${i}].standard: e.g. "WCF 26.1", "소요리문답 36문", "사도신경" — or null with a note and [^d?] in the text`);
      str(errs, `doctrine[${i}].note`, d?.note ?? '', { max: 160 });
    }
  });
  if (doc.doctrine.some((d) => d?.standard === null) && !/\[\^d\?\]/.test(JSON.stringify({ ...doc, doctrine: undefined }))) errs.push('doctrine: an item without a standard needs a [^d?] (교리 확인 필요) marker on its sentence');
}
export const SECTION_CHARS_AT_25 = 1350;
export const sectionTarget = (minutes) => Math.round((SECTION_CHARS_AT_25 * minutes) / 25);

/** Shape and length checks ported from the web stack's zod schemas (api/src/ai/schemas.ts) and prompt targets. */
export function validateStage(doc) {
  const errs = [];
  const warns = [];
  const s = doc?.stage;
  if (s === 'exegesis') {
    for (const k of ['author', 'audience', 'genre', 'purpose', 'structure']) str(errs, `background.${k}`, doc.background?.[k], { min: 1 });
    str(errs, 'context', doc.context, { min: 1 });
    if (arr(errs, 'structure', doc.structure, 1, 8)) doc.structure.forEach((x, i) => { str(errs, `structure[${i}].range`, x?.range, { min: 1 }); str(errs, `structure[${i}].title`, x?.title, { min: 1 }); });
    if (arr(errs, 'verseNotes', doc.verseNotes, 1, 12)) doc.verseNotes.forEach((x, i) => { str(errs, `verseNotes[${i}].verse`, x?.verse, { min: 1 }); str(errs, `verseNotes[${i}].note`, x?.note, { min: 1 }); });
    if (arr(errs, 'themes', doc.themes, 1, 4)) doc.themes.forEach((x, i) => { str(errs, `themes[${i}].title`, x?.title, { min: 1 }); str(errs, `themes[${i}].body`, x?.body, { min: 1 }); });
    str(errs, 'todayLink', doc.todayLink, { min: 1 });
    str(errs, 'historyCulture', doc.historyCulture, { nullable: true });
    quoteList(errs, 'quotes', doc.quotes, 4);
    str(errs, 'meditationNote', doc.meditationNote, { nullable: true });
    const total = [...JSON.stringify({ ...doc, quotes: undefined }).replace(MARK, '')].length;
    if (total > 4000) warns.push(`exegesis is long (${total} chars of JSON); target about 1,800 Korean chars of prose`);
  } else if (s === 'angles') {
    if (arr(errs, 'angles', doc.angles, 3, 3))
      doc.angles.forEach((a, i) => {
        str(errs, `angles[${i}].title`, a?.title, { min: 1, max: 40 });
        str(errs, `angles[${i}].summary`, a?.summary, { min: 1, max: 160 });
        if (arr(errs, `angles[${i}].preview`, a?.preview, 2, 3)) a.preview.forEach((p, j) => str(errs, `angles[${i}].preview[${j}]`, p, { max: 40 }));
        bool(errs, `angles[${i}].fromMeditation`, a?.fromMeditation);
      });
    if (doc.chosen != null && !(Number.isInteger(doc.chosen) && doc.chosen >= 0 && doc.chosen <= 2)) errs.push('chosen: 0, 1, 2 or null');
  } else if (s === 'outline' && doc.movements !== undefined) {
    // one sentence on top (centralIdea) + exactly four parts: 도입 · 전개 · 절정 · 결말
    str(errs, 'centralIdea', doc.centralIdea, { min: 1, max: 100 });
    bool(errs, 'centralFromMeditation', doc.centralFromMeditation);
    for (const k of ['intro', 'points', 'conclusion']) if (doc[k] !== undefined) errs.push(`${k}: not used with movements (the four parts hold it)`);
    if (arr(errs, 'movements', doc.movements, 4, 4))
      doc.movements.forEach((m, i) => {
        const p = `movements[${i}]`;
        const [kind, label] = MOVEMENTS[i];
        if (m?.kind !== kind || m?.label !== label) errs.push(`${p}: kind "${kind}" with label "${label}" (order 도입 · 전개 · 절정 · 결말)`);
        str(errs, `${p}.heading`, m?.heading, { min: 1, max: 40 });
        str(errs, `${p}.serves`, m?.serves, { min: 1, max: 160 });
        str(errs, `${p}.verseRange`, m?.verseRange ?? '', { max: 30 });
        if (arr(errs, `${p}.subpoints`, m?.subpoints, 3, 5))
          m.subpoints.forEach((x, j) => {
            str(errs, `${p}.subpoints[${j}].text`, x?.text, { min: 1, max: 200 });
            if (arr(errs, `${p}.subpoints[${j}].refs`, x?.refs, 1, 3)) {
              x.refs.forEach((r, k) => str(errs, `${p}.subpoints[${j}].refs[${k}]`, r, { min: 1, max: 40 }));
              if (!x.refs.some(hasBible)) errs.push(`${p}.subpoints[${j}].refs: needs a bible source [^b…] (check.mjs bible)`);
            }
          });
        if (m?.crossRefs !== undefined && arr(errs, `${p}.crossRefs`, m.crossRefs, 0, 2))
          m.crossRefs.forEach((r, k) => { str(errs, `${p}.crossRefs[${k}]`, r, { min: 1, max: 40 }); if (!hasBible(r)) errs.push(`${p}.crossRefs[${k}]: needs a bible source [^b…]`); });
        str(errs, `${p}.background`, m?.background ?? null, { max: 300, nullable: true });
        str(errs, `${p}.illustrationIdea`, m?.illustrationIdea ?? null, { max: 200, nullable: true });
        // an idea for the preacher to replace, never a story told as fact: no web source on it
        if (isStr(m?.illustrationIdea) && /\[\^[wc]\d+\]/.test(m.illustrationIdea)) errs.push(`${p}.illustrationIdea: an idea carries no source; a sourced story belongs in illustration.json`);
        if (kind === 'conclusion') {
          if (arr(errs, `${p}.applications`, m?.applications, 1, 3)) m.applications.forEach((a, k) => str(errs, `${p}.applications[${k}]`, a, { min: 1, max: 200 }));
        } else if (m?.applications !== undefined) errs.push(`${p}.applications: only in 결말`);
        if (m?.fromMeditation !== undefined) bool(errs, `${p}.fromMeditation`, m.fromMeditation);
      });
  } else if (s === 'outline') {
    str(errs, 'centralIdea', doc.centralIdea, { min: 1, max: 100 });
    bool(errs, 'centralFromMeditation', doc.centralFromMeditation);
    str(errs, 'intro', doc.intro, { max: 240 });
    if (arr(errs, 'points', doc.points, 2, 4))
      doc.points.forEach((p, i) => {
        str(errs, `points[${i}].title`, p?.title, { min: 1, max: 40 });
        str(errs, `points[${i}].verseRange`, p?.verseRange, { max: 30 });
        if (arr(errs, `points[${i}].supportRefs`, p?.supportRefs, 0, 4)) p.supportRefs.forEach((r, j) => str(errs, `points[${i}].supportRefs[${j}]`, r, { max: 40 }));
        str(errs, `points[${i}].body`, p?.body, { max: 240 });
        bool(errs, `points[${i}].fromMeditation`, p?.fromMeditation);
      });
    str(errs, 'conclusion', doc.conclusion, { max: 240 });
  } else if (s === 'manuscript') {
    if (![15, 25, 35].includes(doc.lengthMinutes)) errs.push('lengthMinutes: 15, 25 or 35');
    // four parts (도입·전개·절정·결말) share the same sermon length as intro + 3 points + conclusion
    const fourParts = Array.isArray(doc.sections) && doc.sections.some((x) => x?.kind === 'development' || x?.kind === 'climax');
    const target = Math.round(sectionTarget(doc.lengthMinutes ?? 25) * (fourParts ? 5 / 4 : 1));
    if (arr(errs, 'sections', doc.sections, 3, 6))
      doc.sections.forEach((sec, i) => {
        if (!['intro', 'point', 'development', 'climax', 'conclusion'].includes(sec?.kind)) errs.push(`sections[${i}].kind: intro | point | conclusion (or intro | development | climax | conclusion for a four-part outline)`);
        str(errs, `sections[${i}].heading`, sec?.heading, { min: 1, max: 80 });
        if (arr(errs, `sections[${i}].paragraphs`, sec?.paragraphs, 1, 12)) sec.paragraphs.forEach((p, j) => str(errs, `sections[${i}].paragraphs[${j}]`, p, { min: 1, max: 600 }));
        quoteList(errs, `sections[${i}].quotes`, sec?.quotes ?? [], 4);
        const chars = [...(sec?.paragraphs ?? []).join('').replace(MARK, '').replace(/\s/g, '')].length;
        if (chars > Math.round(target * 1.2)) errs.push(`sections[${i}]: ${chars} chars > ${Math.round(target * 1.2)} (1.2 x ${target})`);
        if (chars < Math.round(target * 0.7)) warns.push(`sections[${i}]: ${chars} chars, short of ${target}`);
      });
  } else if (s === 'illustration') {
    if (arr(errs, 'illustrations', doc.illustrations, 1, 6))
      doc.illustrations.forEach((x, i) => {
        const p = `illustrations[${i}]`;
        if (!ILLUSTRATION_KINDS.includes(x?.kind)) errs.push(`${p}.kind: ${ILLUSTRATION_KINDS.join(' | ')}`);
        str(errs, `${p}.title`, x?.title, { min: 1, max: 40 });
        str(errs, `${p}.body`, x?.body, { min: 1, max: 400 });
        if (!FITS_AT.test(x?.fitsAt ?? '')) errs.push(`${p}.fitsAt: intro | point1..point4 | conclusion (four-part outline: intro | development | climax | conclusion)`);
        str(errs, `${p}.bridge`, x?.bridge, { min: 1, max: 160 });
        // no invented story presented as fact: every illustration carries a web source or 확인 필요
        const ids = isStr(x?.body) ? [...x.body.matchAll(MARK)].map((m) => m[1]) : [];
        if (!ids.some((id) => id === '?' || id[0] === 'w')) errs.push(`${p}.body: an illustration needs a web source [^w…] or [^?] (확인 필요)`);
        if (isStr(x?.bridge) && /\[\^w\d+\]/.test(x.bridge)) errs.push(`${p}.bridge: put sources on the body, not the bridge`);
      });
  } else if (s === 'application') {
    str(errs, 'audience', doc.audience, { min: 1, max: 20 });
    if (arr(errs, 'points', doc.points, 1, 4))
      doc.points.forEach((pt, i) => {
        const p = `points[${i}]`;
        if (!(Number.isInteger(pt?.pointIndex) && pt.pointIndex >= 0 && pt.pointIndex <= 3)) errs.push(`${p}.pointIndex: 0-3`);
        str(errs, `${p}.title`, pt?.title, { min: 1, max: 40 });
        if (arr(errs, `${p}.items`, pt?.items, 1, 3))
          pt.items.forEach((it, j) => {
            str(errs, `${p}.items[${j}].text`, it?.text, { min: 1, max: 200 });
            if (arr(errs, `${p}.items[${j}].refs`, it?.refs, 1, 3)) {
              it.refs.forEach((r, k) => str(errs, `${p}.items[${j}].refs[${k}]`, r, { min: 1, max: 40 }));
              // each application is tied to the passage: at least one bible marker
              if (!it.refs.some((r) => isStr(r) && /\[\^b\d+\]/.test(r))) errs.push(`${p}.items[${j}].refs: needs a bible source [^b…] (check.mjs bible)`);
            }
          });
      });
  } else {
    errs.push(`stage must be ${STAGES.join(' | ')} (got ${s})`);
  }
  if (STAGES.includes(s)) doctrineList(errs, warns, doc);
  // cult signatures: a hard stop for the owner's review, never a silent pass (DOCTRINE.md §6)
  for (const { path, text } of strings(doc)) for (const h of signatureHits(text)) errs.push(`doctrine-review: ${path} "${h.match}" (${h.label})`);
  return { errors: errs, warnings: warns };
}

// ---------------------------------------------------------------- whole sermon
function strings(v, path = '', out = []) {
  if (isStr(v)) out.push({ path, text: v });
  else if (Array.isArray(v)) v.forEach((x, i) => strings(x, `${path}[${i}]`, out));
  else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) strings(x, path ? `${path}.${k}` : k, out);
  return out;
}

/**
 * Full check of a sermon folder: stage files, every marker, every source.
 * A text with markers is a claim. Its status:
 *   sourced     — at least one marker to a found tier-A web source, a bible source or a user source, and no marker to a
 *                 web source that is not found
 *   reference   — only tier-B found web sources (참고) → must also carry [^?]
 *   unverified  — carries [^?] (확인 필요)
 * Errors: a marker to a web source that is not found without [^?]; a marker to a missing id; tier-B only without [^?];
 *         a quote over 300 chars; any 개역한글 / version=HAN; a bible source whose address or link is wrong; stage errors.
 */
export async function checkSermon(dir, { offline = false, ...opts } = {}) {
  const errors = [];
  const warnings = [];
  const ledger = JSON.parse(readFileSync(join(dir, 'sources.json'), 'utf8'));
  const byId = new Map(ledger.sources.map((s) => [s.id, s]));
  const files = readdirSync(dir).filter((f) => f.endsWith('.json')).sort();

  for (const f of files) {
    const raw = readFileSync(join(dir, f), 'utf8');
    if (hasHan(raw)) errors.push(`${f}: 개역한글 / version=HAN found`);
    // any X address anywhere in the folder's files (DOCTRINE.md §5)
    for (const u of new Set(raw.match(/https?:\/\/[^\s"'<>)\]]+/g) ?? [])) if (classOf({ url: u }).doctrine === 'X') errors.push(`${f}: X address ${u}`);
  }

  // sources
  const recheck = {};
  for (const s of ledger.sources) {
    if (s.kind === 'web') {
      for (const k of ['url', 'quote', 'accessedAt', 'status', 'tier']) if (s[k] == null || s[k] === '') errors.push(`${s.id}: missing ${k}`);
      if (s.status === 'found' && !s.title) errors.push(`${s.id}: found but no title recorded`);
      if (isStr(s.quote) && quoteLength(s.quote) > QUOTE_MAX) errors.push(`${s.id}: quote ${quoteLength(s.quote)} chars > ${QUOTE_MAX}`);
      const t = tierOf(s.finalUrl ?? s.url);
      if (t.tier !== s.tier) errors.push(`${s.id}: tier recorded ${s.tier}, site list says ${t.tier}`);
      // doctrine class and claim type (DOCTRINE.md §2-3)
      if (!DOCTRINE_CLASSES.includes(s.doctrine)) errors.push(`${s.id}: missing doctrine class (R/E/N/X) — run check.mjs migrate`);
      if (!CLAIMS.includes(s.claim)) errors.push(`${s.id}: missing claim (${CLAIMS.join(' | ')}) — run check.mjs migrate`);
      const c = classOf({ url: s.finalUrl ?? s.url, author: s.author, site: s.site });
      if (s.doctrine && c.doctrine !== s.doctrine) errors.push(`${s.id}: doctrine recorded ${s.doctrine}, lists say ${c.doctrine} (${c.by}: ${c.detail})`);
      for (const m of blockMatches({ url: s.finalUrl ?? s.url, author: s.author, site: s.site }).filter((x) => x.level === 'caution')) warnings.push(`${s.id}: ${m.name} is on the 합동 caution list (경계·조사 중) — owner review before publishing`);
      if (c.doctrine === 'X' || s.doctrine === 'X') errors.push(`${s.id}: X source (합동 총회 이단·사이비 결의: ${c.detail}) — remove it`);
      else if (!s.retired && CLAIMS.includes(s.claim) && !claimAllowed(c.doctrine, s.claim)) errors.push(`${s.id}: a ${s.claim} claim cannot rest on a ${c.doctrine} source (${c.by}: ${c.detail})`);
      if (!offline && s.status === 'found' && !s.retired) {
        const r = await checkSpan(s.finalUrl ?? s.url, s.quote, opts);
        recheck[s.id] = r.status;
        if (r.status !== 'found') errors.push(`${s.id}: recorded found, re-check says ${r.status}${r.reason ? ` (${r.reason})` : ''}`);
      }
    } else if (s.kind === 'bible') {
      const book = BIBLE.books.find((b) => b.id === s.bookId);
      if (!book) errors.push(`${s.id}: unknown bookId ${s.bookId}`);
      else {
        if (!addressOk(book, s.chap, s.v1, s.v2)) errors.push(`${s.id}: address ${s.label} not in the verse index`);
        if (s.readerUrl !== readerLink(book, s.chap, s.v1)) errors.push(`${s.id}: reader link must be ${readerLink(book, s.chap, s.v1)}`);
      }
    } else if (s.kind === 'commentary') {
      // owner's commentary library (skills/sermon-commentary): file = catalog key, never a path in published output
      for (const k of ['file', 'page', 'quote', 'title', 'status']) if (s[k] == null || s[k] === '') errors.push(`${s.id}: missing ${k}`);
      if (!Number.isInteger(s.page) || s.page < 1) errors.push(`${s.id}: page must be a page number`);
      if (isStr(s.file) && /[/\\]/.test(s.file)) errors.push(`${s.id}: file must be a catalog key, not a path`);
      if (isStr(s.quote) && quoteLength(s.quote) > QUOTE_MAX) errors.push(`${s.id}: quote ${quoteLength(s.quote)} chars > ${QUOTE_MAX}`);
      if (!DOCTRINE_CLASSES.includes(s.doctrine)) errors.push(`${s.id}: missing doctrine class (R/E/N/X)`);
      if (!CLAIMS.includes(s.claim)) errors.push(`${s.id}: missing claim (${CLAIMS.join(' | ')})`);
      const c = classOf({ author: s.author });
      if (s.doctrine && c.doctrine !== s.doctrine) errors.push(`${s.id}: doctrine recorded ${s.doctrine}, lists say ${c.doctrine} (${c.by}: ${c.detail})`);
      for (const m of blockMatches({ author: s.author, site: s.series }).filter((x) => x.level === 'caution')) warnings.push(`${s.id}: ${m.name} is on the 합동 caution list (경계·조사 중) — owner review before publishing`);
      if (c.doctrine === 'X' || s.doctrine === 'X') errors.push(`${s.id}: X source (합동 총회 이단·사이비 결의: ${c.detail}) — remove it`);
      else if (!s.retired && CLAIMS.includes(s.claim) && !claimAllowed(c.doctrine, s.claim)) errors.push(`${s.id}: a ${s.claim} claim cannot rest on a ${c.doctrine} source (${c.by}: ${c.detail})`);
      if (s.status === 'found' && !s.retired && isStr(s.file) && isStr(s.quote) && Number.isInteger(s.page)) {
        const text = commentaryPageText(s.file, s.page, opts.commentaryHome ? { home: opts.commentaryHome } : undefined);
        if (text == null) errors.push(`${s.id}: cannot verify — no extracted text for ${s.file} p.${s.page} (run commentary.mjs extract ${s.file})`);
        else if (!quoteInPage(text, s.quote)) errors.push(`${s.id}: quote not found on ${s.file} p.${s.page}`);
      }
    } else if (s.kind !== 'user') errors.push(`${s.id}: unknown kind ${s.kind}`);
  }

  // stages + claims
  const claims = { sourced: 0, reference: 0, unverified: 0 };
  const stageNames = [];
  const doctrineReview = [];
  const cited = new Set();
  const assertions = [];
  // stage files only (artifact.json, meta.json and page output live in the same folder)
  for (const f of files.filter((x) => STAGE_FILES.includes(x))) {
    const doc = JSON.parse(readFileSync(join(dir, f), 'utf8'));
    stageNames.push(doc.stage ?? f);
    const v = validateStage(doc);
    if (Array.isArray(doc.doctrine)) assertions.push(...doc.doctrine.map((d) => ({ stage: doc.stage, ...d })));
    errors.push(...v.errors.map((e) => `${f}: ${e}`));
    warnings.push(...v.warnings.map((e) => `${f}: ${e}`));
    for (const { path, text } of strings(doc)) {
      const ids = [...text.matchAll(MARK)].map((m) => m[1]);
      if (!ids.length) continue;
      const where = `${f}:${path}`;
      const marked = ids.includes('?');
      if (ids.includes('d?')) doctrineReview.push(where);
      const srcs = ids.filter((i) => i !== '?' && i !== 'd?').map((i) => {
        const s = byId.get(i);
        if (!s) errors.push(`${where}: marker [^${i}] has no source`);
        else if (s.retired) errors.push(`${where}: cites ${i}, retired (${s.retired.reason ?? 'replaced'}${s.retired.by ? ` by ${s.retired.by}` : ''})`);
        return s;
      }).filter(Boolean);
      for (const s of srcs) if ((s.kind === 'web' || s.kind === 'commentary') && !s.retired) cited.add(s.id);
      const badWeb = srcs.filter((s) => (s.kind === 'web' || s.kind === 'commentary') && s.status !== 'found');
      if (badWeb.length && !marked) errors.push(`${where}: cites ${badWeb.map((s) => `${s.id}(${s.status})`).join(', ')} without [^?]`);
      const strong = srcs.some((s) => (s.kind === 'web' && s.status === 'found' && s.tier === 'A') || (s.kind === 'commentary' && s.status === 'found') || s.kind === 'bible' || s.kind === 'user');
      const weakOnly = !strong && srcs.some((s) => s.kind === 'web' && s.status === 'found' && s.tier === 'B');
      if (marked) claims.unverified++;
      else if (!srcs.length) continue;
      else if (weakOnly) { claims.reference++; errors.push(`${where}: only tier-B (참고) sources — add a tier-A source or mark [^?]`); }
      else if (strong && !badWeb.length) claims.sourced++;
    }
  }

  // illustration / application against the outline (places and points must exist)
  const readStage = (f) => (existsSync(join(dir, f)) ? JSON.parse(readFileSync(join(dir, f), 'utf8')) : null);
  const outline = readStage('outline.json');
  const four = Array.isArray(outline?.movements);
  const nPoints = Array.isArray(outline?.points) ? outline.points.length : 0;
  const ill = readStage('illustration.json');
  const app = readStage('application.json');
  const ms = readStage('manuscript.json');
  if ((ill || app) && !outline) errors.push('illustration/application need outline.json first');
  if (ill && outline) (ill.illustrations ?? []).forEach((x, i) => {
    const m = /^point(\d)$/.exec(x?.fitsAt ?? '');
    if (four && m) errors.push(`illustration.json:illustrations[${i}].fitsAt: ${x.fitsAt} but the outline has four parts (intro | development | climax | conclusion)`);
    else if (!four && /^(development|climax)$/.test(x?.fitsAt ?? '')) errors.push(`illustration.json:illustrations[${i}].fitsAt: ${x.fitsAt} but the outline has points (intro | point1..point${nPoints} | conclusion)`);
    else if (m && Number(m[1]) > nPoints) errors.push(`illustration.json:illustrations[${i}].fitsAt: ${x.fitsAt} but the outline has ${nPoints} points`);
  });
  // a four-part outline: the manuscript follows the same four parts in order; applications sit in 결말 (and may sit elsewhere)
  if (ms && four) {
    const kinds = (ms.sections ?? []).map((x) => x?.kind).join(' ');
    if (kinds !== MOVEMENTS.map(([k]) => k).join(' ')) errors.push(`manuscript.json: sections must follow the outline's four parts in order (intro development climax conclusion), got ${kinds || 'none'}`);
  }
  if (app && four) {
    const idx = (app.points ?? []).map((p) => p?.pointIndex);
    if (!idx.includes(3)) errors.push('application.json: no application for 결말 (pointIndex 3)');
  } else if (app && outline) {
    const idx = (app.points ?? []).map((p) => p?.pointIndex);
    for (let i = 0; i < nPoints; i++) if (!idx.includes(i)) errors.push(`application.json: no application for outline point ${i + 1}`);
    idx.forEach((v, i) => { if (Number.isInteger(v) && v >= nPoints) errors.push(`application.json:points[${i}].pointIndex ${v} but the outline has ${nPoints} points`); });
  }
  const hangul = /[\uac00-\ud7a3]/;
  const illStats = ill ? (() => {
    const list = ill.illustrations ?? [];
    const ids = (x) => [...String(x?.body ?? '').matchAll(MARK)].map((m) => m[1]);
    const srcs = [...new Set(list.flatMap(ids).filter((i) => i[0] === 'w'))].map((i) => byId.get(i)).filter(Boolean);
    return {
      total: list.length,
      sourced: list.filter((x) => !ids(x).includes('?') && ids(x).some((i) => byId.get(i)?.status === 'found')).length,
      needsCheck: list.filter((x) => ids(x).includes('?')).length,
      webSources: srcs.length,
      found: srcs.filter((s) => s.status === 'found').length,
      tierA: srcs.filter((s) => s.tier === 'A' && s.status === 'found').length,
      korean: srcs.filter((s) => s.status === 'found' && hangul.test(s.quote ?? '')).length,
    };
  })() : null;
  const appStats = app ? {
    points: (app.points ?? []).length,
    items: (app.points ?? []).reduce((n, p) => n + (p?.items?.length ?? 0), 0),
    bibleRefs: new Set((app.points ?? []).flatMap((p) => (p?.items ?? []).flatMap((it) => (it?.refs ?? []).flatMap((r) => [...String(r).matchAll(MARK)].map((m) => m[1]))))).size,
  } : null;

  // retired sources (replaced, kept for the record) are not counted
  const allWeb = ledger.sources.filter((s) => s.kind === 'web');
  const web = allWeb.filter((s) => !s.retired);
  const live = web;
  const byClass = Object.fromEntries(DOCTRINE_CLASSES.map((k) => [k, live.filter((s) => s.doctrine === k).length]));
  const byClaim = Object.fromEntries(CLAIMS.map((k) => [k, live.filter((s) => s.claim === k).length]));
  const doctrineStats = {
    classes: byClass,
    claims: byClaim,
    doctrineClaimsNonR: live.filter((s) => s.claim === 'doctrine' && s.doctrine !== 'R').length,
    labeled: { E: live.filter((s) => s.doctrine === 'E' && cited.has(s.id)).length, N: live.filter((s) => s.doctrine === 'N' && cited.has(s.id)).length },
    retired: allWeb.filter((s) => s.retired).length,
    reviewMarkers: doctrineReview.length,
    signatureHits: errors.filter((e) => e.includes('doctrine-review:')).length,
    xSources: errors.filter((e) => / X (source|address)/.test(e)).length,
    assertions: assertions.length,
    unmatched: assertions.filter((d) => d.standard == null).length,
  };
  const count = (f) => web.filter(f).length;
  const stats = {
    sources: {
      web: web.length,
      found: count((s) => s.status === 'found'),
      notFound: count((s) => s.status === 'not-found'),
      unreachable: count((s) => s.status === 'unreachable'),
      unverified: count((s) => s.status === 'unverified'),
      tierA: count((s) => s.tier === 'A'),
      tierB: count((s) => s.tier === 'B'),
      tierAFound: count((s) => s.tier === 'A' && s.status === 'found'),
      bible: ledger.sources.filter((s) => s.kind === 'bible').length,
      user: ledger.sources.filter((s) => s.kind === 'user').length,
      ...(ledger.sources.some((s) => s.kind === 'commentary') ? { commentary: ledger.sources.filter((s) => s.kind === 'commentary' && !s.retired).length } : {}),
    },
    claims,
    doctrine: doctrineStats,
    ...(illStats ? { illustration: illStats } : {}),
    ...(appStats ? { application: appStats } : {}),
    stages: stageNames,
    recheck,
  };
  if (doctrineReview.length) warnings.push(`교리 확인 필요 [^d?] ${doctrineReview.length}: do not publish before the owner reviews (${doctrineReview.join(', ')})`);
  return { ok: errors.length === 0, errors, warnings, stats, doctrineReview, assertions };
}

// ---------------------------------------------------------------- CLI
function flags(args) {
  const out = { _: [] };
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const k = args[i].slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
      const next = args[i + 1];
      if (next == null || next.startsWith('--')) out[k] = true;
      else { out[k] = next; i++; }
    } else out._.push(args[i]);
  }
  return out;
}
const print = (o) => console.log(JSON.stringify(o, null, 2));

async function main(argv) {
  const [cmd, ...rest] = argv;
  const a = flags(rest);
  switch (cmd) {
    case 'span': {
      const r = await checkSpan(a._[0], a._[1]);
      print({ ...r, ...tierOf(r.finalUrl ?? a._[0]) });
      return r.status === 'found' ? 0 : 1;
    }
    case 'add': {
      const s = await addWeb(a._[0], { url: a.url, quote: a.quote, claim: a.claim, site: a.site, author: a.author, published: a.published, quotedFrom: a.quotedFrom, note: a.note });
      print(s);
      return s.status === 'found' ? 0 : 1;
    }
    case 'bible': {
      const [dir, book, chap, v1, v2] = a._;
      print(addBible(dir, book, Number(chap), Number(v1), v2 ? Number(v2) : undefined, a.wording ?? 'none'));
      return 0;
    }
    case 'link': {
      const book = findBook(a._[0]);
      if (!book) { console.error(`unknown book: ${a._[0]}`); return 2; }
      console.log(readerLink(book, Number(a._[1]) || undefined, Number(a._[2]) || undefined));
      return 0;
    }
    case 'tier':
      print({ ...tierOf(a._[0]), ...classOf({ url: a._[0], author: a.author ?? null, site: a.site ?? null }) });
      return 0;
    case 'migrate': {
      const claims = Object.fromEntries(String(a.claims ?? '').split(',').filter(Boolean).map((kv) => kv.split('=')));
      const r = migrateLedger(a._[0], claims);
      print(r);
      return r.every((x) => x.allowed) ? 0 : 1;
    }
    case 'stage': {
      const r = validateStage(JSON.parse(readFileSync(a._[0], 'utf8')));
      print(r);
      return r.errors.length ? 1 : 0;
    }
    case 'sermon': {
      const r = await checkSermon(a._[0], { offline: !!a.offline });
      print(r);
      return r.ok ? 0 : 1;
    }
    default:
      console.error('usage: check.mjs span|add|bible|link|tier|stage|sermon … (see the header of this file)');
      return 2;
  }
}

// Run as a command (not when imported by tests). Compare real paths: the skill folder may sit behind a symlink
// (e.g. /var -> /private/var on macOS, or a linked ~/.claude/skills folder).
const isMain = (() => {
  try { return !!process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url)); } catch { return false; }
})();
if (isMain) {
  main(process.argv.slice(2)).then((code) => process.exit(code), (e) => { console.error(String(e?.message ?? e)); process.exit(e?.code ?? 2); });
}
