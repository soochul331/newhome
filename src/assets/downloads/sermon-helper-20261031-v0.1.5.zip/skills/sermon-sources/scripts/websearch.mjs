// Web search for the 출처 확인 and the 시사 예화 (host tools web-search / web-read), on the owner's computer through
// NAVER API HUB (Naver Cloud Platform). The keys (NAVER_CLIENT_ID / NAVER_CLIENT_SECRET) are read here only: never
// printed, never sent to the page. Every result passes the site list and the blocklist (X dropped, never fetched);
// 개역한글(HAN) links are dropped. web-read reads only a URL this process returned (search results or built
// commentary URLs). At most one search call a second; answers and pages are kept in memory for 15 minutes.
import { readFileSync } from 'node:fs';
import { fetchRaw, htmlToText, decodeEntities, norm, quoteLength, QUOTE_MAX, MIN_READABLE_CHARS, classOf, tierOf, siteOf, hasHan, BLOCK } from './check.mjs';

export const SEARCH_BASE = 'https://naverapihub.apigw.ntruss.com/search/v1/';
export const SEARCH_KINDS = { news: 'news', web: 'webkr', blog: 'blog', encyc: 'encyc' };
export const SEARCH_TTL_MS = 15 * 60 * 1000;
export const READ_CHARS = 12000;

/** NAVER_CLIENT_ID / NAVER_CLIENT_SECRET from the environment or a .env.local file -> {id, secret} | null. */
export function loadKeys({ env = process.env, envFile } = {}) {
  const fromFile = {};
  if (envFile) {
    try {
      for (const line of readFileSync(envFile, 'utf8').split(/\r?\n/)) {
        const m = /^\s*(?:export\s+)?(NAVER_CLIENT_ID|NAVER_CLIENT_SECRET)\s*=\s*(.*)\s*$/.exec(line);
        if (m) fromFile[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2').trim();
      }
    } catch { /* no file: the environment only */ }
  }
  const id = String(env.NAVER_CLIENT_ID || fromFile.NAVER_CLIENT_ID || '').trim();
  const secret = String(env.NAVER_CLIENT_SECRET || fromFile.NAVER_CLIENT_SECRET || '').trim();
  return id && secret ? { id, secret } : null;
}
/** Search answer text: the <b> marks and other tags out, entities decoded, spaces collapsed. */
export const stripTags = (s) => norm(decodeEntities(String(s ?? '').replace(/<[^>]+>/g, '')));
const hostOf = (u) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return ''; } };
// the blocklist names groups, not domains: a romanized alias of a blocked group (5+ letters) inside a host blocks it
const HOST_ALIASES = BLOCK.entries.filter((e) => e.level === 'block').flatMap((e) => e.aliases).filter((a) => /^[a-z0-9 .'-]+$/i.test(a)).map((a) => a.toLowerCase().replace(/[^a-z0-9]/g, '')).filter((a) => a.length >= 5);
const blockedHost = (url) => { const h = hostOf(url).toLowerCase().replace(/[^a-z0-9]/g, ''); return !!h && HOST_ALIASES.some((a) => h.includes(a)); };
/** X: the blocklist names the page (its title as the site name) or its host. */
export const blocked = (url, title = null) => blockedHost(url) || classOf({ url, site: title }).doctrine === 'X';
/** The page text cut at a sentence end under max characters. */
export function cutText(text, max = READ_CHARS) {
  const t = String(text ?? '').replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim();
  if ([...t].length <= max) return t;
  const cut = [...t].slice(0, max).join('');
  const end = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('.\n'), cut.lastIndexOf('다. '), cut.lastIndexOf('? '), cut.lastIndexOf('! '));
  return end > max * 0.6 ? cut.slice(0, end + 1).trim() : cut;
}
const pageLines = (html) => htmlToText(html).split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n');
const titleOf = (html) => stripTags((/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1]) ?? '');

/**
 * search({query, kind, count, recentDays}) / read({url}, {allow}) / verify({url, quote}) / knows(url) over one cache.
 * Injectable: fetch (the search call), fetchPage (fetchRaw), keys (() => {id, secret} | null), now, sleep.
 */
export function makeSearch({ fetch: fetchImpl = (u, o) => fetch(u, o), fetchPage = fetchRaw, keys = () => null, now = () => Date.now(), sleep = (ms) => new Promise((r) => setTimeout(r, ms)) } = {}) {
  const answers = new Map(); // kind|query|count|recentDays -> {value, at}
  const pages = new Map(); // url -> {text, title, finalUrl, at}
  const known = new Set(); // urls this process returned
  let last = 0;
  async function search({ query, kind = 'web', count = 5, recentDays } = {}) {
    // the keys first: an empty query is how the page asks whether searching can work at all (no call is made)
    const k = keys();
    if (!k) return { error: 'no-keys' };
    const q = String(query ?? '').trim();
    if (!q) return { error: 'invalid', reason: 'query required' };
    if (!SEARCH_KINDS[kind]) return { error: 'invalid', reason: 'kind: news | web | blog | encyc' };
    const n = Math.min(Math.max(Number.isInteger(count) ? count : 5, 1), 10);
    const days = kind === 'news' && Number.isInteger(recentDays) && recentDays > 0 ? recentDays : null;
    const ck = [kind, q, n, days].join('|');
    const c = answers.get(ck);
    if (c && now() - c.at < SEARCH_TTL_MS) return c.value;
    const wait = last + 1000 - now();
    if (wait > 0) await sleep(wait);
    last = now();
    const qs = new URLSearchParams({ query: q, display: String(n), start: '1', sort: 'sim', format: 'json' });
    let res;
    try {
      res = await fetchImpl(SEARCH_BASE + SEARCH_KINDS[kind] + '?' + qs.toString(), { headers: { 'X-NCP-APIGW-API-KEY-ID': k.id, 'X-NCP-APIGW-API-KEY': k.secret, Accept: 'application/json' } });
    } catch { return { error: 'unreachable' }; }
    if (res.status === 401 || res.status === 403) return { error: 'bad-keys' };
    if (res.status === 429) return { error: 'quota' };
    if (!res.ok) return { error: 'unreachable', reason: `HTTP ${res.status}` };
    let body;
    try { body = await res.json(); } catch { return { error: 'unreachable', reason: 'not JSON' }; }
    const results = [], dropped = { blocklisted: 0, han: 0 };
    for (const it of Array.isArray(body?.items) ? body.items : []) {
      const url = String((kind === 'news' && it.originallink) || it.link || '').trim();
      if (!/^https?:\/\//.test(url)) continue;
      if (hasHan(url)) { dropped.han++; continue; }
      const title = stripTags(it.title);
      if (blocked(url, title)) { dropped.blocklisted++; continue; }
      const cls = classOf({ url });
      const at = it.pubDate ? Date.parse(it.pubDate) : NaN;
      if (days && (Number.isNaN(at) || now() - at > days * 86400000)) continue;
      const t = tierOf(url);
      results.push({ title, url, site: siteOf(url)?.domain ?? hostOf(url), description: stripTags(it.description), ...(Number.isNaN(at) ? {} : { publishedAt: new Date(at).toISOString() }), tier: t.tier, doctrine: cls.doctrine, group: t.group });
      known.add(url);
    }
    const value = { results, dropped };
    answers.set(ck, { value, at: now() });
    return value;
  }
  async function fetchText(url) {
    const c = pages.get(url);
    if (c && now() - c.at < SEARCH_TTL_MS) return c;
    const r = await fetchPage(url);
    if (!r.ok) return { error: r.reason || 'unreachable' };
    if (/just a moment|checking your browser|client challenge|attention required/i.test(titleOf(r.html))) return { error: 'bot check page' };
    const text = pageLines(r.html);
    if ([...norm(text)].length < MIN_READABLE_CHARS) return { error: 'no readable text' };
    const v = { text, title: titleOf(r.html), finalUrl: r.finalUrl || url, at: now() };
    pages.set(url, v);
    return v;
  }
  const refused = (url) => (hasHan(url) ? '개역한글(version=HAN) link rejected' : blocked(url) ? 'blocklisted' : null);
  async function read({ url } = {}, { allow = false } = {}) {
    const checkedAt = new Date(now()).toISOString();
    if (typeof url !== 'string' || (!known.has(url) && !allow)) return { status: 'invalid', reason: 'not a URL this tool returned', checkedAt };
    if (refused(url)) return { status: 'invalid', reason: refused(url), checkedAt };
    const p = await fetchText(url);
    const t = tierOf(url);
    if (p.error) return { status: 'unreachable', reason: p.error, url, checkedAt };
    const text = cutText(p.text);
    return { url, finalUrl: p.finalUrl, title: p.title, site: siteOf(url)?.domain ?? hostOf(url), tier: t.tier, doctrine: classOf({ url }).doctrine, text, chars: [...text].length, checkedAt: new Date(p.at).toISOString() };
  }
  async function verify({ url, quote } = {}) {
    const checkedAt = new Date(now()).toISOString();
    if (typeof url !== 'string' || !known.has(url)) return { status: 'invalid', reason: 'not a URL this tool returned', checkedAt };
    if (refused(url)) return { status: 'invalid', reason: refused(url), checkedAt };
    const doctrine = classOf({ url }).doctrine;
    if (typeof quote !== 'string' || !norm(quote)) return { status: 'invalid', reason: 'empty quote', doctrine, checkedAt };
    if (quoteLength(quote) > QUOTE_MAX) return { status: 'invalid', reason: `quote longer than ${QUOTE_MAX} chars`, doctrine, checkedAt };
    const p = await fetchText(url);
    if (p.error) return { status: 'unreachable', reason: p.error, doctrine, finalUrl: url, checkedAt };
    return { status: norm(p.text).includes(norm(quote)) ? 'found' : 'not-found', doctrine, title: p.title, finalUrl: p.finalUrl, checkedAt: new Date(p.at).toISOString() };
  }
  return { search, read, verify, knows: (url) => known.has(url), remember: (url) => known.add(url) };
}
