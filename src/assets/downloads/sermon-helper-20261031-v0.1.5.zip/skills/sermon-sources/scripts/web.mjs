// Online commentaries for the 출처 확인 (host tools web-pages / web-verify): deterministic URLs from
// web-commentaries.json, read on the owner's computer. No search engine, no link following, listed hosts only,
// never a 개역한글(HAN) URL. Quotes are checked like check.mjs checkSpan (norm(), at most QUOTE_MAX characters).
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { fetchRaw, htmlToText, norm, quoteLength, QUOTE_MAX, MIN_READABLE_CHARS, classOf, tierOf, findBook, hasHan } from './check.mjs';

export const WEB = JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), 'web-commentaries.json'), 'utf8'));
/** At most this many pages per web-pages call, characters per page and in all. */
export const WEB_MAX = 4;
export const WEB_CHARS = 12000;
export const WEB_TOTAL = 24000;
export const WEB_TTL_MS = 15 * 60 * 1000;
const RANK = { R: 0, E: 1, N: 2 };

/** "시편 127:1-5" / "요한복음 15장" / {book, chapter} -> {book (bible.json entry), chapter, verse} or null. */
export function webPassage(p) {
  if (p && typeof p === 'object') { const book = findBook(String(p.book ?? '')); const chapter = Number(p.chapter); return book && Number.isInteger(chapter) && book.chapters[chapter - 1] ? { book, chapter, verse: Number(p.verse) || 1 } : null; }
  const m = /^(.+?)\s*(\d{1,3})\s*(?:[:：]|[장편]\s*)?\s*(\d{1,3})?/.exec(String(p ?? '').normalize('NFC').trim());
  if (!m) return null;
  const book = findBook(m[1].trim()) ?? findBook(m[1].replace(/\s+/g, ''));
  const chapter = Number(m[2]);
  return book && book.chapters[chapter - 1] ? { book, chapter, verse: Number(m[3]) || 1 } : null;
}
export const webUrl = (entry, book, chapter) => entry.pattern.replace('{book}', WEB.books[book.code]).replace('{chapter}', String(chapter));
/** Is this a URL the server builds (a listed entry, a listed book, a real chapter)? */
export function builtUrl(url) {
  let u;
  try { u = new URL(url); } catch { return null; }
  if (u.protocol !== 'https:' || !WEB.hosts.includes(u.hostname) || u.search || u.hash || hasHan(url)) return null;
  for (const e of WEB.entries) {
    const [pre, post] = e.pattern.split('{book}');
    const [mid, end] = post.split('{chapter}');
    if (!url.startsWith(pre) || !url.endsWith(end)) continue;
    const rest = url.slice(pre.length, url.length - end.length);
    const i = rest.indexOf(mid);
    if (i < 0) continue;
    const slug = rest.slice(0, i), chapter = Number(rest.slice(i + mid.length));
    const code = Object.keys(WEB.books).find((k) => WEB.books[k] === slug);
    const book = code && findBook(code);
    if (book && Number.isInteger(chapter) && book.chapters[chapter - 1] && webUrl(e, book, chapter) === url) return { entry: e, book, chapter };
  }
  return null;
}
/** The page text from the passage's first verse heading on (else from the top), cut at a sentence end under max. */
export function excerptOf(text, chapter, verse, max) {
  let t = text;
  if (verse > 1) { const m = new RegExp(`(^|\\n)[^\\n]{0,40}\\b${chapter}:${verse}\\b[^\\n]*\\n`).exec(t); if (m) t = t.slice(m.index); }
  t = t.replace(/[ \t]+/g, ' ').replace(/\n\s*\n+/g, '\n').trim();
  if ([...t].length <= max) return t;
  const cut = [...t].slice(0, max).join('');
  const end = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('.\n'), cut.lastIndexOf('? '), cut.lastIndexOf('! '));
  return end > max * 0.6 ? cut.slice(0, end + 1) : cut;
}
const pageLines = (html) => htmlToText(html).split('\n').map((l) => l.replace(/\s+/g, ' ').trim()).filter(Boolean).join('\n');
const titleOk = (html) => !/just a moment|checking your browser|client challenge|attention required/i.test((/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? ''));

/** The two tools over one in-memory cache (url -> {text, finalUrl, at}). `fetchRaw` and `now` are injectable for tests. */
export function makeWeb({ fetch: fetchPage = fetchRaw, now = () => Date.now() } = {}) {
  const cache = new Map();
  async function read(url) {
    const c = cache.get(url);
    if (c && now() - c.at < WEB_TTL_MS) return c;
    const r = await fetchPage(url);
    if (!r.ok) return { error: r.reason || 'unreachable' };
    if (!titleOk(r.html)) return { error: 'bot check page' };
    const text = pageLines(r.html);
    if ([...norm(text)].length < MIN_READABLE_CHARS) return { error: 'no readable text' };
    const v = { text, finalUrl: r.finalUrl || url, at: now() };
    cache.set(url, v);
    return v;
  }
  return {
    cache,
    async pages({ passage, ids } = {}) {
      const where = webPassage(passage);
      if (!where) throw Object.assign(new Error('passage: a Bible address like "요한복음 15:1-11"'), { toolError: true });
      const wanted = Array.isArray(ids) && ids.length ? WEB.entries.filter((e) => ids.includes(e.id)) : WEB.entries;
      const list = wanted.map((e) => ({ e, url: webUrl(e, where.book, where.chapter), cls: classOf({ url: webUrl(e, where.book, where.chapter), author: e.author }) }))
        .filter((x) => x.cls.doctrine !== 'X').sort((a, b) => (RANK[a.cls.doctrine] ?? 3) - (RANK[b.cls.doctrine] ?? 3));
      const got = [], skipped = [];
      for (const x of list) {
        if (got.length >= WEB_MAX) break;
        if (hasHan(x.url)) { skipped.push({ id: x.e.id, url: x.url, reason: 'HAN' }); continue; }
        const r = await read(x.url);
        if (r.error) { skipped.push({ id: x.e.id, url: x.url, reason: r.error }); continue; }
        got.push({ ...x, r });
      }
      let left = WEB_TOTAL;
      const pages = got.map((x, i) => {
        const text = excerptOf(x.r.text, where.chapter, where.verse, Math.min(WEB_CHARS, Math.floor(left / (got.length - i))));
        left -= [...text].length;
        return { key: 'web:' + x.e.id, id: x.e.id, author: x.e.author, title: x.e.title, url: x.url, doctrine: x.cls.doctrine, tier: tierOf(x.url).tier, text, chars: [...text].length, checkedAt: new Date(x.r.at).toISOString() };
      });
      return { pages, skipped };
    },
    async verify({ url, quote } = {}) {
      const checkedAt = new Date(now()).toISOString();
      const b = typeof url === 'string' ? builtUrl(url) : null;
      if (!b) return { status: 'invalid', reason: hasHan(String(url ?? '')) ? '개역한글(version=HAN) link rejected' : 'not a URL this tool builds', checkedAt };
      const doctrine = classOf({ url, author: b.entry.author }).doctrine;
      const base = { doctrine, title: b.entry.title };
      if (typeof quote !== 'string' || !norm(quote)) return { status: 'invalid', reason: 'empty quote', ...base, checkedAt };
      if (quoteLength(quote) > QUOTE_MAX) return { status: 'invalid', reason: `quote longer than ${QUOTE_MAX} chars`, ...base, checkedAt };
      const r = await read(url);
      if (r.error) return { status: 'unreachable', reason: r.error, ...base, finalUrl: url, checkedAt };
      return { status: norm(r.text).includes(norm(quote)) ? 'found' : 'not-found', ...base, finalUrl: r.finalUrl, checkedAt: new Date(r.at).toISOString() };
    },
  };
}
