---
name: sermon-sources
description: 설교 준비에서 주석·인용·역사 배경의 출처를 실제 웹 페이지로 확인해 출처 원장(sources.json)에 적는다. 원문을 다시 받아 인용 구절이 글자 그대로 있어야 '출처 있음'. 설교 스킬 전체가 함께 쓴다.
---

# sermon-sources — 출처 원장

설교 스킬(sermon-exegesis · sermon-angles · sermon-outline · sermon-manuscript)이 사실을 말할 때마다 이 스킬의 규칙을 따른다.
자세한 규칙은 같은 폴더의 `RULES.md`, 교리 기준은 `DOCTRINE.md`. 도구는 `scripts/check.mjs`(Node 18 이상, 설치할 것 없음).

> **절대 규칙(DOCTRINE.md):** 이단·사이비 자료는 어떤 출처로도 쓰지 않는다. 해석·교리의 근거는 개혁주의(R) 출처만 쓴다. 비개혁주의(E)·비기독교(N) 출처는 사실·역사·원어·예화에만 쓰고, 화면에 표시된다.

이 스킬 폴더의 경로를 `$SRC`라고 부른다. 스킬을 불러오면 Claude Code가 'Base directory'로 알려 준다.
예: `~/.claude/skills/sermon-sources`.

## 설교준비 도우미의 8 출처 확인

도우미에서 마친 원고에 각주를 다는 일은 `sermon-page/SKILL.md` §3-4가 이끈다. 이 원장과 `check.mjs`가 그 확인을 맡는다. 목사님 원고의 문장은 바꾸지 않고 문장 끝에 표시만 붙인다.

도우미 페이지 안의 출처 확인(Claude 데스크톱 앱)은 주석 도구(`sermon-commentary/mcp/server.mjs`)의 `web-pages`·`web-verify`로 온라인 주석도 읽는다. 검색 엔진은 쓰지 않는다: `scripts/web-commentaries.json`의 목록(Bible Hub의 칼빈·매튜 헨리·풀·길 등 16종, 66권 주소표)으로 주소를 만들고(`scripts/web.mjs`), 그 호스트만 읽고, 링크는 따라가지 않으며, 개역한글(HAN) 주소는 거부한다. 교리 등급은 `authors.json`(없으면 E), 인용 확인은 `checkSpan`과 같은 규칙(norm, 300자)이다.

웹 검색(`web-search`·`web-read`)은 `scripts/websearch.mjs`가 NAVER API HUB로 한다(키는 저장소 `.env.local`의 `NAVER_CLIENT_ID`·`NAVER_CLIENT_SECRET`, 페이지로 보내지 않음). 결과마다 `sites.json` 등급과 금지 목록을 거치고(X는 빼고 열지 않음; 금지 단체의 로마자 이름이 들어간 호스트도 X), 개역한글 링크는 뺀다. 1초에 한 번, 15분 저장. `web-read`·`web-verify`는 이 과정에서 검색이 돌려준 주소(또는 web-pages의 주소)만 연다.

## 한 줄 원칙

**열어 본 페이지에서 원문 그대로 찾은 구절만 출처다.** 그렇지 않은 사실 주장은 **'확인 필요'** 로 표시한다.
출처를 지어내지 않는다. 주소를 추측해서 적지 않는다.

## 설교 폴더

설교마다 폴더 하나: `sermons/<slug>/` (예 `sermons/요한복음-15-1-11/`).

- `exegesis.json` · `angles.json` · `outline.json` · `manuscript.json` — 단계별 결과 (각 단계 스킬이 쓴다)
- `sources.json` — 출처 원장 (이 스킬의 도구가 쓴다. 손으로 status를 바꾸지 않는다)

## 출처를 더하는 순서

1. **찾기:** 웹 검색으로 후보를 찾는다. 등급 A 사이트를 먼저 본다(RULES.md §2).
2. **읽기:** WebFetch 등으로 페이지를 읽고 쓸 구절을 고른다. 이때 나온 요약은 출처가 아니다.
3. **원문 확인 + 기록:** 구절을 원문에서 글자 그대로(300자 이하) 골라 아래를 실행한다.
   ```bash
   node "$SRC/scripts/check.mjs" add sermons/<slug> --url "<주소>" --quote "<원문 구절>" --claim <doctrine|fact|history|language|illustration> --site "<사이트 이름>" --author "<저자 또는 생략>" --published "<게시일 또는 생략>"
   ```
   - `--claim`은 이 출처가 뒷받침하는 문장의 종류다(DOCTRINE.md §3). 해석·교리는 `doctrine`이며 **개혁주의(R) 출처만** 통과한다.
   - 도구가 교리 등급(R/E/N/X)을 정해 함께 적는다(`blocklist.json` → `authors.json` → `sites.json` → 목록 밖은 E).
     - X(합동 총회 이단·사이비 결의)는 종료 코드 2로 거부된다. `doctrine` 주장에 R이 아니면 종료 코드 3으로 거부된다.
   - 여러 저자 사이트(biblehub·ccel 등)는 `--author`를 꼭 적는다. 모르는 저자는 E다.
   - 결과 `status`가 `found`일 때만 그 출처를 근거로 쓴다.
   - `not-found`면 구절을 원문과 다시 맞춰 본다. 요약을 원문으로 착각하지 않았는지 확인한다.
   - `unreachable`(봇 확인, 자바스크립트로만 그리는 페이지, 로그인 필요)이면 다른 페이지를 찾거나 그 주장을 '확인 필요'로 둔다.
4. **성경 구절:**
   ```bash
   node "$SRC/scripts/check.mjs" bible sermons/<slug> 요한복음 15 5 --wording ai-recall
   ```
   - 대한성서공회 읽기 링크(`version=GAE`)가 만들어진다.
   - 개역개정 문구를 화면에 보이면 `--wording`에 출처를 적는다: 목사님이 붙여넣으면 `user-paste`, 기억으로 옮기면 `ai-recall`.
5. **본문에 표시:** 단계 파일의 문장 끝에 각주 표시를 단다.
   - `[^w3]` 웹 · `[^b2]` 성경 · `[^u1]` 목사님 자료 · `[^?]` 확인 필요 · `[^d?]` 교리 확인 필요(DOCTRINE.md §4)
   - 한 문장에 여러 개를 달 수 있다.
6. **점검:** 단계를 마칠 때마다, 그리고 마지막에 반드시 실행한다.
   ```bash
   node "$SRC/scripts/check.mjs" sermon sermons/<slug>
   ```
   웹 출처를 모두 다시 받아 확인한다. `ok: true`가 아니면 고친 뒤 다시 돌린다.

## 목사님 서재의 주석 (sermon-commentary)

목사님 주석 서재(PDF)에서 인용할 때는 `sermon-commentary` 스킬의 `commentary.mjs add`로 '주석' 출처(`kind: "commentary"`, 본문 표시 `[^c1]`)를 더한다.
인용이 그 쪽의 뽑아 둔 글에 글자 그대로 있어야 found이고, `check.mjs sermon`이 다시 확인한다. 교리 등급·주장 규칙은 웹 출처와 같다.

## 상태 뜻 (목사님께 그대로 설명할 수 있게)

| 상태 | 뜻 |
| --- | --- |
| found | 페이지를 다시 받아 보니 인용 구절이 글자 그대로 있다. 출처로 인정 |
| not-found | 페이지는 열렸지만 그 구절이 없다. 출처로 쓰지 않음 |
| unreachable | 페이지를 글로 읽을 수 없었다(막힘·자바스크립트 전용·로그인·PDF). 출처로 쓰지 않음 |
| unverified | 찾아볼 페이지를 아직 못 찾음. 본문에서는 '확인 필요' |
| 등급 A | 성서공회·교단·신학교·학술지·출판사·기독 언론·주석 사이트. 사실 주장의 근거가 될 수 있다 |
| 등급 B | 개인 블로그·카페·위키·영상 등. '참고'로만 쓰고, 혼자서는 근거가 되지 못한다 |

## 다른 명령

- `check.mjs span <url> "<구절>"` — 기록 없이 확인만
- `check.mjs tier <url>` — 사이트 등급
- `check.mjs link 요한복음 15 5` — 읽기 링크만
- `check.mjs stage <파일>` — 단계 파일 모양·분량 검사
