#!/usr/bin/env node
// sermon-commentary — 목사님 주석 서재(PDF)에서 본문에 맞는 주석 1~3권을 고르고, 그 쪽만 꺼낸다. Node 18 이상.
// 글자 있는 PDF는 모든 운영체제에서 pdf.js(동봉), 스캔본 글자 인식은 macOS Vision · Windows.Media.Ocr (platform.mjs).
//   node commentary.mjs library add <폴더> | list | remove <폴더|번호>   주석 폴더 등록(여러 개, .local/commentary/libraries.json)
//   node commentary.mjs catalog [--root <서재>]          등록한 폴더 전부를 이름·크기만 읽어 목록을 만든다(파일 내용은 열지 않음)
//   node commentary.mjs select "요한복음 15:1-11"       후보 순위 → 상위 몇 권만 글자를 뽑아 위치 확인 → 3권
//   node commentary.mjs extract <key> [--ocr]           한 권의 쪽별 글자(pdf.js, 스캔본은 --ocr로 글자 인식)
//   node commentary.mjs doctor                          이 컴퓨터에서 되는지 점검(Node·PDF 도구·글자 인식 언어·시험 PDF·연결한 폴더)
//   node commentary.mjs locate <key> "요한복음 15:1-11"  그 본문을 다루는 쪽 범위와 그 쪽의 글
//   node commentary.mjs verify <key> <쪽> "<인용>"       인용이 그 쪽 글에 있는지
//   node commentary.mjs add <설교폴더> --file <key> --page <쪽> --quote "…" --claim <종류>
// 서재 폴더는 읽기만 한다. 목록과 뽑은 글은 .local/commentary/(git 제외)에만 둔다. 주석 글은 커밋·게시하지 않는다.

import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, statSync, realpathSync, rmSync } from 'node:fs';
import { join, dirname, basename, extname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { runExtract, folderPath, doctor, doctorText } from './platform.mjs';
export { localState } from './platform.mjs';
import {
  BIBLE, classOf, blockMatches, claimAllowed, CLAIMS, QUOTE_MAX, quoteLength,
  commentaryHome, commentaryCachePath, commentaryPageText, quoteInPage,
} from '../../sermon-sources/scripts/check.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
// ---------------------------------------------------------------- libraries (the user's own folders; none built in)
// Any folder the user names: local disk, Google Drive, iCloud, OneDrive, an external drive. Kept in
// .local/commentary/libraries.json (git-ignored) as {version: 1, libraries: [{path, addedAt}]}.
export function librariesPath() { return join(commentaryHome(), 'libraries.json'); }
export function readLibraries() {
  if (!existsSync(librariesPath())) return null;
  const d = JSON.parse(readFileSync(librariesPath(), 'utf8'));
  return { version: 1, libraries: Array.isArray(d?.libraries) ? d.libraries.filter((l) => l && typeof l.path === 'string') : [] };
}
function writeLibraries(list) {
  mkdirSync(commentaryHome(), { recursive: true });
  writeFileSync(librariesPath(), JSON.stringify({ version: 1, libraries: list }, null, 2) + '\n');
}
const isDir = (p) => { try { return statSync(p).isDirectory(); } catch { return false; } };
const samePath = (a, b) => { const r = (p) => { try { return nfc(realpathSync(p)); } catch { return nfc(resolve(p)); } }; return r(a) === r(b); };
/** Register a folder (absolute path kept as the user gave it, NFC). Adding the same folder twice changes nothing. */
export function addLibrary(folder) {
  const path = folderPath(folder); // drive letters, UNC shares, quotes, ~ handled per OS
  if (!isDir(path)) { const e = new Error(`not a folder: ${path}`); e.code = 2; throw e; }
  const list = readLibraries()?.libraries ?? [];
  if (list.some((l) => samePath(l.path, path))) return { added: false, path, libraries: list };
  list.push({ path, addedAt: new Date().toISOString() });
  writeLibraries(list);
  return { added: true, path, libraries: list };
}
/** Remove by path or by its number in `library list` (1-based). The folder itself is never touched. */
export function removeLibrary(which) {
  const list = readLibraries()?.libraries ?? [];
  const n = /^\d+$/.test(String(which)) ? Number(which) - 1 : list.findIndex((l) => samePath(l.path, String(which)) || l.path === nfc(String(which)));
  if (n < 0 || n >= list.length) { const e = new Error(`not registered: ${which}`); e.code = 2; throw e; }
  const [removed] = list.splice(n, 1);
  writeLibraries(list);
  return { removed: removed.path, libraries: list };
}
export function listLibraries() {
  return (readLibraries()?.libraries ?? []).map((l, i) => ({ n: i + 1, path: l.path, addedAt: l.addedAt, exists: isDir(l.path) }));
}
/** One-time move from the single-folder days: no libraries.json yet, but an older catalog names a folder that exists. */
export function migrateLibraries() {
  if (existsSync(librariesPath()) || !existsSync(catalogPath())) return null;
  let root = null;
  try { root = JSON.parse(readFileSync(catalogPath(), 'utf8')).root; } catch { return null; }
  if (typeof root !== 'string' || !isDir(root)) return null;
  writeLibraries([{ path: nfc(root), addedAt: new Date().toISOString(), from: 'catalog.json (before libraries.json)' }]);
  return { migrated: nfc(root) };
}
/** Folders to read: --root, else SERMON_COMMENTARY_LIBRARY, else the registered ones (after the one-time migration). */
export function libraryRoots({ root, log = (m) => console.error(m) } = {}) {
  if (root) return [nfc(root)];
  if (process.env.SERMON_COMMENTARY_LIBRARY) return [nfc(process.env.SERMON_COMMENTARY_LIBRARY)];
  const m = migrateLibraries();
  if (m) log(`registered the folder from the earlier catalog once: ${m.migrated} (library list / remove to change)`);
  const list = (readLibraries()?.libraries ?? []).map((l) => l.path);
  if (!list.length) { const e = new Error('no commentary folder registered — run: commentary.mjs library add <folder>'); e.code = 2; throw e; }
  return list;
}
const sha = (s, n = 12) => createHash('sha1').update(s).digest('hex').slice(0, n);
const nfc = (s) => String(s).normalize('NFC');

// ---------------------------------------------------------------- book names
const EN = ['Genesis', 'Exodus', 'Leviticus', 'Numbers', 'Deuteronomy', 'Joshua', 'Judges', 'Ruth', '1 Samuel', '2 Samuel', '1 Kings', '2 Kings', '1 Chronicles', '2 Chronicles', 'Ezra', 'Nehemiah', 'Esther', 'Job', 'Psalms', 'Proverbs', 'Ecclesiastes', 'Song of Songs', 'Isaiah', 'Jeremiah', 'Lamentations', 'Ezekiel', 'Daniel', 'Hosea', 'Joel', 'Amos', 'Obadiah', 'Jonah', 'Micah', 'Nahum', 'Habakkuk', 'Zephaniah', 'Haggai', 'Zechariah', 'Malachi', 'Matthew', 'Mark', 'Luke', 'John', 'Acts', 'Romans', '1 Corinthians', '2 Corinthians', 'Galatians', 'Ephesians', 'Philippians', 'Colossians', '1 Thessalonians', '2 Thessalonians', '1 Timothy', '2 Timothy', 'Titus', 'Philemon', 'Hebrews', 'James', '1 Peter', '2 Peter', '1 John', '2 John', '3 John', 'Jude', 'Revelation'];
const EN_EXTRA = { 19: ['Psalm'], 22: ['Song of Solomon', 'Canticles'], 44: ['Acts of the Apostles'], 66: ['Apocalypse'] };
// Korean spellings seen in library file names besides bible.json (name + abbrevs)
const KO_EXTRA = { 7: ['사사기'], 22: ['아가서'], 24: ['에레미야'], 31: ['오바댜'], 42: ['누가복음서'], 44: ['사도행전'], 57: ['빌레몬서'], 66: ['계시록'] };
const BOOKS = BIBLE.books;
const book = (id) => BOOKS.find((b) => b.id === id);
const KO_FULL = BOOKS.flatMap((b) => [b.name, ...(KO_EXTRA[b.id] ?? [])].map((n) => [n, b.id])).sort((a, b) => b[0].length - a[0].length);
const KO_ABBR = new Map(BOOKS.flatMap((b) => b.abbrevs.map((a) => [a, b.id])));
const EN_NAMES = EN.flatMap((n, i) => [n, ...(EN_EXTRA[i + 1] ?? [])].map((x) => [x, i + 1])).sort((a, b) => b[0].length - a[0].length);
// ordinary words whose syllables happen to be book abbreviations (신약 = 신+약, 사막 = 사+막 ...)
const ORDINARY = /^(신약|구약|신학|사막|나갈|요단|행전)/;
const PAIRS = { 고린도: [46, 47], 데살로니가: [52, 53], 디모데: [54, 55], 베드로: [60, 61], 살: [52, 53], 딤: [54, 55], 벧: [60, 61], 고: [46, 47] };

/** Book ids named in a title (title part only, never the author part). Each hit: {id, at, end}. */
export function booksIn(title) {
  const t = nfc(title);
  const hits = [];
  const taken = new Array(t.length).fill(false);
  const take = (at, len, ids) => {
    for (let i = at; i < at + len; i++) if (taken[i]) return;
    for (let i = at; i < at + len; i++) taken[i] = true;
    for (const id of ids) hits.push({ id, at, end: at + len });
  };
  const scan = (re, ids) => { for (const m of t.matchAll(re)) take(m.index, m[0].length, typeof ids === 'function' ? ids(m) : ids); };
  // 그랜드 종합주석 "[43] John(21)(all)"
  scan(/\[(\d{2})\]/g, (m) => (Number(m[1]) >= 1 && Number(m[1]) <= 66 ? [Number(m[1])] : []));
  // 요한일이삼서 / 요한 1 2 3서 / 요123 / 요한1,2,3서
  scan(/요한\s*(?:일이삼|1\s*[,.]?\s*2\s*[,.]?\s*3)\s*서?|요\s*123/g, [62, 63, 64]);
  scan(/(?:The\s+)?(?:Epistles|Letters)\s+of\s+John|요한\s*서신/gi, [62, 63, 64]);
  scan(/공관\s*복음/g, [40, 41, 42]);
  // "The First Epistle to the Corinthians", "Second Letter of Peter"
  scan(/(First|Second|Third|1st|2nd|3rd)\s+(?:Epistle|Letter)\s+(?:of|to)\s+(?:the\s+)?(Corinthians|Thessalonians|Timothy|Peter|John)/gi, (m) => {
    const n = { first: 1, '1st': 1, second: 2, '2nd': 2, third: 3, '3rd': 3 }[m[1].toLowerCase()];
    const id = EN.indexOf(`${n} ${m[2][0].toUpperCase()}${m[2].slice(1).toLowerCase()}`) + 1;
    return id ? [id] : [];
  });
  scan(/요한\s*(?:일|1)\s*서/g, [62]);
  scan(/요한\s*(?:이|2)\s*서/g, [63]);
  scan(/요한\s*(?:삼|3)\s*서/g, [64]);
  // 고린도전후서, 데살로니가전후, 벧전후, 살전후
  scan(/(고린도|데살로니가|디모데|베드로|살|딤|벧|고)\s*전\s*후\s*서?/g, (m) => PAIRS[m[1]]);
  for (const [name, id] of KO_FULL) scan(new RegExp(name, 'g'), [id]);
  for (const [name, id] of EN_NAMES) {
    const re = /^\d /.test(name)
      ? new RegExp(`(?<![\\p{L}\\d])(?:${name[0]}|${['', 'First', 'Second', 'Third'][Number(name[0])]})\\s*${name.slice(2)}(?![\\p{L}])`, 'gu')
      : new RegExp(`(?<![\\p{L}\\d])(?<!(?:^|\\D)[123]\\s)(?<!(?:First|Second|Third)\\s)${name}(?![\\p{L}])`, 'gu');
    scan(re, [id]);
  }
  // abbreviation ranges "롬-고후", "스~욥" and lists "마.마가", "전_아", "마막눅": every token must be an abbreviation
  for (const m of t.matchAll(/(?<![\p{L}])([가-힣]{1,3})\s*([-~])\s*([가-힣]{1,3})(?![\p{L}])/gu)) {
    const a = KO_ABBR.get(m[1]), b = KO_ABBR.get(m[3]);
    if (a && b && b > a) take(m.index, m[0].length, Array.from({ length: b - a + 1 }, (_, i) => a + i));
  }
  for (const m of t.matchAll(/(?<![\p{L}])[가-힣]{1,3}(?:[._·,][가-힣]{1,3})+(?![\p{L}])/gu)) {
    const parts = m[0].split(/[._·,]/);
    const ids = parts.map((p) => (KO_ABBR.has(p) ? [KO_ABBR.get(p)] : PAIRS[p]));
    if (ids.every(Boolean)) take(m.index, m[0].length, ids.flat());
  }
  for (const m of t.matchAll(/(?<![\p{L}])[가-힣]{2,5}(?![\p{L}])/gu)) {
    if (ORDINARY.test(m[0])) continue;
    const chars = [...m[0]];
    const ids = chars.map((c) => KO_ABBR.get(c));
    if (chars.length >= 2 && ids.every(Boolean) && new Set(ids).size === ids.length) take(m.index, m[0].length, ids);
  }
  return hits.sort((a, b) => a.at - b.at || a.id - b.id);
}

/** Chapter coverage right after a book name: "15-21장", "제13-21장", "(1-9;50)", "Chapters 1–39", "(상)/(하)", "(21)(all)". */
export function rangeAfter(title, end) {
  const rest = nfc(title).slice(end);
  if (/^\s*\(\d+\)\s*\(all\)/i.test(rest)) return { chapters: 'all', volume: null, how: 'all' };
  let m = /^\s*[,(]?\s*(?:제\s*)?(\d{1,3})\s*(?:장|편)?\s*[-–~]\s*(\d{1,3})(?=\D|$)/.exec(rest) ?? /^,?\s*Chapters?\s+(\d{1,3})\s*[-–]\s*(\d{1,3})/i.exec(rest);
  if (m && Number(m[2]) >= Number(m[1])) return { chapters: [Number(m[1]), Number(m[2])], volume: null, how: 'name' };
  m = /^\s*\(?\s*(상|중|하)\s*\)?/.exec(rest);
  if (m) return { chapters: null, volume: { 상: 1, 중: 2, 하: 3 }[m[1]], volLabel: m[1], how: 'volume' };
  m = /^\s*(\d)(?:\s*ocr|\s*OCR|clearscan|\s*[-_(.)]|\s*$)/.exec(rest) ?? /^\s*vol\.?\s*(\d)/i.exec(rest);
  if (m) return { chapters: null, volume: Number(m[1]), volLabel: m[1], how: 'volume' };
  return { chapters: 'all', volume: null, how: 'assumed' };
}

// single-author series folders (a file name rarely repeats the author)
const DIR_AUTHOR = [
  [/박윤선/, '박윤선'], [/[핸헨]드릭슨/, '윌리엄 핸드릭슨'], [/렌스키/, '렌스키'], [/바클레이/, '윌리엄 바클레이'],
  [/칼빈/, '칼빈'], [/스펄전/, '스펄전'], [/이상근/, '이상근'], [/톰\s*라이트/, '톰 라이트'], [/김정우/, '김정우'],
  [/김희보/, '김희보'], [/메튜\s*헨리|매튜\s*헨리/, '매튜 헨리'],
];
const NOT_AUTHOR = /^(구약|신약|구약편|신약편|프리셉트)$|주석|시리즈|로고스|제자원|성경|강해|연구|ocr|OCR|clearscan|cropped|\d|^(상|중|하)$/;

/** Author from the file name: " - 저자 [지음 …]", "_저자", "…-저자", "(저자)"; else the series folder. */
function authorFromName(name, dirs) {
  const t = nfc(name).replace(/\.[A-Za-z0-9]{2,4}$/, '').replace(/\s*(clearscan_cropped|clearscan)$/i, '');
  const clean = (a) => a.replace(/\s*(지음|저|편저|편역).*$/, '').replace(/\s+\S+\s+옮김$/, '').replace(/\s+/g, ' ').trim();
  let m = / - (.+)$/.exec(t);
  if (m) {
    const a = clean(m[1]);
    if (a && !NOT_AUTHOR.test(a)) return { author: a, how: 'name' };
  }
  m = /^((?:[A-Z]\.\s?){1,3}[가-힣]{2,4})\s/.exec(t); // "D.A.카슨 요한복음 주석"
  if (m) return { author: m[1], how: 'name' };
  m = /\s([가-힣]{1,4}\s[가-힣]{2,4}|[가-힣]{2,4})\s+지음/.exec(t);
  if (m) return { author: m[1], how: 'name' };
  m = /_([^_]+)$/.exec(t);
  if (m && !NOT_AUTHOR.test(m[1]) && booksIn(m[1]).length === 0) return { author: clean(m[1]), how: 'name' };
  m = /\(([가-힣]{2,4}(?:\s[가-힣]{2,5})?)\)$/.exec(t);
  if (m && booksIn(m[1]).length === 0 && !/^(상|중|하)$/.test(m[1])) return { author: m[1], how: 'name' };
  m = /-([가-힣]{2,4}\s[가-힣]{1,4})$/.exec(t);
  if (m && booksIn(m[1]).length === 0) return { author: m[1], how: 'name' };
  return { author: null, how: null };
}
/** authorFrom, but a name that is only a section word ("신약", "구약편") is no author. */
function authorOf(name, dirs) {
  const r = authorFromName(name, dirs);
  return r.author && /^(구약|신약|구약편|신약편|신구약.*|프리셉트)$/.test(r.author) ? { author: null, how: null } : r;
}
export function authorFrom(name, dirs) {
  const r = authorOf(name, dirs);
  if (r.author) return r;
  for (const d of [...dirs].reverse()) for (const [re, a] of DIR_AUTHOR) if (re.test(nfc(d))) return { author: a, how: 'folder' };
  return { author: null, how: null };
}

const CONTAINERS = /^\d+\.\s*주요전집주석$|^(신약|구약)$|ocr$|^칼빈 (신약|구약|주석\(영문\))$|^\d\.\s*옥스퍼드/i;
/** Series = the deepest folder that is not a container ("01. 주요전집주석", "신약", "카리스 신약 ocr"). */
export function seriesFrom(dirs) {
  const d = [...dirs].reverse().find((x) => !CONTAINERS.test(nfc(x))) ?? dirs[0] ?? '';
  const m = /^(.*?)\s*\(([^)]*)\)\s*$/.exec(nfc(d));
  return m ? { series: m[1].trim(), seriesNote: m[2] } : { series: nfc(d), seriesNote: null };
}

/** Parse one library path (relative). Pure: the name and folders only. */
export function parsePath(rel) {
  const parts = nfc(rel).split('/');
  const name = parts.pop();
  const format = extname(name).slice(1).toLowerCase();
  const title = name.slice(0, name.length - extname(name).length);
  const { series, seriesNote } = seriesFrom(parts);
  const { author, how: authorHow } = authorFrom(name, parts);
  // the title part is before " - author" so an author named John never reads as the book John
  const titlePart = title.replace(/ - .+$/, '');
  const hits = booksIn(titlePart);
  const books = [];
  for (const h of hits) if (!books.some((b) => b.id === h.id)) books.push({ id: h.id, ...rangeAfter(titlePart, h.end) });
  // several books in one file ("요한복음(하),사도행전", "마막눅"): a book with no range of its own is whole
  const lang = /[가-힣]/.test(titlePart.replace(/\([^)]*\)/g, '')) ? 'ko' : 'en';
  return { path: nfc(rel), name, title, format, series, seriesNote, author, authorHow, books, lang };
}

// ---------------------------------------------------------------- catalog (stat only)
const SKIP = (n) => n.startsWith('._') || n === '.DS_Store' || n === 'Thumbs.db' || n.startsWith('.');
function walk(root, rel = '', out = []) {
  for (const n of readdirSync(join(root, rel)).sort()) {
    if (SKIP(n)) continue;
    const r = rel ? `${rel}/${n}` : n;
    const st = statSync(join(root, r));
    if (st.isDirectory()) walk(root, r, out);
    else if (st.isFile()) out.push({ rel: r, size: st.size, mtime: Math.floor(st.mtimeMs), root: nfc(root) });
  }
  return out;
}

/** Group same name + same size (duplicate folders) into one entry; the shortest path is primary. */
export function buildCatalog(files) {
  const groups = new Map();
  for (const f of files) {
    const k = `${nfc(basename(f.rel))}\u0000${f.size}`;
    if (!groups.has(k)) groups.set(k, []);
    groups.get(k).push(f);
  }
  const entries = [];
  for (const g of groups.values()) {
    g.sort((a, b) => a.rel.length - b.rel.length || (a.rel < b.rel ? -1 : 1));
    const p = parsePath(g[0].rel);
    entries.push({ key: sha(nfc(g[0].rel)), ...p, ...(g[0].root ? { root: g[0].root } : {}), size: g[0].size, mtime: g[0].mtime, dups: g.slice(1).map((x) => nfc(x.rel)) });
  }
  entries.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0)); // stable: same path keeps the folder order
  // keys stay sha(path) (caches and sermon ledgers keep working); the same path in a second folder gets the folder in its key
  const seen = new Set();
  for (const e of entries) { if (seen.has(e.key)) e.key = sha(`${e.root}\u0000${e.path}`); seen.add(e.key); }
  const formats = {};
  for (const e of entries) formats[e.format] = (formats[e.format] ?? 0) + 1;
  return {
    files: files.length,
    entries,
    stats: { files: files.length, entries: entries.length, duplicates: files.length - entries.length, formats, withBook: entries.filter((e) => e.books.length).length, pdfWithBook: entries.filter((e) => e.format === 'pdf' && e.books.length).length },
  };
}

export function catalogPath() { return join(commentaryHome(), 'catalog.json'); }
/** Catalog of one folder or several (roots: string | string[]); missing folders are listed, not fatal. */
export function scanLibrary(roots) {
  const list = (Array.isArray(roots) ? roots : [roots ?? libraryRoots()]).flat().map(nfc);
  const t0 = Date.now();
  const present = list.filter(isDir);
  const cat = buildCatalog(present.flatMap((r) => walk(r)));
  const perLibrary = list.map((r) => ({ path: r, exists: present.includes(r), files: cat.entries.filter((e) => e.root === r).length }));
  cat.stats.libraries = list.length;
  const out = { root: present[0] ?? list[0], roots: list, perLibrary, builtAt: new Date().toISOString(), ms: Date.now() - t0, ...cat };
  mkdirSync(commentaryHome(), { recursive: true });
  writeFileSync(catalogPath(), JSON.stringify(out));
  return out;
}
export function loadCatalog() {
  if (!existsSync(catalogPath())) throw new Error(`no catalog — run: node commentary.mjs catalog (${catalogPath()})`);
  return JSON.parse(readFileSync(catalogPath(), 'utf8'));
}
const entryOf = (cat, key) => cat.entries.find((e) => e.key === key) ?? (() => { throw new Error(`unknown catalog key ${key}`); })();

// ---------------------------------------------------------------- extract (pdf.js on every OS; OCR only on request)
export const TEXT_PAGE_MIN = 30; // a page with fewer non-space characters has no usable text layer
/** Page-wise text of a PDF file, cached by path + size + mtime. Scanned files are marked needsOcr. */
export function extractFile(absPath, { key, size, mtime, ocr = false, platform } = {}) {
  const st = size == null ? statSync(absPath) : null;
  const meta = { key: key ?? sha(nfc(absPath)), size: size ?? st.size, mtime: mtime ?? Math.floor(st.mtimeMs) };
  const cache = commentaryCachePath(meta.key, meta.size, meta.mtime, ocr ? 'ocr' : 'js');
  if (existsSync(cache)) return { ...JSON.parse(readFileSync(cache, 'utf8')), cached: true };
  const t0 = Date.now();
  mkdirSync(dirname(cache), { recursive: true });
  const tmp = `${cache}.tmp`;
  let raw;
  try { raw = runExtract(absPath, tmp, { ocr, platform }); } finally { try { rmSync(tmp, { force: true }); } catch {} }
  const textPages = raw.pages.filter((p) => p.text.replace(/\s/g, '').length >= TEXT_PAGE_MIN).length;
  const out = {
    ...meta, ocr, engine: raw.engine, pageCount: raw.pageCount, textPages,
    needsOcr: !ocr && textPages < raw.pageCount * 0.5,
    chars: raw.pages.reduce((k, p) => k + p.chars, 0), ms: Date.now() - t0,
    pages: raw.pages.map((p) => ({ page: p.page, text: p.text })),
  };
  writeFileSync(cache, JSON.stringify(out));
  return { ...out, cached: false };
}
export function extractEntry(cat, key, opts = {}) {
  const e = entryOf(cat, key);
  if (e.format !== 'pdf') throw new Error(`${key}: ${e.format} files are phase 2 (PDF only)`);
  return extractFile(join(e.root ?? cat.root, e.path), { key: e.key, size: e.size, mtime: e.mtime, ocr: !!opts.ocr });
}

// ---------------------------------------------------------------- passage + locate
/** "요한복음 15:1-11", "요 15:1-11", "John 15:1-11", "요한복음 15장" -> {bookId, chap, v1, v2}. */
export function parsePassage(q) {
  const m = /^\s*(.+?)\s*(\d{1,3})(?:\s*[:：장]\s*(\d{1,3})?(?:\s*[-–~]\s*(\d{1,3}))?)?\s*절?\s*$/.exec(nfc(q));
  if (!m) throw new Error(`cannot read passage: ${q}`);
  const name = m[1].trim();
  const b = BOOKS.find((x) => x.name === name || x.abbrevs.includes(name) || x.code === name.toLowerCase()) ?? (() => { const h = booksIn(name); return h.length === 1 ? book(h[0].id) : null; })();
  if (!b) throw new Error(`unknown book: ${name}`);
  const chap = Number(m[2]);
  const v1 = m[3] ? Number(m[3]) : 1;
  const v2 = m[4] ? Number(m[4]) : m[3] ? v1 : b.chapters[chap - 1];
  return { bookId: b.id, book: b.name, chap, v1, v2, label: `${b.name} ${chap}:${v1}${v2 !== v1 ? `-${v2}` : ''}` };
}

const OTHER_BOOK_BEFORE = (before, target) => {
  // a reference like "롬 8:1" or "Rom. 8:1" belongs to another book; "요 15:1" / "John 15:1" / bare "15:1" count
  const m = /([가-힣]{1,6}|[A-Za-z]{2,12})\.?\s*$/.exec(before);
  if (!m) return false;
  const w = m[1];
  const ko = KO_ABBR.get(w) ?? KO_FULL.find(([n]) => n === w)?.[1];
  if (ko) return ko !== target;
  const en = EN_NAMES.find(([n]) => n.toLowerCase().startsWith(w.toLowerCase()) && w.length >= 3)?.[1];
  return en ? en !== target : false;
};

/** Score each page for a passage and return the best run of pages. Pure (pages = [{page, text}]). */
function locateRuns(pages, passage, { maxPages = 20 } = {}) {
  const { bookId, chap, v1, v2 } = passage;
  const b = book(bookId);
  const names = [b.name, ...b.abbrevs, EN[bookId - 1]].map((x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const headRe = new RegExp(`^\\s*(?:(?:${names})\\s*)?(?:제\\s*)?(\\d{1,3})\\s*장(?![가-힣])|^\\s*(?:CHAPTER|Chapter)\\s+(\\d{1,3})\\b|^\\s*(?:${names})\\s+(\\d{1,3})\\s*$`, 'm');
  let current = null;
  const scored = pages.map((p) => {
    const text = nfc(p.text);
    let target = 0, head = 0, ctx = 0, past = false;
    const verses = new Set();
    for (const line of text.split('\n')) {
      const h = headRe.exec(line);
      if (h) { current = Number(h[1] ?? h[2] ?? h[3]); if (current === chap) head++; else past = true; }
      for (const m of line.matchAll(/(?<![\d:])(\d{1,3})\s*[:：]\s*(\d{1,3})(?:\s*[-–~]\s*(\d{1,3}))?(?!\d)/g)) {
        if (OTHER_BOOK_BEFORE(line.slice(Math.max(0, m.index - 14), m.index), bookId)) continue;
        const c = Number(m[1]), a = Number(m[2]), z = m[3] ? Number(m[3]) : a;
        if (c !== chap) continue;
        current = chap;
        if (a > v2) past = true;
        if (z >= v1 && a <= v2) { target++; for (let v = Math.max(a, v1); v <= Math.min(z, v2); v++) verses.add(v); }
      }
      if (current === chap) for (const m of line.matchAll(/(?<![\d:])(\d{1,3})\s*(?:[-–~]\s*(\d{1,3})\s*)?절/g)) {
        const a = Number(m[1]), z = m[2] ? Number(m[2]) : a;
        if (z >= v1 && a <= v2) { ctx++; for (let v = Math.max(a, v1); v <= Math.min(z, v2); v++) verses.add(v); }
      }
    }
    return { page: p.page, score: target * 2 + ctx + head * 3, head, verses, past };
  });
  // runs of scoring pages (gaps of up to 2 pages join), best total wins
  // a page where the text has moved past the passage (16장 heading, 15:12) ends a run instead of bridging a gap
  const runs = [];
  let open = false;
  for (const s of scored) {
    if (s.score <= 0) { if (s.past) open = false; continue; }
    const last = runs.at(-1);
    if (open && last && s.page - last.end <= 3) { last.end = s.page; last.items.push(s); open = !s.past; }
    else { runs.push({ start: s.page, end: s.page, items: [s] }); open = true; }
  }
  if (!runs.length) return { found: false, confidence: null, pages: [], verses: [] };
  const total = (r) => r.items.reduce((k, x) => k + x.score, 0);
  let best = runs.reduce((a, r) => (total(r) > total(a) ? r : a));
  if (best.end - best.start + 1 > maxPages) {
    // keep the densest window of maxPages
    let top = null;
    for (const s of best.items) {
      const w = best.items.filter((x) => x.page >= s.page && x.page < s.page + maxPages);
      const t = w.reduce((k, x) => k + x.score, 0);
      if (!top || t > top.t) top = { t, start: s.page, end: w.at(-1).page, items: w };
    }
    best = { ...best, ...top };
  }
  const verses = [...new Set(best.items.flatMap((x) => [...x.verses]))].sort((a, b) => a - b);
  const span = v2 - v1 + 1;
  const heading = best.items.some((x) => x.head > 0);
  const confidence = (heading || verses.includes(v1)) && verses.length >= Math.ceil(span * 0.6) ? 'high' : total(best) >= 6 ? 'medium' : 'low';
  return { found: true, confidence, start: best.start, end: best.end, score: total(best), verses, heading, pages: Array.from({ length: best.end - best.start + 1 }, (_, i) => best.start + i) };
}

const TOC_PAGE = (t) => /차\s*례|목\s*차|contents/i.test(t.slice(0, 200)) || (t.match(/(\.{4,}|…{2,}|[.·…]\s?[.·…]\s?[.·…]).{0,12}\d{1,4}\s*$/gm) ?? []).length >= 4;
/**
 * Table-of-contents strategy (sermon collections): an entry like "16. 기도가 가진 능력의 비밀 (15:7) …… 342" gives a
 * printed page; pages whose first line starts with the entry number ("16. 기도가…" running header) give the PDF pages.
 */
export function locateToc(pages, passage, { maxPages = 20 } = {}) {
  const { chap, v1, v2 } = passage;
  const entries = [];
  for (const p of pages.filter((x) => TOC_PAGE(x.text))) for (const raw of x_lines(p.text)) {
    const line = raw.replace(/\s+/g, ' ');
    const ref = /\(\s*(?:[가-힣A-Za-z]{1,4}\.?\s*)?(\d\s?\d?\s?\d?)\s*[:：]\s*(\d\s?\d?\s?\d?)(?:\s*[-–~]\s*(\d\s?\d?\s?\d?))?[^)]*[)}\]]/.exec(line);
    const pg = /(\d[\d\s]{0,5})\s*[A-Za-z]?\s*$/.exec(line);
    if (!ref || !pg) continue;
    const num = (x) => Number(String(x).replace(/\s/g, ''));
    const n = /^\W*(\d{1,3})\s*[.,;:•]/.exec(line);
    entries.push({ n: n ? Number(n[1]) : null, c: num(ref[1]), a: num(ref[2]), z: ref[3] ? num(ref[3]) : num(ref[2]), printed: num(pg[1]), tocPage: p.page });
  }
  if (entries.length < 3) return { found: false, confidence: null, pages: [], verses: [] };
  // entry numbers lost by OCR come from their neighbours
  entries.forEach((e, i) => { if (e.n == null && i > 0 && entries[i - 1].n != null) e.n = entries[i - 1].n + 1; });
  const headPages = (n) => pages.filter((p) => new RegExp(`^\\W{0,3}${n}\\s*[.,;:•]`).test(p.text.split('\n')[0].trim())).map((p) => p.page);
  const hits = entries.map((e, i) => ({ ...e, i })).filter((e) => e.c === chap && e.z >= v1 && e.a <= v2 && e.n != null);
  const segments = [];
  for (const e of hits) {
    const hp = headPages(e.n);
    if (!hp.length) continue;
    const next = entries[e.i + 1];
    const nextHp = next?.n != null ? headPages(next.n) : [];
    const start = Math.max(1, hp[0] - 1); // the first page of a sermon often has no running header
    const end = nextHp.length ? nextHp[0] - 2 : hp.at(-1);
    segments.push({ n: e.n, ref: `${e.c}:${e.a}${e.z !== e.a ? `-${e.z}` : ''}`, start, end: Math.max(start, end) });
  }
  if (!segments.length) return { found: false, confidence: null, pages: [], verses: [] };
  // pages in verse order up to maxPages (a whole sermon first)
  const out = [];
  for (const sg of segments) for (let q = sg.start; q <= sg.end && out.length < maxPages; q++) out.push(q);
  const verses = [...new Set(hits.flatMap((e) => Array.from({ length: Math.min(e.z, v2) - Math.max(e.a, v1) + 1 }, (_, k) => Math.max(e.a, v1) + k)))].sort((a, b) => a - b);
  return { found: true, confidence: 'medium', via: 'toc', start: out[0], end: out.at(-1), verses, segments, truncated: segments.reduce((k, sg) => k + sg.end - sg.start + 1, 0) > out.length, pages: out };
}
const x_lines = (t) => t.split('\n');
/** Best of the page-run strategy and the table-of-contents strategy. */
export function locate(pages, passage, opts = {}) {
  const runs = locateRuns(pages, passage, opts);
  const onToc = runs.found && runs.pages.every((n) => TOC_PAGE(pages.find((p) => p.page === n)?.text ?? ''));
  if (runs.found && runs.confidence === 'high' && !onToc) return { ...runs, via: 'pages' };
  const toc = locateToc(pages, passage, opts);
  if (toc.found) return toc;
  return onToc ? { found: false, confidence: null, pages: [], verses: [], reason: 'only a table of contents mentions the passage' } : { ...runs, via: 'pages' };
}
/** Chapters a text discusses, for choosing the next volume: running headers ("요 16: 2" on a page's first line) when
 *  the book has them, else all bare "c:v" references; the middle 90% of what is seen. */
export function chaptersSeen(pages, bookId) {
  const C = book(bookId).chapters.length;
  const b = book(bookId);
  const named = new RegExp(`(?:^|[^가-힣A-Za-z])(?:${[b.name, ...b.abbrevs, EN[bookId - 1]].join('|')})\\.?\\s*$`);
  const own = [], heads = [], refs = [];
  for (const p of pages) p.text.split('\n').forEach((line, i) => {
    for (const m of line.matchAll(/(?<![\d:])(\d{1,3})\s*[:：]\s*\d{1,3}/g)) {
      const before = line.slice(Math.max(0, m.index - 14), m.index);
      if (OTHER_BOOK_BEFORE(before, bookId)) continue;
      const c = Number(m[1]);
      if (c < 1 || c > C) continue;
      if (i === 0 && named.test(before)) own.push(c); // "요 16: 2" running header names the book
      (i === 0 ? heads : refs).push(c);
    }
  });
  const [use, via] = own.length >= 10 ? [own, 'named headers'] : heads.length >= pages.length * 0.2 ? [heads, 'headers'] : [refs, 'references'];
  use.sort((x, y) => x - y);
  if (!use.length) return { min: null, max: null, via: null };
  return { min: use[Math.floor(use.length * 0.05)], max: use[Math.ceil(use.length * 0.95) - 1], via };
}

/** Rough token estimate (stated rule): Hangul syllable ≈ 1 token, other non-space characters ≈ 1/4 token each. */
export function estimateTokens(text) {
  const s = String(text);
  const hangul = (s.match(/[가-힣]/g) ?? []).length;
  const other = s.replace(/[가-힣\s]/g, '').length;
  return Math.ceil(hangul + other / 4);
}
export function pagesText(doc, range) {
  return doc.pages.filter((p) => range.includes(p.page)).map((p) => `[${p.page}쪽]\n${p.text}`).join('\n\n');
}

// ---------------------------------------------------------------- select
const CLASS_RANK = { R: 0, E: 1, N: 2 };
/** Doctrine class of a commentary (DOCTRINE.md §2 rules via check.mjs classOf; unknown author → E). */
export function commentaryClass(e) {
  const c = classOf({ author: e.author });
  const caution = blockMatches({ author: e.author, site: e.series }).filter((x) => x.level === 'caution');
  const seriesBlock = blockMatches({ author: e.series }).filter((x) => x.level === 'block');
  if (seriesBlock.length) return { doctrine: 'X', by: 'blocklist', detail: seriesBlock.map((x) => x.name).join(', ') };
  return { ...c, ...(caution.length ? { caution: caution.map((x) => x.name) } : {}) };
}
/** Volume sets ("요한복음(상)/(하)", "요한복음1/2") get an estimated range by their place in the set. */
function volumeEstimates(cands) {
  const sets = new Map();
  for (const c of cands) if (c.cov.volume) {
    const k = `${dirname(c.e.path)}\u0000${c.e.author ?? ''}\u0000${c.e.title.replace(/\s*\(?(상|중|하|\d)\)?\s*(ocr|OCR|clearscan_cropped)?.*$/, '').slice(0, 40)}`;
    if (!sets.has(k)) sets.set(k, []);
    sets.get(k).push(c);
  }
  for (const set of sets.values()) {
    const vols = [...new Set(set.map((c) => c.cov.volume))].sort((a, b) => a - b);
    // 상/하 without 중 is a two-volume set
    for (const c of set) {
      const n = vols.length, i = vols.indexOf(c.cov.volume);
      const C = book(c.bookId).chapters.length;
      c.est = n > 1 ? [Math.floor((i * C) / n) + 1, Math.ceil(((i + 1) * C) / n)] : null;
    }
  }
}
const sameWork = (a, b) => a.e.size === b.e.size || (a.e.author && a.e.author === b.e.author && a.e.series === b.e.series && JSON.stringify(a.cov) === JSON.stringify(b.cov));

/**
 * Rank commentaries for a passage. Step 1 from the catalog only (no file is opened): covers the chapter >
 * doctrine class (R, then E; X never) > Korean. Step 2 opens only the top `extract` distinct works: text over
 * scanned, located pages. Returns the ranked list and the top `top` with one-line reasons.
 */
export function select(cat, passageQ, { extract = 5, top = 3, ocr = false, maxMB = 200, extractFn = extractEntry } = {}) {
  const p = typeof passageQ === 'string' ? parsePassage(passageQ) : passageQ;
  const forBook = cat.entries.filter((e) => e.books.some((b) => b.id === p.bookId));
  const pdf = forBook.filter((e) => e.format === 'pdf');
  let cands = pdf.map((e) => ({ e, bookId: p.bookId, cov: e.books.find((b) => b.id === p.bookId), cls: commentaryClass(e) }));
  volumeEstimates(cands);
  for (const c of cands) {
    const ch = c.cov.chapters;
    c.covers = ch === 'all' ? (c.cov.how === 'all' ? 'whole' : 'whole-assumed') : Array.isArray(ch) ? (p.chap >= ch[0] && p.chap <= ch[1] ? 'range' : 'no') : c.est ? (p.chap >= c.est[0] && p.chap <= c.est[1] ? 'volume-estimated' : 'volume-other') : 'unknown';
  }
  const dropped = { blocked: cands.filter((c) => c.cls.doctrine === 'X').length, otherChapters: cands.filter((c) => c.covers === 'no' || c.covers === 'volume-other').length };
  cands = cands.filter((c) => c.cls.doctrine !== 'X' && c.covers !== 'no' && c.covers !== 'volume-other');
  // the name says (or the volume suggests) the chapter is inside: one tier; the pages are confirmed in step 2
  const COVER_RANK = { range: 0, whole: 0, 'volume-estimated': 0, 'whole-assumed': 0, unknown: 1 };
  const PRECISE = { range: 0, 'volume-estimated': 1, whole: 1, 'whole-assumed': 2, unknown: 3 };
  // smaller files first among equals: opening a file may download it from Drive
  const metaRank = (c) => [COVER_RANK[c.covers], CLASS_RANK[c.cls.doctrine] ?? 3, c.e.lang === 'ko' ? 0 : 1, PRECISE[c.covers], c.e.size, c.e.path];
  const cmp = (ka, kb) => { for (let i = 0; i < ka.length; i++) if (ka[i] !== kb[i]) return ka[i] < kb[i] ? -1 : 1; return 0; };
  cands.sort((a, b) => cmp(metaRank(a), metaRank(b)));
  // step 2: open only the first `extract` distinct works
  const opened = [];
  for (const c of cands) {
    if (opened.length >= extract) break;
    if (opened.some((o) => sameWork(o, c))) { c.skipped = 'same work as an opened file'; continue; }
    if (c.e.size > maxMB * 1e6) { c.skipped = `larger than ${maxMB} MB (download); --max-mb to allow`; continue; }
    const t0 = Date.now();
    try {
      const doc = extractFn(cat, c.e.key, { ocr });
      c.doc = { pageCount: doc.pageCount, textPages: doc.textPages, needsOcr: doc.needsOcr, cached: doc.cached, ms: Date.now() - t0 };
      c.loc = doc.needsOcr ? { found: false, confidence: null, pages: [], reason: 'scanned (needs OCR)' } : locate(doc.pages, p);
      if (!doc.needsOcr) c.chapters = chaptersSeen(doc.pages, p.bookId);
      if (c.loc.found) {
        const text = pagesText(doc, c.loc.pages);
        c.excerpt = { chars: [...text].length, tokens: estimateTokens(text) };
      }
    } catch (err) {
      c.doc = { error: String(err?.message ?? err).slice(0, 200), ...(err?.state ? { state: err.state } : {}), ms: Date.now() - t0 };
      c.loc = { found: false, confidence: null, pages: [] };
    }
    opened.push(c);
    // an estimated volume that does not hold the chapter: open the neighbouring volume of the same set instead
    if (c.covers === 'volume-estimated' && (!c.loc.found || c.loc.confidence === 'low') && c.doc && !c.doc.error && !c.doc.needsOcr && c.chapters?.min != null) {
      const dir = c.chapters.min > p.chap ? -1 : c.chapters.max < p.chap ? 1 : 0;
      const nb = dir && pdf.map((e) => ({ e, bookId: p.bookId, cov: e.books.find((b) => b.id === p.bookId), cls: c.cls }))
        .find((x) => x.e !== c.e && x.e.author === c.e.author && dirname(x.e.path) === dirname(c.e.path) && x.cov.volume === c.cov.volume + dir);
      if (nb) {
        nb.covers = 'volume-neighbour';
        nb.why = `${c.cov.volLabel}권은 ${c.chapters.min}-${c.chapters.max}장을 다룸`;
        const t1 = Date.now();
        try {
          const doc = extractFn(cat, nb.e.key, { ocr });
          nb.doc = { pageCount: doc.pageCount, textPages: doc.textPages, needsOcr: doc.needsOcr, cached: doc.cached, ms: Date.now() - t1 };
          nb.loc = doc.needsOcr ? { found: false, confidence: null, pages: [], reason: 'scanned (needs OCR)' } : locate(doc.pages, p);
          if (nb.loc.found) { const text = pagesText(doc, nb.loc.pages); nb.excerpt = { chars: [...text].length, tokens: estimateTokens(text) }; }
        } catch (err) {
          nb.doc = { error: String(err?.message ?? err).slice(0, 200), ms: Date.now() - t1 };
          nb.loc = { found: false, confidence: null, pages: [] };
        }
        opened.push(nb);
      }
    }
  }
  const CONF = { high: 0, medium: 1, low: 2 };
  const finalRank = (c) => [c.loc?.found ? (c.loc.confidence === 'low' ? 1 : 0) : 2, CLASS_RANK[c.cls.doctrine] ?? 3, c.doc?.needsOcr ? 1 : 0, c.e.lang === 'ko' ? 0 : 1, CONF[c.loc?.confidence] ?? 3, PRECISE[c.covers], c.e.size, c.e.path];
  opened.sort((a, b) => cmp(finalRank(a), finalRank(b)));
  const chosen = opened.filter((c) => c.loc?.found && c.loc.confidence !== 'low').slice(0, top);
  if (chosen.length < top) chosen.push(...opened.filter((c) => c.loc?.found && c.loc.confidence === 'low').slice(0, top - chosen.length));
  const reason = (c) => [
    `${c.cls.doctrine}(${c.cls.by === 'author' ? `${c.cls.detail}, authors.json` : c.e.author ? `${c.e.author}: authors.json에 없음 → E` : '저자 미상 → E'})`,
    c.covers === 'range' ? `이름에 ${c.cov.chapters[0]}-${c.cov.chapters[1]}장` : c.covers === 'volume-neighbour' ? `${c.cov.volLabel}권(옆 권: ${c.why})` : c.covers === 'volume-estimated' ? `${c.cov.volLabel}권 → ${c.est[0]}-${c.est[1]}장 추정` : c.covers.startsWith('whole') ? '한 권 전체' : '범위 미상',
    `${c.loc.start}-${c.loc.end}쪽(${c.loc.confidence}${c.loc.via === 'toc' ? `, 차례에서 ${c.loc.segments.map((sg) => sg.ref).join('·')}` : ''})`,
    c.doc.needsOcr ? '스캔본' : '글자 있는 PDF',
    c.e.lang === 'ko' ? '한국어' : '영어',
    ...(c.cls.doctrine === 'E' ? ['E: 사실·원어·배경에만, "비개혁주의 자료" 표시'] : []),
    ...(c.cls.caution ? [`경계: ${c.cls.caution.join(', ')}`] : []),
  ].join(' · ');
  const view = (c) => ({
    key: c.e.key, path: c.e.path, series: c.e.series, author: c.e.author, title: c.e.title, lang: c.e.lang, sizeMB: Math.round(c.e.size / 1e5) / 10,
    doctrine: c.cls.doctrine, by: c.cls.by, covers: c.covers, ...(c.est ? { estimated: c.est } : {}),
    ...(c.doc ? { doc: c.doc } : {}), ...(c.chapters ? { chaptersSeen: c.chapters } : {}),
    ...(c.loc ? { located: { found: c.loc.found, confidence: c.loc.confidence, via: c.loc.via, start: c.loc.start, end: c.loc.end, verses: c.loc.verses, ...(c.loc.segments ? { segments: c.loc.segments, truncated: c.loc.truncated } : {}), reason: c.loc.reason } } : {}),
    ...(c.excerpt ? { excerpt: c.excerpt } : {}), ...(c.skipped ? { skipped: c.skipped } : {}),
  });
  return {
    passage: p,
    counts: { bookEntries: forBook.length, bookPdf: pdf.length, bookPdfFiles: pdf.reduce((k, e) => k + 1 + e.dups.length, 0), duplicatesMerged: pdf.reduce((k, e) => k + e.dups.length, 0), coverChapter: cands.length, ...dropped, opened: opened.length },
    top: chosen.map((c) => ({ ...view(c), reason: reason(c) })),
    opened: opened.map(view),
    ranked: cands.map(view),
  };
}

// ---------------------------------------------------------------- quote verify + ledger
/** Is the quote on that page of that catalog file? Uses the cached extract (no file is opened here). */
export function verify(key, page, quote, opts) {
  const text = commentaryPageText(key, page, opts);
  if (text == null) return { status: 'unverifiable', reason: 'no extracted text for this file/page — run extract' };
  return quoteInPage(text, quote) ? { status: 'found' } : { status: 'not-found' };
}
/** Add a commentary source to a sermon ledger after the quote is found on its page. */
export function addCommentary(dir, { file, page, quote, claim }) {
  if (!CLAIMS.includes(claim)) throw new Error(`--claim required: ${CLAIMS.join(' | ')}`);
  if (quoteLength(quote) > QUOTE_MAX) throw new Error(`quote > ${QUOTE_MAX} chars`);
  const cat = loadCatalog();
  const e = entryOf(cat, file);
  const cls = commentaryClass(e);
  if (cls.doctrine === 'X') { const err = new Error(`refused: X (${cls.detail})`); err.code = 2; throw err; }
  if (!claimAllowed(cls.doctrine, claim)) { const err = new Error(`refused: a ${claim} claim cannot rest on a ${cls.doctrine} commentary`); err.code = 3; throw err; }
  const r = verify(file, Number(page), quote);
  const p = join(dir, 'sources.json');
  const ledger = existsSync(p) ? JSON.parse(readFileSync(p, 'utf8')) : { version: 1, sermon: basename(dir), sources: [] };
  const ns = ledger.sources.filter((s) => /^c\d+$/.test(s.id)).map((s) => Number(s.id.slice(1)));
  const s = {
    id: `c${ns.length ? Math.max(...ns) + 1 : 1}`, kind: 'commentary', author: e.author, title: e.title, series: e.series, file: e.key, page: Number(page),
    quote, status: r.status, claim, doctrine: cls.doctrine, doctrineBy: `${cls.by}: ${cls.detail}`, checkedAt: new Date().toISOString(),
  };
  ledger.sources.push(s);
  writeFileSync(p, JSON.stringify(ledger, null, 2) + '\n');
  return s;
}

// ---------------------------------------------------------------- the desktop app's local tool (host:sermon-sources)
/**
 * What to put in the Claude desktop app's config so a 설교준비 도우미 page can call this computer's commentary tool
 * (mcp/server.mjs, read-only). Printed only: this script never writes the app's config.
 */
export function mcpConfig({ platform = process.platform, node = process.execPath, home = homedir(), appData = process.env.APPDATA } = {}) {
  const server = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'mcp', 'server.mjs');
  const win = platform === 'win32';
  const file = win ? `${appData || `${home}\\AppData\\Roaming`}\\Claude\\claude_desktop_config.json` : platform === 'darwin' ? join(home, 'Library', 'Application Support', 'Claude', 'claude_desktop_config.json') : join(home, '.config', 'Claude', 'claude_desktop_config.json');
  return { file, snippet: { mcpServers: { 'sermon-sources': { command: node, args: [win ? server.replace(/\//g, '\\') : server] } } } };
}
export function mcpConfigText(c) {
  return [
    '설교준비 도우미에서 출처 확인을 바로 하려면 Claude 데스크톱 앱에 주석 도구를 한 번 등록해 주세요.',
    `1. 이 파일을 여세요(없으면 새로 만드세요): ${c.file}`,
    '2. 아래 내용을 넣으세요. 이미 "mcpServers"가 있으면 그 안에 "sermon-sources" 항목만 더하세요.',
    JSON.stringify(c.snippet, null, 2),
    '3. Claude 데스크톱 앱을 완전히 종료했다가 다시 여세요.',
    '이 도구는 주석을 읽기만 합니다. 이 스크립트는 앱 설정 파일을 직접 고치지 않습니다.',
  ].join('\n');
}

// ---------------------------------------------------------------- CLI
function flags(args) {
  const out = { _: [] };
  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--')) {
      const k = args[i].slice(2);
      const next = args[i + 1];
      if (next == null || next.startsWith('--')) out[k] = true;
      else { out[k] = next; i++; }
    } else out._.push(args[i]);
  }
  return out;
}
const print = (o) => console.log(JSON.stringify(o, null, 2));
// Windows PowerShell 5.1 decodes node's UTF-8 as CP949 by default; a typed command gets a hint on stderr (pipes, tests and the MCP server never see it).
const consoleHint = () => { if (process.platform === 'win32' && process.stdout.isTTY) console.error('(If Korean looks broken, run: chcp 65001)'); };
async function main(argv) {
  const [cmd, ...rest] = argv;
  const a = flags(rest);
  switch (cmd) {
    case 'library': {
      const [sub, arg] = a._;
      if (sub === 'add') { print(addLibrary(arg)); return 0; }
      if (sub === 'remove') { print(removeLibrary(arg)); return 0; }
      if (sub === 'list' || !sub) {
        const m = migrateLibraries();
        if (m) console.error(`registered the folder from the earlier catalog once: ${m.migrated} (library list / remove to change)`);
        print({ file: librariesPath(), ...(m ? { migratedOnce: m.migrated } : {}), libraries: listLibraries() });
        return 0;
      }
      console.error('usage: commentary.mjs library add <folder> | list | remove <folder|n>');
      return 2;
    }
    case 'mcp-config': { consoleHint(); console.log(mcpConfigText(mcpConfig())); return 0; }
    case 'doctor': {
      consoleHint();
      const rows = doctor({ libraries: listLibraries() });
      console.log(doctorText(rows));
      return rows.some((r) => r.ok === false) ? 1 : 0;
    }
    case 'catalog': {
      const c = scanLibrary(libraryRoots({ root: a.root }));
      // a scanned (image-only) PDF is known only when it is opened, so its share is not counted here
      print({ wrote: catalogPath(), ms: c.ms, ...c.stats, perLibrary: c.perLibrary, scanned: 'unknown until a book is opened' });
      return 0;
    }
    case 'select': { print(select(loadCatalog(), a._[0], { extract: Number(a.extract ?? 5), top: Number(a.top ?? 3), ocr: !!a.ocr, maxMB: Number(a['max-mb'] ?? 200) })); return 0; }
    case 'extract': {
      const d = extractEntry(loadCatalog(), a._[0], { ocr: !!a.ocr });
      print({ key: d.key, engine: d.engine, ocr: d.ocr, pageCount: d.pageCount, textPages: d.textPages, needsOcr: d.needsOcr, chars: d.chars, cached: d.cached, ms: d.ms });
      return 0;
    }
    case 'locate': {
      const cat = loadCatalog();
      const d = extractEntry(cat, a._[0], { ocr: !!a.ocr });
      const p = parsePassage(a._[1]);
      const loc = d.needsOcr ? { found: false, reason: 'scanned (needs OCR) — run with --ocr' } : locate(d.pages, p, { maxPages: Number(a['max-pages'] ?? 20) });
      if (!loc.found) { print({ passage: p.label, ...loc }); return 1; }
      const text = pagesText(d, loc.pages);
      // the pages' text goes to stdout for Claude to read; the JSON summary goes to stderr
      console.error(JSON.stringify({ passage: p.label, ...loc, chars: [...text].length, tokens: estimateTokens(text) }));
      console.log(text);
      return 0;
    }
    case 'verify': { const r = verify(a._[0], Number(a._[1]), a._[2]); print(r); return r.status === 'found' ? 0 : 1; }
    case 'add': { const s = addCommentary(a._[0], { file: a.file, page: a.page, quote: a.quote, claim: a.claim }); print(s); return s.status === 'found' ? 0 : 1; }
    default:
      console.error('usage: commentary.mjs doctor | mcp-config | library add|list|remove | catalog | select <passage> | extract <key> [--ocr] | locate <key> <passage> | verify <key> <page> <quote> | add <dir> --file <key> --page <n> --quote <q> --claim <c>');
      return 2;
  }
}
const isMain = (() => { try { return !!process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url)); } catch { return false; } })();
if (isMain) main(process.argv.slice(2)).then((c) => process.exit(c), (e) => { console.error(String(e?.message ?? e)); process.exit(e?.code ?? 1); });
