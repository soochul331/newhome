// Page-wise text of one PDF with macOS PDFKit; optional OCR with the Vision framework (ko + en).
//   pdftext <in.pdf> <out.json> [--ocr] [--first N] [--last M]   (text pages come from pdftext.mjs; this tool does OCR)
//   pdftext --materialize <file>      download an online-only Drive file (this process only), print its size
//   pdftext --langs                   Vision recognition languages, one per line
// Output: {"pageCount":N,"ocr":false,"pages":[{"page":1,"chars":123,"text":"..."}]}
// Reads the file only; never writes next to it. An online-only Drive file is downloaded on open (this process only).
import Foundation
import PDFKit
import Vision
import CoreGraphics

var args = Array(CommandLine.arguments.dropFirst())
func flag(_ name: String) -> Bool { if let i = args.firstIndex(of: name) { args.remove(at: i); return true }; return false }
func opt(_ name: String) -> Int? {
  guard let i = args.firstIndex(of: name), i + 1 < args.count, let v = Int(args[i + 1]) else { return nil }
  args.removeSubrange(i...(i + 1)); return v
}
let materialize = flag("--materialize")
let listLangs = flag("--langs")
if listLangs {
  let req = VNRecognizeTextRequest()
  req.recognitionLevel = .accurate
  print(((try? req.supportedRecognitionLanguages()) ?? []).joined(separator: "\n"))
  exit(0)
}
let useOCR = flag("--ocr")
let firstOpt = opt("--first")
let lastOpt = opt("--last")
// Drive "online-only" (dataless) files: allow this process — only this process — to download a file on read.
// setiopolicy_np(IOPOL_TYPE_VFS_MATERIALIZE_DATALESS_FILES = 3, IOPOL_SCOPE_PROCESS = 0, IOPOL_MATERIALIZE_DATALESS_FILES_ON = 2)
_ = setiopolicy_np(3, 0, 2)
if materialize {
  guard args.count == 1, let h = FileHandle(forReadingAtPath: args[0]) else {
    FileHandle.standardError.write("cannot read file\n".data(using: .utf8)!); exit(1)
  }
  var total = 0
  while true { let d = h.readData(ofLength: 1 << 20); if d.isEmpty { break }; total += d.count }
  print(total)
  exit(0)
}
guard args.count == 2 else {
  FileHandle.standardError.write("usage: pdftext <in.pdf> <out.json> [--ocr] [--first N] [--last M]\n".data(using: .utf8)!)
  exit(2)
}
let input = URL(fileURLWithPath: args[0])
let output = URL(fileURLWithPath: args[1])
guard let doc = PDFDocument(url: input) else {
  FileHandle.standardError.write("cannot open PDF\n".data(using: .utf8)!)
  exit(1)
}
if doc.isLocked { FileHandle.standardError.write("locked PDF\n".data(using: .utf8)!); exit(1) }

func ocr(_ page: PDFPage) -> String {
  let box = page.bounds(for: .mediaBox)
  let scale: CGFloat = 2.0
  let w = Int(box.width * scale), h = Int(box.height * scale)
  guard w > 0, h > 0, let ctx = CGContext(data: nil, width: w, height: h, bitsPerComponent: 8, bytesPerRow: 0,
    space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else { return "" }
  ctx.setFillColor(CGColor(red: 1, green: 1, blue: 1, alpha: 1))
  ctx.fill(CGRect(x: 0, y: 0, width: w, height: h))
  ctx.scaleBy(x: scale, y: scale)
  page.draw(with: .mediaBox, to: ctx)
  guard let img = ctx.makeImage() else { return "" }
  let req = VNRecognizeTextRequest()
  req.recognitionLevel = .accurate
  req.recognitionLanguages = ["ko-KR", "en-US"]
  req.usesLanguageCorrection = true
  try? VNImageRequestHandler(cgImage: img, options: [:]).perform([req])
  return (req.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
}

let n = doc.pageCount
let first = max(1, firstOpt ?? 1)
let last = min(n, lastOpt ?? n)
var pages: [[String: Any]] = []
if first <= last {
  for i in (first - 1)...(last - 1) {
    guard let p = doc.page(at: i) else { continue }
    let text = useOCR ? ocr(p) : (p.string ?? "")
    pages.append(["page": i + 1, "chars": text.count, "text": text])
  }
}
let out: [String: Any] = ["pageCount": n, "ocr": useOCR, "pages": pages]
let data = try JSONSerialization.data(withJSONObject: out, options: [])
try data.write(to: output)
