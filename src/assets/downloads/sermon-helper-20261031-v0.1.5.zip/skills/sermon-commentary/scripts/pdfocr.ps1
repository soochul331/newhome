# Text recognition (OCR) for scanned PDFs on Windows 10/11 with built-in Windows parts only:
# Windows.Data.Pdf renders each page, Windows.Media.Ocr reads it (Korean engine; it also reads Latin letters).
# Run with Windows PowerShell 5.1 (powershell.exe), not PowerShell 7: these are WinRT types.
#   powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File pdfocr.ps1 -In <in.pdf> -Out <out.json> [-First N] [-Last M]
#   powershell.exe ... -File pdfocr.ps1 -Langs -Out <out.json>      # which OCR languages this PC has
# Output (same shape as pdftext.swift / pdftext.mjs): {"pageCount":N,"ocr":true,"engine":"windows-ocr","pages":[{"page":1,"chars":12,"text":"..."}]}
# Exit 3 with "korean-ocr-missing" on stderr when the Korean OCR language pack is not installed. Nothing is ever installed here.
# Reads the PDF only. Google Drive / OneDrive files that live only in the cloud are downloaded by Windows when read.
param(
  [string]$In = '',
  [Parameter(Mandatory = $true)][string]$Out,
  [int]$First = 1,
  [int]$Last = 0,
  [switch]$Langs
)
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding $false
function Write-Json($obj) { [System.IO.File]::WriteAllText($Out, ($obj | ConvertTo-Json -Depth 5 -Compress), $utf8) }

Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Data.Pdf.PdfDocument, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Data.Pdf.PdfPageRenderOptions, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.StorageFile, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Foundation, ContentType = WindowsRuntime]

# WinRT async -> .NET Task (the usual Windows PowerShell pattern)
$ext = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 }
$asTaskOp = $ext | Where-Object { $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
$asTaskAction = $ext | Where-Object { $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction' } | Select-Object -First 1
function Await($op, [Type]$type) { $t = $asTaskOp.MakeGenericMethod($type).Invoke($null, @($op)); $null = $t.Wait(-1); $t.Result }
function AwaitAction($op) { $t = $asTaskAction.Invoke($null, @($op)); $null = $t.Wait(-1) }

$tags = @([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages | ForEach-Object { $_.LanguageTag })
if ($Langs) { Write-Json @{ languages = $tags; maxImageDimension = [Windows.Media.Ocr.OcrEngine]::MaxImageDimension }; exit 0 }
if (-not $In) { [Console]::Error.WriteLine('usage: pdfocr.ps1 -In <in.pdf> -Out <out.json> [-First N] [-Last M] | -Langs -Out <out.json>'); exit 2 }

$ko = New-Object Windows.Globalization.Language 'ko'
if (-not [Windows.Media.Ocr.OcrEngine]::IsLanguageSupported($ko)) { [Console]::Error.WriteLine('korean-ocr-missing'); exit 3 }
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($ko)
if ($null -eq $engine) { [Console]::Error.WriteLine('korean-ocr-missing'); exit 3 }
$max = [double][Windows.Media.Ocr.OcrEngine]::MaxImageDimension

try {
  $path = (Resolve-Path -LiteralPath $In).ProviderPath
  $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
  $pdf = Await ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument])
} catch {
  [Console]::Error.WriteLine("cannot open PDF: $($_.Exception.Message)"); exit 1
}
$n = [int]$pdf.PageCount
if ($Last -le 0 -or $Last -gt $n) { $Last = $n }
if ($First -lt 1) { $First = 1 }
$pages = New-Object System.Collections.ArrayList
for ($i = $First; $i -le $Last; $i++) {
  $page = $pdf.GetPage([uint32]($i - 1))
  # about 2x the page size, kept inside what the OCR engine accepts
  $w = [double]$page.Size.Width; $h = [double]$page.Size.Height
  $scale = [Math]::Min(2.0, [Math]::Min($max / [Math]::Max($w, 1), $max / [Math]::Max($h, 1)))
  $opts = New-Object Windows.Data.Pdf.PdfPageRenderOptions
  $opts.DestinationWidth = [uint32][Math]::Floor($w * $scale)
  $opts.DestinationHeight = [uint32][Math]::Floor($h * $scale)
  $stream = New-Object Windows.Storage.Streams.InMemoryRandomAccessStream
  AwaitAction ($page.RenderToStreamAsync($stream, $opts))
  $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
  $text = (@($result.Lines | ForEach-Object { $_.Text }) -join "`n")
  $null = $pages.Add(@{ page = $i; chars = $text.Length; text = $text })
  $bitmap.Dispose(); $stream.Dispose(); $page.Dispose()
}
Write-Json @{ pageCount = $n; ocr = $true; engine = 'windows-ocr'; pages = $pages }
exit 0
