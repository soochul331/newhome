#!/usr/bin/env node
// Page-wise text of one PDF on any OS (Windows, macOS, Linux) with the vendored pdf.js (no network, no install).
//   node pdftext.mjs <in.pdf> <out.json> [--first N] [--last M]
// Output (same shape as pdftext.swift): {"pageCount":N,"ocr":false,"engine":"pdfjs-4.8.69","pages":[{"page":1,"chars":123,"text":"..."}]}
// Reads the file only; never writes next to it. Scanned pages come out empty (OCR is a separate, per-OS tool).
import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export const PDFJS_VERSION = '4.8.69';
export const PDFJS_DIR = join(dirname(fileURLToPath(import.meta.url)), '..', 'vendor', `pdfjs-dist-${PDFJS_VERSION}`);

let lib = null;
async function pdfjs() {
  if (lib) return lib;
  lib = await import(pathToFileURL(join(PDFJS_DIR, 'pdf.min.mjs')).href);
  lib.GlobalWorkerOptions.workerSrc = pathToFileURL(join(PDFJS_DIR, 'pdf.worker.min.mjs')).href;
  return lib;
}
/** Text of pages first..last; a line break where pdf.js marks the end of a line. */
export async function pdfText(bytes, { first = 1, last = Infinity } = {}) {
  const p = await pdfjs();
  const doc = await p.getDocument({
    data: new Uint8Array(bytes), cMapUrl: join(PDFJS_DIR, 'cmaps') + '/', cMapPacked: true, // Korean CID fonts need the CMaps
    isEvalSupported: false, disableFontFace: true, useSystemFonts: false, verbosity: p.VerbosityLevel.ERRORS,
  }).promise;
  try {
    const pages = [];
    for (let i = Math.max(1, first); i <= Math.min(doc.numPages, last); i++) {
      const page = await doc.getPage(i);
      const tc = await page.getTextContent();
      const text = tc.items.map((it) => (it.str ?? '') + (it.hasEOL ? '\n' : '')).join('');
      pages.push({ page: i, chars: [...text].length, text });
      page.cleanup();
    }
    return { pageCount: doc.numPages, ocr: false, engine: `pdfjs-${PDFJS_VERSION}`, pages };
  } finally {
    await doc.destroy();
  }
}

const isMain = (() => { try { return !!process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url)); } catch { return false; } })();
if (isMain) {
  const args = process.argv.slice(2);
  const num = (k) => { const i = args.indexOf(k); if (i < 0) return undefined; const v = Number(args[i + 1]); args.splice(i, 2); return v; };
  const first = num('--first') ?? 1, last = num('--last') ?? Infinity;
  if (args.length !== 2) { process.stderr.write('usage: pdftext.mjs <in.pdf> <out.json> [--first N] [--last M]\n'); process.exit(2); }
  let bytes;
  try { bytes = readFileSync(args[0]); } catch (e) { process.stderr.write(`cannot read file: ${e.code ?? e.message}\n`); process.exit(1); }
  pdfText(bytes, { first, last }).then(
    (out) => { writeFileSync(args[1], JSON.stringify(out)); process.exit(0); },
    (e) => { process.stderr.write(`${/password/i.test(String(e?.name ?? e)) ? 'locked PDF' : 'cannot open PDF'}: ${String(e?.message ?? e).split('\n')[0]}\n`); process.exit(1); },
  );
}
