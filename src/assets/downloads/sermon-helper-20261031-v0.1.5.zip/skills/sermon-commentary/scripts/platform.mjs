// sermon-commentary — what differs per operating system, in one place. Everything here takes {platform, run, …}
// so tests can play Windows on a Mac. Nothing is installed: missing parts are reported with how to add them.
//   text PDFs  : pdftext.mjs (vendored pdf.js) on every OS — same page shape everywhere
//   scanned    : macOS Vision (pdftext.swift --ocr) · Windows.Media.Ocr (pdfocr.ps1) · other systems: not supported
//   cloud files: macOS Drive 'online-only' files are downloaded by pdftext.swift --materialize (per-process iopolicy,
//                macOS only); Windows (Google Drive for desktop, OneDrive Files On-Demand) downloads a file when read.
import { readFileSync, existsSync, mkdirSync, writeFileSync, readdirSync, statSync, mkdtempSync, rmSync } from 'node:fs';
import { join, dirname, posix, win32 } from 'node:path';
import { tmpdir, homedir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const HERE = dirname(fileURLToPath(import.meta.url));
export const PDFTEXT_JS = join(HERE, 'pdftext.mjs');
export const PDFOCR_PS1 = join(HERE, 'pdfocr.ps1');
export const SWIFT = join(HERE, 'pdftext.swift');
export const VENDOR = join(HERE, '..', 'vendor', 'pdfjs-dist-4.8.69');
const sha = (b, n = 12) => createHash('sha1').update(b).digest('hex').slice(0, n);

/** run(cmd, args, opts) -> {status, stdout, stderr}; never throws (a missing program gives status null + error). */
export function defaultRun(cmd, args, opts = {}) {
  const r = spawnSync(cmd, args, { encoding: 'utf8', maxBuffer: 1 << 26, windowsHide: true, ...opts });
  return { status: r.status, stdout: r.stdout ?? '', stderr: r.stderr ?? '', error: r.error ? String(r.error.code ?? r.error.message) : null };
}
const ctx = (o = {}) => ({ platform: o.platform ?? process.platform, run: o.run ?? defaultRun, home: o.home ?? homedir() });
export const OS_NAME = { darwin: 'macOS', win32: 'Windows', linux: 'Linux' };

// ---------------------------------------------------------------- folders
/**
 * A folder the user typed or pasted, made absolute for that OS: quotes trimmed, ~ expanded, NFC.
 * Windows: drive letters (C:\…, G:\내 드라이브\…) and UNC shares (\\server\share\…) are kept as Windows paths.
 */
export function folderPath(input, o = {}) {
  const { platform, home } = ctx(o);
  const P = platform === 'win32' ? win32 : posix;
  let s = String(input ?? '').trim().replace(/^(['"])(.*)\1$/, '$2').normalize('NFC');
  if (s === '~' || s.startsWith('~/') || s.startsWith('~\\')) s = P.join(home, s.slice(1));
  return (o.cwd ? P.resolve(o.cwd, s) : P.resolve(s)).normalize('NFC');
}

// ---------------------------------------------------------------- cloud placeholders
const WIN_OFFLINE = 0x1000, WIN_RECALL_ON_OPEN = 0x40000, WIN_RECALL_ON_DATA_ACCESS = 0x400000;
/** 'online-only' when the file lives only in the cloud (macOS dataless flag; Windows offline / recall attributes). */
export function localState(absPath, o = {}) {
  const { platform, run } = ctx(o);
  if (platform === 'darwin') {
    const r = run('stat', ['-f', '%Sf', absPath]);
    return r.status === 0 ? (/dataless/.test(r.stdout) ? 'online-only' : 'local') : 'unknown';
  }
  if (platform === 'win32') {
    const r = run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `[int](Get-Item -LiteralPath '${absPath.replace(/'/g, "''")}' -Force).Attributes`]);
    const a = Number(String(r.stdout).trim());
    if (r.status !== 0 || !Number.isFinite(a)) return 'unknown';
    return a & (WIN_OFFLINE | WIN_RECALL_ON_OPEN | WIN_RECALL_ON_DATA_ACCESS) ? 'online-only' : 'local';
  }
  return 'unknown';
}
export const CLOUD_HELP = {
  darwin: '클라우드에만 있는 파일을 내려받지 못했어요. Finder에서 그 파일을 한 번 열거나 \'오프라인으로 사용 가능\'으로 바꾼 뒤 다시 해 주세요.',
  win32: '클라우드에만 있는 파일을 내려받지 못했어요. 탐색기에서 그 파일을 한 번 열거나(구글 드라이브: \'오프라인으로 사용 가능\', OneDrive: \'항상 이 디바이스에 유지\') 인터넷 연결을 확인한 뒤 다시 해 주세요.',
};

// ---------------------------------------------------------------- tools
export function swiftTool(o = {}) {
  const { run } = ctx(o);
  const binDir = process.env.SERMON_COMMENTARY_BIN || join(HERE, '..', '..', '..', '.local', 'commentary', 'bin');
  const bin = join(binDir, `pdftext-${sha(readFileSync(SWIFT))}`);
  if (existsSync(bin)) return bin;
  mkdirSync(binDir, { recursive: true });
  const r = run('swiftc', ['-O', SWIFT, '-o', bin]);
  if (r.status !== 0) { const e = new Error('macOS 글자 인식 도구를 만들지 못했어요(swiftc 없음). 터미널에서 xcode-select --install 로 개발자 도구를 설치하면 돼요.'); e.code = 'swift-missing'; throw e; }
  return bin;
}
export const OCR_HELP = {
  win32: [
    'Windows에 한국어 글자 인식(OCR) 언어 팩이 없어요. 스캔한 PDF를 읽으려면 한 번 추가해 주세요(자동으로 설치하지 않아요):',
    '  1) 설정 → 시간 및 언어 → 언어 및 지역 → \'언어 추가\'에서 한국어를 추가하면 함께 설치돼요.',
    '  2) 또는 관리자 권한 Windows PowerShell에서:',
    "     Get-WindowsCapability -Online | Where-Object { $_.Name -Like 'Language.OCR*ko-KR*' } | Add-WindowsCapability -Online",
    '  설치 뒤 다시 \'주석 도구 점검해 줘\'라고 말씀해 주세요.',
  ].join('\n'),
  other: '이 운영체제에서는 스캔한 PDF의 글자 인식을 아직 지원하지 않아요. 글자가 들어 있는 PDF는 읽을 수 있어요.',
};
const PS = (args) => ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', PDFOCR_PS1, ...args];

/**
 * Page text of one PDF into outJson ({pageCount, ocr, engine, pages: [{page, chars, text}]}), per OS.
 * Throws an Error with .code: 'cannot-open' | 'online-only' | 'korean-ocr-missing' | 'ocr-unsupported' | 'swift-missing'.
 */
export function runExtract(absPath, outJson, { ocr = false, first, last, ...o } = {}) {
  const c = ctx(o);
  const range = (f, l, a, b) => [...(first ? [f, String(first)] : []), ...(last ? [l, String(last)] : [])].concat(a ?? [], b ?? []);
  const fail = (code, msg, extra = {}) => Object.assign(new Error(msg), { code, ...extra });
  if (!ocr && c.platform === 'darwin' && localState(absPath, c) === 'online-only') {
    const r = c.run(swiftTool(c), ['--materialize', absPath]);
    if (r.status !== 0) throw fail('online-only', CLOUD_HELP.darwin, { state: 'online-only' });
  }
  let r;
  if (!ocr) r = c.run(o.node ?? process.execPath, [PDFTEXT_JS, absPath, outJson, ...range('--first', '--last')]);
  else if (c.platform === 'darwin') r = c.run(swiftTool(c), [absPath, outJson, '--ocr', ...range('--first', '--last')]);
  else if (c.platform === 'win32') {
    r = c.run('powershell.exe', PS(['-In', absPath, '-Out', outJson, ...range('-First', '-Last')]));
    if (r.status === 3 || /korean-ocr-missing/.test(r.stderr)) throw fail('korean-ocr-missing', OCR_HELP.win32);
  } else throw fail('ocr-unsupported', OCR_HELP.other);
  if (r.status !== 0) {
    const why = String(r.stderr || r.error || '').trim().split('\n').at(-1) || 'extract failed';
    const state = localState(absPath, c);
    if (state === 'online-only') throw fail('online-only', CLOUD_HELP[c.platform] ?? why, { state });
    throw fail('cannot-open', why, { state });
  }
  const raw = JSON.parse(readFileSync(outJson, 'utf8').replace(/^\uFEFF/, ''));
  return { ...raw, engine: raw.engine ?? (ocr ? 'vision' : 'pdfkit') };
}

// ---------------------------------------------------------------- self-test (commentary.mjs doctor)
/** A one-page PDF with the line "John 15:1 doctor test" (Helvetica), made here: nothing is downloaded. */
export function samplePdf() {
  const text = 'BT /F1 18 Tf 72 720 Td (John 15:1 doctor test) Tj ET';
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>',
    `<< /Length ${text.length} >>\nstream\n${text}\nendstream`,
  ];
  let out = '%PDF-1.4\n';
  const offs = [];
  objs.forEach((o, i) => { offs.push(out.length); out += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = out.length;
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n${offs.map((n) => `${String(n).padStart(10, '0')} 00000 n \n`).join('')}`;
  out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(out, 'latin1');
}
/** sha256 of every vendored file equals VENDOR.json (catches a broken copy). */
export function vendorCheck(dir = VENDOR) {
  const p = join(dir, 'VENDOR.json');
  if (!existsSync(p)) return { ok: false, detail: 'VENDOR.json 없음' };
  const v = JSON.parse(readFileSync(p, 'utf8'));
  const bad = Object.entries(v.files).filter(([f, h]) => !existsSync(join(dir, f)) || createHash('sha256').update(readFileSync(join(dir, f))).digest('hex') !== h).map(([f]) => f);
  return { ok: bad.length === 0, version: v.version, bad };
}
/**
 * Plain Korean checks: [{name, ok: true | false | 'warn', detail}]. Essential = Node + PDF text tool.
 * deps: {platform, run, nodeVersion, libraries: [{path, exists}], node}
 */
export function doctor(o = {}) {
  const c = ctx(o);
  const out = [];
  const add = (name, ok, detail) => out.push({ name, ok, detail });
  const nv = o.nodeVersion ?? process.versions.node;
  const major = Number(String(nv).split('.')[0]);
  add('Node.js', major >= 18, major >= 18 ? `${nv} — 됩니다` : `${nv} — 18 이상이 필요해요. https://nodejs.org 에서 LTS 버전을 설치해 주세요.`);
  add('운영체제', c.platform === 'darwin' || c.platform === 'win32' ? true : 'warn', `${OS_NAME[c.platform] ?? c.platform}${c.platform === 'darwin' || c.platform === 'win32' ? '' : ' — 글자가 들어 있는 PDF만 읽어요(글자 인식은 지원하지 않아요)'}`);
  const v = vendorCheck();
  if (!v.ok) add('PDF 글자 읽기 도구', false, `pdf.js 파일이 온전하지 않아요(${v.detail ?? v.bad.join(', ')}). 스킬을 다시 설치해 주세요.`);
  else {
    const dir = mkdtempSync(join(tmpdir(), 'commentary-doctor-'));
    try {
      const pdf = join(dir, 'sample.pdf'), json = join(dir, 'sample.json');
      writeFileSync(pdf, samplePdf());
      let r;
      try { r = runExtract(pdf, json, { ...c, node: o.node }); } catch (e) { r = { error: e.message }; }
      const okText = !!r?.pages?.[0]?.text?.includes('John 15:1 doctor test');
      add('PDF 글자 읽기 도구', okText, okText ? `pdf.js ${v.version} — 시험용 PDF의 글자를 읽었어요` : `시험용 PDF를 읽지 못했어요: ${r?.error ?? '글자가 다름'}`);
    } finally { rmSync(dir, { recursive: true, force: true }); }
  }
  if (c.platform === 'darwin') {
    let detail, ok;
    try {
      const r = c.run(swiftTool(c), ['--langs']);
      const langs = r.stdout.split('\n').map((s) => s.trim()).filter(Boolean);
      ok = langs.includes('ko-KR') ? true : 'warn';
      detail = ok === true ? 'macOS Vision — 한국어·영어 글자 인식이 돼요' : 'macOS Vision에 한국어 글자 인식이 없어요(macOS 13 이상에서 돼요). 스캔한 PDF는 읽기 어려워요.';
    } catch (e) { ok = 'warn'; detail = e.message; }
    add('스캔한 PDF 글자 인식', ok, detail);
  } else if (c.platform === 'win32') {
    const dir = mkdtempSync(join(tmpdir(), 'commentary-doctor-'));
    try {
      const json = join(dir, 'langs.json');
      const r = c.run('powershell.exe', PS(['-Langs', '-Out', json]));
      if (r.status !== 0 || !existsSync(json)) add('스캔한 PDF 글자 인식', 'warn', `Windows 글자 인식을 확인하지 못했어요(${String(r.stderr || r.error || '').trim().split('\n').at(-1) || 'PowerShell 오류'}). 글자가 들어 있는 PDF는 읽을 수 있어요.`);
      else {
        const langs = JSON.parse(readFileSync(json, 'utf8').replace(/^\uFEFF/, '')).languages ?? [];
        const ko = langs.some((t) => /^ko(-|$)/i.test(t)), en = langs.some((t) => /^en(-|$)/i.test(t));
        add('스캔한 PDF 글자 인식', ko ? true : 'warn', ko ? `Windows 글자 인식 — 한국어${en ? '·영어' : ''} 돼요` : OCR_HELP.win32);
      }
    } finally { rmSync(dir, { recursive: true, force: true }); }
  } else add('스캔한 PDF 글자 인식', 'warn', OCR_HELP.other);
  const libs = o.libraries ?? [];
  if (!libs.length) add('연결한 주석 폴더', 'warn', "아직 없어요. Claude Code에 '내 주석 폴더는 <폴더 경로>야. 연결해 줘'라고 말씀해 주세요.");
  for (const l of libs) {
    if (!l.exists) { add('연결한 주석 폴더', false, `${l.path} — 폴더를 찾지 못했어요(드라이브 연결·이름 변경을 확인해 주세요)`); continue; }
    try { const { files, pdfs } = countFiles(l.path); add('연결한 주석 폴더', true, `${l.path} — 파일 ${files}개, PDF ${pdfs}개`); } catch (e) { add('연결한 주석 폴더', false, `${l.path} — 읽지 못했어요(${e.code ?? e.message})`); }
  }
  return out;
}
/** Files and PDFs under a connected folder (hidden names skipped, 8 levels deep); throws when the folder cannot be read. */
export function countFiles(dir) {
  let pdfs = 0, files = 0;
  const walk = (d, depth) => { for (const n of readdirSync(d)) { if (n.startsWith('.')) continue; const p = join(d, n); let st; try { st = statSync(p); } catch { continue; } if (st.isDirectory()) { if (depth < 8) walk(p, depth + 1); } else { files++; if (/\.pdf$/i.test(n)) pdfs++; } } };
  walk(dir, 0);
  return { files, pdfs };
}
export function doctorText(rows) {
  const mark = (ok) => (ok === true ? '✓' : ok === false ? '✗' : '!');
  const lines = rows.map((r) => `${mark(r.ok)} ${r.name}: ${r.detail}`);
  const bad = rows.filter((r) => r.ok === false).length, warn = rows.filter((r) => r.ok === 'warn').length;
  lines.push(bad ? `→ 고칠 것이 ${bad}가지 있어요.` : warn ? `→ 주석 읽기는 돼요. 확인할 것 ${warn}가지가 있어요.` : '→ 모두 정상이에요.');
  return lines.join('\n');
}
