#!/usr/bin/env node
// Minimal local MCP server (stdio, newline-delimited JSON-RPC) exposing the
// commentary tools read-only, so a 설교준비 도우미 page opened in the Claude
// desktop app can call them as `host:sermon-sources`. The library is never
// written to and no AI is called: status/select shell out to commentary.mjs,
// pages/verify read the extract cache (a page is extracted on demand, with the
// same cloud-file handling as commentary.mjs). web-pages/web-verify read the
// listed online commentaries (sermon-sources/scripts/web.mjs: built URLs only,
// no search, no link following). web-search/web-read search the web through NAVER
// API HUB (sermon-sources/scripts/websearch.mjs; keys from .env.local, never sent out).
//   node server.mjs        (the Claude desktop app starts it; see docs/INSTALL-ko.md)
import { execFile } from 'node:child_process';
import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';
import { realpathSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { homedir } from 'node:os';

const CLI = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'scripts', 'commentary.mjs');
const RO = { readOnlyHint: true, openWorldHint: false };
const WEB_RO = { readOnlyHint: true, openWorldHint: true }; // reads public pages of the listed hosts
/** At most this many pages and characters go back from one `pages` call (the page reads a small budget). */
export const PAGES_MAX = 6;
export const CHARS_MAX = 16000;
export const QUOTE_MAX = 300;

export const TOOLS = [
  { name: 'status', description: 'Check that the commentary tools work on this computer (Node, pdf.js, OCR, library folders).', inputSchema: { type: 'object', properties: {} }, annotations: RO },
  { name: 'select', description: 'Pick the commentaries and page ranges for a passage, e.g. "요한복음 15:1-11". Local only, no AI.', inputSchema: { type: 'object', properties: { passage: { type: 'string' } }, required: ['passage'] }, annotations: RO },
  { name: 'pages', description: `Text of pages from..to of one catalog file (at most ${PAGES_MAX} pages, ${CHARS_MAX} characters), with its author, title and doctrine class. Extracts the file on demand. Local only, no AI.`, inputSchema: { type: 'object', properties: { key: { type: 'string' }, from: { type: 'integer', minimum: 1 }, to: { type: 'integer', minimum: 1 } }, required: ['key', 'from', 'to'] }, annotations: RO },
  { name: 'verify', description: `Is this quote (at most ${QUOTE_MAX} characters) on that page of that catalog file? Exact or whitespace-normalized match on the extracted text. Local only, no AI.`, inputSchema: { type: 'object', properties: { key: { type: 'string' }, page: { type: 'integer', minimum: 1 }, quote: { type: 'string' } }, required: ['key', 'page', 'quote'] }, annotations: RO },
  { name: 'web-pages', description: 'Text of the listed online commentaries (Bible Hub) for a passage\'s chapter, e.g. "시편 127:1-5": built URLs only, no search, at most 4 pages and 24,000 characters, R authors first. No AI.', inputSchema: { type: 'object', properties: { passage: { type: 'string' }, ids: { type: 'array', items: { type: 'string' } } }, required: ['passage'] }, annotations: WEB_RO },
  { name: 'web-verify', description: `Is this quote (at most ${QUOTE_MAX} characters) in the text of that page? Only URLs web-pages built or web-search returned. No AI.`, inputSchema: { type: 'object', properties: { url: { type: 'string' }, quote: { type: 'string' } }, required: ['url', 'quote'] }, annotations: WEB_RO },
  { name: 'web-search', description: 'Search the web (NAVER API HUB) on this computer: news, web pages, blogs or the encyclopedia. Blocklisted sites and 개역한글 links are dropped; each result carries its site tier and doctrine class. At most 10 results. No AI.', inputSchema: { type: 'object', properties: { query: { type: 'string' }, kind: { type: 'string', enum: ['news', 'web', 'blog', 'encyc'] }, count: { type: 'integer', minimum: 1, maximum: 10 }, recentDays: { type: 'integer', minimum: 1 } }, required: ['query', 'kind'] }, annotations: WEB_RO },
  { name: 'web-read', description: 'Text of a page web-search or web-pages returned (at most 12,000 characters). Blocklisted sites and 개역한글 links refused. No AI.', inputSchema: { type: 'object', properties: { url: { type: 'string' } }, required: ['url'] }, annotations: WEB_RO },
];

const fail = (message) => { const e = new Error(message); e.toolError = true; throw e; };
const posInt = (v) => Number.isInteger(v) && v >= 1;
/** catalog.json read for status: {cat, at: its mtime ISO}, or null when it is missing or unreadable. */
export function readCatalog(file) {
  try { return { cat: JSON.parse(readFileSync(file, 'utf8')), at: statSync(file).mtime.toISOString() }; } catch { return null; }
}
/** The catalog report's numbers for one folder (duplicate files merged, as `catalog` reports them), or null when the
 * catalog has no entries there. Entries of an older catalog without `root` belong to its `root`. */
export function catalogCounts(catalog, root) {
  const cat = catalog?.cat;
  if (!cat || !Array.isArray(cat.entries)) return null;
  const nfc = (p) => (typeof p === 'string' ? p.normalize('NFC') : p);
  const mine = cat.entries.filter((e) => nfc(e.root ?? cat.root) === nfc(root));
  if (!mine.length) return null;
  const duplicates = mine.reduce((n, e) => n + (Array.isArray(e.dups) ? e.dups.length : 0), 0);
  const book = (e) => Array.isArray(e.books) && e.books.length > 0;
  return { files: mine.length + duplicates, pdfs: mine.filter((e) => e.format === 'pdf').length, withBook: mine.filter(book).length, pdfWithBook: mine.filter((e) => e.format === 'pdf' && book(e)).length, duplicates, at: catalog.at };
}
/** The connected commentary folders for status: [{path, exists, files, pdfs, catalog?}]. files/pdfs are live counts
 * (null when unreadable); `catalog` is the catalog report's numbers for that folder when the catalog covers it. */
export function libraryRows(list, count, short = homeShort, catalog = null) {
  return list.map((l) => {
    if (!l.exists) return { path: short(l.path), exists: false, files: null, pdfs: null };
    let row;
    try { const { files, pdfs } = count(l.path); row = { path: short(l.path), exists: true, files, pdfs }; } catch { row = { path: short(l.path), exists: true, files: null, pdfs: null }; }
    const c = catalogCounts(catalog, l.path);
    return c ? { ...row, catalog: c } : row;
  });
}
/** A path with the home folder written as ~ (shown to the page owner; names only, no file content). On Windows the full
 * path (C:\\Users\\…): people there do not know ~. */
export const homeShort = (p, home = homedir(), platform = process.platform) => (platform !== 'win32' && home && (p === home || p.startsWith(home + path.sep)) ? '~' + p.slice(home.length) : p);

/**
 * The tools' work. `lib` = {loadCatalog, extractEntry, commentaryClass, verify, quoteLength} (commentary.mjs and
 * check.mjs in production, fakes in the tests); `cli(args)` runs commentary.mjs for status/select; `web` is
 * web.mjs makeWeb() and `search` websearch.mjs makeSearch() (injected fetches in the tests). `keys` = {file, present()}:
 * where the search keys are read (home shortened to ~) and whether they are there — the path and a yes/no, never a value.
 */
export function makeHandlers({ lib, cli, web, search, keys, libraries }) {
  const entry = (key) => {
    if (typeof key !== 'string' || !key) fail('key required');
    const cat = lib().loadCatalog();
    const e = cat.entries.find((x) => x.key === key);
    if (!e) fail(`unknown catalog key ${key}`);
    const cls = lib().commentaryClass(e);
    if (cls.doctrine === 'X') fail(`refused: X (${cls.detail ?? 'blocklist'})`);
    return { cat, e, cls };
  };
  return {
    status: async () => {
      const r = await cli(['doctor']);
      const extra = { ...(web ? { webCommentaries: { entries: web.entries } } : {}), ...(keys ? { keysFile: keys.file, keys: !!keys.present() } : {}), ...(libraries ? { libraries: libraries() } : {}) };
      if (!Object.keys(extra).length) return r;
      let body = null;
      try { body = JSON.parse(r.text); } catch {}
      // doctor prints plain Korean lines: they go under `report`
      return { ...r, text: JSON.stringify(body && typeof body === 'object' && !Array.isArray(body) ? { ...body, ...extra } : { report: r.text, ...extra }) };
    },
    select: async (a) => { if (typeof a.passage !== 'string' || !a.passage.trim()) fail('passage required'); return cli(['select', a.passage, '--top', '3']); },
    pages: async (a) => {
      if (!posInt(a.from) || !posInt(a.to) || a.to < a.from) fail('from and to: page numbers, from <= to');
      const { cat, e, cls } = entry(a.key);
      const doc = lib().extractEntry(cat, a.key, { ocr: false });
      const to = Math.min(a.to, a.from + PAGES_MAX - 1);
      const pages = [];
      let chars = 0, truncated = to < a.to;
      if (!doc.needsOcr) for (const p of doc.pages.filter((x) => x.page >= a.from && x.page <= to)) {
        const left = CHARS_MAX - chars;
        if (left <= 0) { truncated = true; break; }
        const text = [...p.text].length > left ? [...p.text].slice(0, left).join('') : p.text;
        if (text !== p.text) truncated = true;
        pages.push({ page: p.page, text });
        chars += [...text].length;
      }
      return { text: JSON.stringify({ key: e.key, author: e.author ?? null, title: e.title, series: e.series ?? null, doctrine: cls.doctrine, pageCount: doc.pageCount, needsOcr: !!doc.needsOcr, from: a.from, to, pages, chars, truncated }) };
    },
    verify: async (a) => {
      if (!posInt(a.page)) fail('page: a page number');
      if (typeof a.quote !== 'string' || !a.quote.trim()) fail('quote required');
      const { cls } = entry(a.key);
      if (lib().quoteLength(a.quote) > QUOTE_MAX) return { text: JSON.stringify({ status: 'invalid', reason: `quote longer than ${QUOTE_MAX} characters`, doctrine: cls.doctrine }) };
      const r = lib().verify(a.key, a.page, a.quote);
      return { text: JSON.stringify({ ...r, doctrine: cls.doctrine }) };
    },
    'web-pages': async (a) => { if (!web) fail('web tools not available'); if (typeof a.passage !== 'string' || !a.passage.trim()) fail('passage required'); return { text: JSON.stringify(await web.pages({ passage: a.passage, ids: a.ids })) }; },
    'web-verify': async (a) => {
      if (search?.knows(a.url)) return { text: JSON.stringify(await search.verify({ url: a.url, quote: a.quote })) };
      if (!web) fail('web tools not available');
      return { text: JSON.stringify(await web.verify({ url: a.url, quote: a.quote })) };
    },
    'web-search': async (a) => {
      if (!search) fail('web search not available');
      const r = await search.search({ query: a.query, kind: a.kind, count: a.count, recentDays: a.recentDays });
      // no or wrong keys: say where the key file is (status may not reach the page when doctor finds a problem)
      return { text: JSON.stringify(keys && (r?.error === 'no-keys' || r?.error === 'bad-keys') ? { ...r, keysFile: keys.file } : r) };
    },
    // a built commentary URL (web-pages) may be read too
    'web-read': async (a) => { if (!search) fail('web search not available'); return { text: JSON.stringify(await search.read({ url: a.url }, { allow: !!web?.builtUrl?.(a.url) })) }; },
  };
}

/** One JSON-RPC request -> its response (null for a notification). */
export async function handle(req, handlers) {
  if (!req || typeof req !== 'object') return null;
  const { id, method, params } = req;
  if (id === undefined) return null; // notification
  const ok = (result) => ({ jsonrpc: '2.0', id, result });
  if (method === 'initialize') return ok({ protocolVersion: params?.protocolVersion || '2025-06-18', capabilities: { tools: {} }, serverInfo: { name: 'sermon-sources', version: '0.4.4' } });
  if (method === 'ping') return ok({});
  if (method === 'tools/list') return ok({ tools: TOOLS });
  if (method === 'tools/call') {
    const name = params?.name;
    if (!TOOLS.some((t) => t.name === name)) return { jsonrpc: '2.0', id, error: { code: -32602, message: 'unknown tool' } };
    try {
      const r = await handlers[name](params.arguments || {});
      return ok({ content: [{ type: 'text', text: r.text }], isError: r.ok === false });
    } catch (e) {
      return ok({ content: [{ type: 'text', text: String(e?.message ?? e) }], isError: true });
    }
  }
  return { jsonrpc: '2.0', id, error: { code: -32601, message: 'method not found' } };
}

const runCli = (args) => new Promise((resolve) => {
  const t0 = Date.now();
  process.stderr.write(`[sermon-sources] start ${args[0]}\n`); // the desktop app keeps stderr in its log: how long each call took
  execFile(process.execPath, [CLI, ...args], { cwd: path.join(path.dirname(CLI), '..', '..', '..'), maxBuffer: 16 << 20, timeout: 120000 }, (err, stdout, stderr) => {
    process.stderr.write(`[sermon-sources] end ${args[0]} ${Date.now() - t0}ms${err ? ' error ' + String(err.code ?? err.signal ?? '') + ' ' + String(stderr || err.message).slice(0, 300).replace(/\s+/g, ' ') : ''}\n`);
    resolve({ ok: !err, text: (stdout || '') + (err ? '\n' + (stderr || err.message) : '') });
  });
});

const isMain = (() => { try { return !!process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url)); } catch { return false; } })();
if (isMain) {
  const commentary = await import('../scripts/commentary.mjs');
  const check = await import('../../sermon-sources/scripts/check.mjs');
  const webLib = await import('../../sermon-sources/scripts/web.mjs');
  const lib = { loadCatalog: commentary.loadCatalog, extractEntry: commentary.extractEntry, commentaryClass: commentary.commentaryClass, verify: commentary.verify, quoteLength: check.quoteLength };
  const searchLib = await import('../../sermon-sources/scripts/websearch.mjs');
  const envFile = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..', '.env.local'); // the keys stay on this computer
  const search = searchLib.makeSearch({ keys: () => searchLib.loadKeys({ envFile }) });
  const keys = { file: homeShort(envFile), present: () => !!searchLib.loadKeys({ envFile }) };
  const platform = await import('../scripts/platform.mjs');
  const libraries = () => libraryRows(commentary.listLibraries(), platform.countFiles, homeShort, readCatalog(commentary.catalogPath()));
  const handlers = makeHandlers({ lib: () => lib, cli: runCli, web: { entries: webLib.WEB.entries.length, builtUrl: webLib.builtUrl, ...webLib.makeWeb() }, search, keys, libraries });
  createInterface({ input: process.stdin }).on('line', async (line) => {
    let req;
    try { req = JSON.parse(line); } catch { return; }
    const res = await handle(req, handlers);
    if (res) process.stdout.write(JSON.stringify(res) + '\n');
  });
}
