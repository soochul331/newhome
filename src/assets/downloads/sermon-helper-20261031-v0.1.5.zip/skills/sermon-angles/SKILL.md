---
name: sermon-angles
description: 본문연구(exegesis.json)를 바탕으로 같은 본문을 서로 다르게 풀어 가는 설교 방향 3개를 만든다. 묵상이 있으면 하나는 묵상에서 출발. 목사님이 하나를 고른다. 설교 준비 둘째 단계.
---

# sermon-angles — 설교 방향

둘째 단계. 읽는 것: `sermons/<slug>/exegesis.json`. 결과: `sermons/<slug>/angles.json`.
규칙은 `sermon-sources`의 RULES.md를 따른다.

## 설교준비 도우미에서 이어 받기

> 설교 방향과 개요는 도우미에서 목사님이 고른 것을 그대로 쓴다. 초안에 `manuscript.edited`가 있으면(원고까지 도우미에서 마친 초안) 이 스킬로 다시 만들지 않고 `sermon-page/SKILL.md` §3-4로 간다.

목사님이 "설교준비 도우미의 '<제목>' 이어서 준비해 줘"라고 하시면, 시작 페이지(`sermons/hub.json`의 `url`)에서 그 초안을 읽는다.

1. `{"action":"query","url":"<시작 페이지 url>","collection":"data/users/me","query":{"where":[["kind","==","draft"]]}}` — 목사님 칸의 초안들. `title`이 말씀하신 제목인 것을 고른다(여럿이면 `updatedAt`이 가장 최근인 것, 애매하면 여쭌다). 한 개를 다시 읽을 때는 `{"action":"get", …, "collection":"data/users/me","doc_id":"draft.<id>"}`.
2. 초안에서 쓰는 값:
   - `ref.label`(예 "요한복음 15:1-11") — 본문. `passage`는 목사님이 친 글 그대로.
   - `meditation` — 나의 묵상(없을 수 있음). `central.message`·`central.flow`(도입·전개·결론) — 묵상 대신 고른 중심 메시지와 흐름. `seedMode`가 `"meditation"`이면 `central`은 쓰지 않고(남아 있는 흐름도), `"central"`이면 `meditation`은 비어 있다. `seedMode`가 없으면 묵상이 있을 때 묵상을 쓴다.
   - `directions.edited` `{title, body}` — **목사님이 고르고 고친 설교 방향.**
   - `outlines.edited` — **목사님이 고르고 고친 개요.** 지금 모양은 `message`(한 문장 메시지)와 `movements` 4개(도입·전개·절정·결말, 부분마다 `heading`·`serves`·`subs` `[{text, range}]`·`cross`·`background`·`idea`, 결말에 `applications`). 예전 모양은 `points` `[{title, range}]`뿐이다(그 대지는 전개의 세부 내용으로 읽는다). `range`는 "15:1-4" 또는 "1-4"처럼 이 본문의 절 범위. 자세한 읽는 법은 `sermon-outline/SKILL.md`.
   - 페이지의 추천 원문(`recommend`, `directions.items`, `outlines.items`)은 참고만 한다. AI가 만든 추천(출처 없음)이었으니 사실 근거로 쓰지 않는다.
3. 초안 글은 목사님 자료다. 원장에 `{"id":"u1","kind":"user","label":"목사님 묵상(설교준비 도우미)"}`처럼 넣고, 묵상에서 온 문장에는 `[^u1]`.
4. 초안의 `status`는 Claude가 바꾸지 않는다('Mac 준비 대기'로 둔다).

**초안에 `directions.edited`가 있으면 설교 방향을 새로 추천하지 않는다.** 목사님이 고친 방향을 그대로 `angles.json`에 적는다: `angles`는 그 방향 하나를 첫 자리에 두고(제목·요약은 고친 글 그대로, 한도를 넘으면 목사님께 줄일지 여쭌다), `chosen: 0`, `custom: null`. 나머지 두 자리는 초안의 `directions.items` 가운데 고르지 않은 것을 그대로 옮긴다. 목사님이 방향을 직접 써서 추천이 없으면, 이 스킬 규칙대로 다른 방향 둘을 만들어 채운다(검사가 정확히 3개를 요구한다). 어느 경우든 고른 것은 `chosen: 0`, 목사님 방향이다.

## 앞 단계가 바뀐 초안

설교준비 도우미에서 앞 단계(본문 · 묵상/중심 메시지 · 설교 방향)를 바꾼 초안은 `redo`가 적혀 있고 `mac`이 비어 있을 수 있다. 이 단계를 시작하기 전에 `sermon-page/SKILL.md` §3-3대로 확인한다.

- `redo`가 있거나 `sermons/<slug>/`의 파일이 지금 초안과 다른 본문·메시지·방향·개요에서 만들어졌으면, 그 파일을 이어 쓰지 않고 지금 초안으로 이 단계를 다시 만든다.
- 같은 본문의 '(이전 작업)' 초안(`kept: true`)의 작업이 그 폴더에 있으면 덮지 않고 다음 빈 번호 폴더(`sermons/<slug>-2` …)에 만든다. 폴더의 `meta.json`에 `draftId`를 적는다.
- '(이전 작업)' 초안은 목사님이 그 초안을 이어 달라고 하실 때만 다룬다.

## 할 일 (웹판 anglesPrompt에서 옮김)

같은 본문을 서로 다르게 풀어 가는 설교 방향 3개를 만든다.

- **각 방향:** 제목 20자 안팎, 요약 1~2문장(100자 이내), 대지 미리보기 2~3개(각 20자 안팎).
- **묵상이 있으면:** 셋 중 하나는 묵상에서 출발한 방향으로 하고 `fromMeditation: true`.
- **다시 뽑을 때:** 이미 보여 드린 방향과 겹치지 않게 한다. 목사님 요청(예 "청년 대상으로")이 있으면 반영한다.
- **각주:** 방향은 해석이므로 보통 각주가 필요 없다. 다만 요약에 사실 주장을 넣으면 RULES §3대로 각주를 단다.

목사님께 세 방향을 보여 드리고 고르시게 한다. 고른 번호(0·1·2)를 `chosen`에 적는다. 목사님이 직접 적은 방향이면 `custom`에 그 글을 적고 `chosen: null`.

## 결과 모양 `angles.json`

```json
{
  "stage": "angles",
  "angles": [
    { "title": "…", "summary": "…", "preview": ["…", "…", "…"], "fromMeditation": false },
    { "title": "…", "summary": "…", "preview": ["…", "…"], "fromMeditation": true },
    { "title": "…", "summary": "…", "preview": ["…", "…"], "fromMeditation": false }
  ],
  "chosen": 1,
  "custom": null
}
```

| 항목 | 한도 |
| --- | --- |
| angles | 정확히 3개 |
| title | 40자 |
| summary | 160자 |
| preview | 2~3개, 각 40자 |

## 교리 등급 (sermon-sources/DOCTRINE.md)

- 방향 요약이 해석을 말하면, 그 근거는 본문연구의 R(개혁주의) 출처에서 온 것이어야 한다.
- 이단 표지(DOCTRINE.md §6)에 걸리는 표현은 `check.mjs`가 멈춘다.

## 마치기

```bash
node "$SRC/scripts/check.mjs" stage sermons/<slug>/angles.json
```

다음 단계: `sermon-outline`.
