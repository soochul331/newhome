---
name: sermon-illustration
description: 확정된 개요에 맞는 예화(이야기·통계·인용·역사 사건)를 찾아 출처를 확인하고, 개요의 어느 자리에 들어가는지와 이어 주는 말을 붙인다. 출처를 찾지 못한 예화는 '확인 필요'로만 둔다(지어낸 예화를 사실처럼 쓰지 않음). 설교 준비 다섯째 단계(선택).
---

# sermon-illustration — 예화

다섯째 단계(선택). 읽는 것: `outline.json`(+ `exegesis.json`, `manuscript.json`이 있으면 함께), `sources.json`. 결과: `sermons/<slug>/illustration.json`.
규칙은 `sermon-sources`의 RULES.md를 따른다. 이 스킬 폴더 경로와 별개로, sermon-sources 스킬 폴더 경로를 `$SRC`라고 부른다.

## 받는 것

- **개수:** 기본 3개(1~6개). 목사님이 정하면 그대로.
- **자리:** 개요의 어느 곳이 비어 보이는지 목사님이 말하면 그 자리를 먼저 채운다.

## 할 일

1. **자리 고르기:** 개요에서 예화가 도움이 될 자리를 고른다.
   - 네 부분 개요(`movements`): `intro` 도입 · `development` 전개 · `climax` 절정 · `conclusion` 결말. 절정은 본문 이야기와 오늘의 삶의 장면을 드는 자리라 예화가 가장 잘 맞는다. 개요의 `illustrationIdea`(목사님이 바꿀 예화 아이디어)가 있는 자리를 먼저 본다.
   - 예전 개요(`points`): `intro`, `point1`~`point4`, `conclusion`.
2. **찾기:** 웹 검색으로 후보를 찾는다.
   - 실제 있었던 일·통계·인용문·역사 사건만 예화로 쓴다.
   - **A 등급** 페이지를 먼저 찾는다. A는 `scripts/sites.json`에 적힌 곳뿐이다: 대한성서공회, 교단 본부, 신학교·대학(ac.kr·edu·ac.uk), 학술지(KCI·RISS·DBpia·JSTOR·doi.org 등), 기독교 출판사, 기독교 언론, 공개 주석·고전 문헌(biblehub·ccel·gutenberg·archive.org 등).
   - 목록에 없는 곳(정부·통계 기관, 일반 언론 포함)은 지금 B 등급이다. B 출처만 있는 예화는 `[^?]`를 함께 달아야 점검을 통과한다. 사이트 목록은 `check.mjs tier <주소>`로 확인한다.
   - 한국어 출처도 환영한다. 다만 등급 규칙은 같다. 개인 블로그·카페는 B 등급이라 혼자 근거가 되지 못한다.
3. **열고 확인하기:** 쓸 구절을 페이지에서 고른 뒤 원문 그대로 확인해 원장에 올린다.
   ```bash
   node "$SRC/scripts/check.mjs" add sermons/<slug> --url "<주소>" --quote "<원문 그대로, 300자 이하>" --claim illustration --site "<사이트>" [--author "<저자>"] [--published "<날짜>"]
   ```
   - `status: found`일 때만 그 예화를 사실로 쓴다. 본문에 `[^w…]`를 단다.
   - `not-found`·`unreachable`이면 다른 페이지를 찾는다. 끝내 못 찾으면 그 예화 본문에 `[^?]`를 단다(**확인 필요**).
   - 검색 결과 요약문이나 WebFetch 요약은 출처가 아니다(RULES §2-1).
4. **지어내지 않는다:**
   - 출처 없는 이야기를 실화처럼 쓰지 않는다. 인물·숫자·날짜·장소를 지어내지 않는다.
   - 널리 돌지만 출처를 못 찾은 이야기(예: 유명인 일화)는 `[^?]`로 두고, 본문에 "출처를 확인하지 못한 이야기"라고 적는다.
   - 통계는 기관·조사 연도를 원문에서 그대로 옮긴다.
5. **이어 주는 말(`bridge`):** 예화에서 그 자리의 메시지로 넘어가는 1~2문장. 해석·권면이므로 각주를 달지 않는다. 출처는 `body`에만 단다.
6. **인용 길이:** 원장 인용 구절은 300자 이하. 본문(`body`)은 예화를 우리말로 풀어 쓴 것(400자 이하)이고, 따옴표로 직접 옮긴 말은 원장 인용과 같은 문구여야 한다.

## 결과 모양 `illustration.json`

```json
{
  "stage": "illustration",
  "illustrations": [
    {
      "kind": "history",
      "title": "…",
      "body": "…[^w17]",
      "fitsAt": "point1",
      "bridge": "…"
    },
    {
      "kind": "story",
      "title": "…",
      "body": "출처를 확인하지 못한 이야기다. …[^?]",
      "fitsAt": "intro",
      "bridge": "…"
    }
  ]
}
```

| 항목 | 한도 |
| --- | --- |
| illustrations | 1~6개 |
| kind | `story` 이야기 · `statistic` 통계 · `quote` 인용 · `history` 역사 사건 |
| title | 40자 |
| body | 400자, `[^w…]` 또는 `[^?]` 필수 |
| fitsAt | 네 부분 개요: `intro` · `development` · `climax` · `conclusion` / 예전 개요: `intro` · `point1`~`point4`(개요에 있는 대지만) · `conclusion` |
| bridge | 160자, 웹 각주 없음 |

## 교리 등급 (sermon-sources/DOCTRINE.md)

- 출처를 더할 때는 `check.mjs add`에 `--claim`을 꼭 적는다.
  - 예화는 `--claim illustration`이다. R(개혁주의)·E(비개혁주의) 출처를 쓸 수 있다.
  - 종교와 무관한 사실(농업·자연·통계)은 `--claim fact`이다. N(비기독교) 출처도 쓸 수 있다.
- E·N 출처는 화면에 '비개혁주의 자료'·'비기독교 자료'로 표시된다.
- 예화 문장에서 교리 결론을 끌어내지 않는다. 교리·해석은 본문연구·개요·원고에서 R 출처로 단다.
- 이단·사이비(X) 출처는 `check.mjs`가 거부한다. 이단 단체의 사이트는 열지 않는다.

## 앞 단계가 바뀐 초안

설교준비 도우미에서 앞 단계(본문 · 묵상/중심 메시지 · 설교 방향)를 바꾼 초안은 `redo`가 적혀 있고 `mac`이 비어 있을 수 있다. 이 단계를 시작하기 전에 `sermon-page/SKILL.md` §3-3대로 확인한다.

- `redo`가 있거나 `sermons/<slug>/`의 파일이 지금 초안과 다른 본문·메시지·방향·개요에서 만들어졌으면, 그 파일을 이어 쓰지 않고 지금 초안으로 이 단계를 다시 만든다.
- 같은 본문의 '(이전 작업)' 초안(`kept: true`)의 작업이 그 폴더에 있으면 덮지 않고 다음 빈 번호 폴더(`sermons/<slug>-2` …)에 만든다. 폴더의 `meta.json`에 `draftId`를 적는다.
- '(이전 작업)' 초안은 목사님이 그 초안을 이어 달라고 하실 때만 다룬다.

## 설교준비 도우미에서 온 초안 (오너 2026-10-26)

예화은(는) 이제 설교준비 도우미 **안에서** 쓴다(초안의 `illustration.edited`, 7 예화 단계 — 원고 초안 앞, 오너 2026-10-28). 목사님이 도우미에서 "'<제목>' 이어서 준비해 줘"라고 하시면 이 스킬로 다시 쓰지 않고 `sermon-page/SKILL.md` §3-4(10 출처 확인 → 설교 페이지)를 따른다. 목사님이 고친 글을 고쳐 쓰지 않는다.
이 스킬은 도우미 없이 Claude Code에서 처음부터 준비할 때 쓴다. 도우미의 단계 표시는 8 출처 확인 하나(`mac.sources`)뿐이므로 이 단계는 `mac`에 따로 적지 않는다.

## 마치기

```bash
node "$SRC/scripts/check.mjs" stage sermons/<slug>/illustration.json
node "$SRC/scripts/check.mjs" sermon sermons/<slug>
```

`sermon` 점검의 `stats.illustration`을 목사님께 그대로 보고한다.

- `total` 예화 수, `sourced` 출처 확인된 예화, `needsCheck` 확인 필요 예화
- `found` 확인된 웹 출처, `tierA` A 등급, `korean` 한국어 인용 구절 수

다음: `sermon-application`(적용), 그리고 설교 페이지를 다시 게시한다(`sermon-page` — '예화' 탭 `#illustration`).
