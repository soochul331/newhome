---
name: sermon-exegesis
description: 설교 본문(개역개정)의 본문연구를 만든다 — 배경·문맥·단락·절별 풀이·신학 주제·오늘과 닿는 지점. 사실마다 출처를 sermon-sources 규칙으로 확인해 각주를 단다. 설교 준비의 첫 단계.
---

# sermon-exegesis — 본문연구

설교 준비 첫 단계. 결과는 `sermons/<slug>/exegesis.json`.
**먼저 `sermon-sources` 스킬의 SKILL.md와 RULES.md를 읽고 그 규칙을 따른다.**
출처 원장은 `sermons/<slug>/sources.json`이다.

## 받는 것

- **본문:** 예 "요한복음 15:1-11".
  - 주소가 실제로 있는지 `check.mjs bible`로 확인하고 `[^b…]`를 만든다.
- **목사님의 묵상** (있으면): 최대 1,000자. 원장에 `{"id":"u1","kind":"user","label":"목사님 묵상"}`으로 넣는다.
- **목사님이 붙여넣은 본문** (있으면): 그 문구로만 인용한다(`wording: user-paste`).
- **설교 방향** (있으면): 대상·강조점·주의할 점.

본문 주소가 없거나 애매하면 먼저 물어본다. 슬러그는 `<책>-<장>-<절>-<절>`(예 `요한복음-15-1-11`)로 정한다.

## 설교준비 도우미에서 이어 받기

> 초안에 `manuscript.edited`가 있으면(원고까지 도우미에서 마친 초안) 이 스킬이 아니라 `sermon-page/SKILL.md` §3-4로 간다. 아래는 초안을 읽는 법(§3-4도 이대로 읽는다)과, 원고가 아직 없는 예전 초안을 이어 받을 때의 순서다.

목사님이 "설교준비 도우미의 '<제목>' 이어서 준비해 줘"라고 하시면, 시작 페이지(`sermons/hub.json`의 `url`)에서 그 초안을 읽는다.

1. `{"action":"query","url":"<시작 페이지 url>","collection":"data/users/me","query":{"where":[["kind","==","draft"]]}}` — 목사님 칸의 초안들. `title`이 말씀하신 제목인 것을 고른다(여럿이면 `updatedAt`이 가장 최근인 것, 애매하면 여쭌다). 한 개를 다시 읽을 때는 `{"action":"get", …, "collection":"data/users/me","doc_id":"draft.<id>"}`.
2. 초안에서 쓰는 값:
   - `ref.label`(예 "요한복음 15:1-11") — 본문. `passage`는 목사님이 친 글 그대로.
   - `meditation` — 나의 묵상(없을 수 있음). `central.message`·`central.flow`(도입·전개·결론) — 묵상 대신 고른 중심 메시지와 흐름. `seedMode`가 `"meditation"`이면 `central`은 쓰지 않고(남아 있는 흐름도), `"central"`이면 `meditation`은 비어 있다. `seedMode`가 없으면 묵상이 있을 때 묵상을 쓴다.
   - `directions.edited` `{title, body}` — **목사님이 고르고 고친 설교 방향.**
   - `outlines.edited` — **목사님이 고르고 고친 개요.** 지금 모양은 `message`(한 문장 메시지)와 `movements` 4개(도입·전개·절정·결말, 부분마다 `heading`·`serves`·`subs` `[{text, range}]`·`cross`·`background`·`idea`, 결말에 `applications`). 예전 모양은 `points` `[{title, range}]`뿐이다(그 대지는 전개의 세부 내용으로 읽는다). `range`는 "15:1-4" 또는 "1-4"처럼 이 본문의 절 범위. 자세한 읽는 법은 `sermon-outline/SKILL.md`.
   - 페이지의 추천 원문(`recommend`, `directions.items`, `outlines.items`)은 참고만 한다. AI가 만든 추천(출처 없음)이었으니 사실 근거로 쓰지 않는다.
3. 초안 글은 목사님 자료다. 원장에 `{"id":"u1","kind":"user","label":"목사님 묵상(설교준비 도우미)"}`처럼 넣고, 묵상에서 온 문장에는 `[^u1]`.
4. 초안의 `status`는 Claude가 바꾸지 않는다. 진행은 `mac.sources`에만 적는다(`sermon-page/SKILL.md` §3-2).
5. 도우미에서 쓴 결과도 함께 있다: `exegesis.edited` `{groups: [{range, title, body, background}]}`, `manuscript.edited` `{sections: [{key, label, heading, paragraphs[]}]}`, `illustration.edited` `{items: [{part, title, idea, bridge}]}`, `application.edited` `{items: [{part, text, range}]}`. AI가 출처 없이 쓰고 목사님이 고친 글이다. 배경 메모·예화 아이디어는 확인 전의 글로 읽는다. 단, 주석 도구가 연결된 앱에서 쓴 본문연구에는 `groups[].notes`(도구가 그 쪽에서 찾은 주석 인용: key·page·quote·point·claim)가 있을 수 있고, 원고의 `manuscript.notes`가 그 메모를 각주로 가리킨다(`sermon-page/SKILL.md` §3-1). 이 메모는 출처 원장에 그대로 옮길 수 있는 확인된 인용이다.

이 단계에서는 본문(`ref.label`)·묵상(또는 중심 메시지와 흐름)·고친 설교 방향(`directions.edited`)을 '받는 것'으로 쓴다. 설교 방향은 '대상·강조점'으로 존중한다.

## 할 일 (웹판 exegesisPrompt에서 옮김)

이 본문의 본문연구를 만든다. 담을 것:

- 배경: 저자·수신자·장르·목적·구조
- 문맥, 단락 구조
- 절별 풀이: 핵심 절 위주
- 신학 주제 2~4개, 오늘과 닿는 지점
- `historyCulture`: 확실한 것이 없으면 null
- `quotes`: 핵심 구절 2~4개의 개역개정 문구, 각 1~3절만
- 묵상이 있으면 `meditationNote`에 묵상과 본문이 만나는 자리를 2~3문장으로 적고, 신학 주제와 오늘과 닿는 지점을 고를 때 반영한다. 없으면 null

전체 분량은 한국어 약 1,800자 이내. 간결한 서술체.

### 조사 (출처)

1. 배경·저자·연대·문화·원어처럼 **사실을 말하는 문장**은 등급 A 출처를 찾아 `check.mjs add --claim history|language|fact`로 확인한다.
   **해석·교리 문장**(이 구절이 무엇을 뜻하는가)은 개혁주의(R) 출처만 `--claim doctrine`으로 단다(DOCTRINE.md §3). 예:
   - R: ccel.org의 칼뱅 주석·매튜 헨리, biblehub의 매튜 풀·반즈·빈센트, 기독신문·총신대 자료
   - E(사실·원어만, '비개혁주의 자료' 표시): 구직(enduringword), 엘리코트·케임브리지·Expositor's Greek Testament, 앤드류 머리
   - 여러 저자 사이트(biblehub·ccel 등)는 `--author`에 저자를 꼭 적는다. 모르는 저자는 E로 다뤄 교리 근거가 될 수 없다.
2. found가 된 출처만 각주로 단다. 찾지 못하면 그 문장 끝에 `[^?]`를 단다(RULES §3).
3. 인용 구절은 원문 그대로 300자 이하. 영어 주석은 영어 원문 그대로 기록한다.
   - 본문연구 문장은 한국어로 풀어 쓰고 각주로 연결한다.

## 결과 모양 `exegesis.json`

웹판 `exegesisOut` 구조와 같고 `stage`, `passage`, 인용의 `wording`을 더했다. 각주 표시는 문장 끝에 붙인다.

```json
{
  "stage": "exegesis",
  "passage": { "label": "요한복음 15:1-11", "bookId": 43, "chap": 15, "v1": 1, "v2": 11 },
  "meditation": "목사님 묵상 원문 또는 null",
  "background": { "author": "…[^w1]", "audience": "…", "genre": "…", "purpose": "…", "structure": "…" },
  "context": "…",
  "structure": [{ "range": "1-4절", "title": "…" }],
  "verseNotes": [{ "verse": "1절", "note": "…[^w2]" }],
  "themes": [{ "title": "…", "body": "…" }],
  "todayLink": "…",
  "historyCulture": "…[^w3] 또는 null",
  "quotes": [{ "refText": "요한복음 15:5", "text": "개역개정 문구[^b2]", "wording": "ai-recall" }],
  "meditationNote": "…[^u1] 또는 null"
}
```

| 항목 | 한도 |
| --- | --- |
| structure | 1~8개 |
| verseNotes | 1~12개 |
| themes | 1~4개 |
| quotes | 0~4개, refText 40자, text 300자 |

## 교리 대조 (doctrine pass — sermon-sources/DOCTRINE.md §4)

글을 다 쓴 뒤, 마치기 전에 한다.

1. 이 단계 글이 말하는 **교리 주장**(하나님·그리스도·성령·구원·교회·성례·종말에 관한 주장)을 한 줄씩 뽑아 `doctrine` 목록에 적는다.
   - 해석 문장(이 구절이 무엇을 뜻하는가)의 근거는 **R(개혁주의) 출처만** 단다.
   - E(비개혁주의)·N(비기독교) 출처는 사실·역사·원어에만 쓴다(DOCTRINE.md §3).
2. 각 주장을 웨스트민스터 신앙고백·대요리문답·소요리문답(예장합동 헌법 교리표준)이나 공교회 신경에 맞대어 본다. 맞는 조항을 `standard`에 적는다.
   - 조항 적는 법: `WCF 16.3`, `대요리문답 66문`, `소요리문답 36문`, `사도신경`, `니케아 신경`, `칼케돈 신경`, `벨직 27조`, `하이델베르크 1문`, `도르트 5장 3항`. 둘 이상이면 `; `로 잇는다.
   - 조항 번호는 기억으로 쓰지 말고, 확신이 없으면 신앙고백 원문을 열어 확인한다.
3. 기준에 맞대어 볼 수 없는 주장은 `standard: null`로 두고 `note`에 이유를 쓴다. 글의 그 문장 끝에 `[^d?]`(교리 확인 필요)를 단다.
   - `[^d?]`가 하나라도 있으면 **오너가 검토하기 전에는 게시하지 않는다.** 목사님께 그 문장을 그대로 보여 드리고 판단을 여쭌다.
4. 이단 표지(DOCTRINE.md §6)에 걸리면 `check.mjs`가 doctrine-review 오류로 멈춘다. 문장을 고치거나 목사님께 검토를 받는다. 오류를 피하려고 표현만 비틀지 않는다.

```json
"doctrine": [
  { "assertion": "그리스도와의 연합 없이는 선한 열매가 없다", "standard": "WCF 16.3", "note": "5절" },
  { "assertion": "…", "standard": null, "note": "기준 조항을 찾지 못함" }
]
```

| 항목 | 한도 |
| --- | --- |
| doctrine | 0~12개, assertion 80자, note 160자 |

## 앞 단계가 바뀐 초안

설교준비 도우미에서 앞 단계(본문 · 묵상/중심 메시지 · 설교 방향)를 바꾼 초안은 `redo`가 적혀 있고 `mac`이 비어 있을 수 있다. 이 단계를 시작하기 전에 `sermon-page/SKILL.md` §3-3대로 확인한다.

- `redo`가 있거나 `sermons/<slug>/`의 파일이 지금 초안과 다른 본문·메시지·방향·개요에서 만들어졌으면, 그 파일을 이어 쓰지 않고 지금 초안으로 이 단계를 다시 만든다.
- 같은 본문의 '(이전 작업)' 초안(`kept: true`)의 작업이 그 폴더에 있으면 덮지 않고 다음 빈 번호 폴더(`sermons/<slug>-2` …)에 만든다. 폴더의 `meta.json`에 `draftId`를 적는다.
- '(이전 작업)' 초안은 목사님이 그 초안을 이어 달라고 하실 때만 다룬다.

## 설교준비 도우미에서 온 초안 (오너 2026-10-26)

본문연구은(는) 이제 설교준비 도우미 **안에서** 쓴다(초안의 `exegesis.edited`). 목사님이 도우미에서 "'<제목>' 이어서 준비해 줘"라고 하시면 이 스킬로 다시 쓰지 않고 `sermon-page/SKILL.md` §3-4(8 출처 확인 → 설교 페이지)를 따른다. 목사님이 고친 글을 고쳐 쓰지 않는다.
이 스킬은 도우미 없이 Claude Code에서 처음부터 준비할 때 쓴다. 도우미의 단계 표시는 8 출처 확인 하나(`mac.sources`)뿐이므로 이 단계는 `mac`에 따로 적지 않는다.

## 마치기

```bash
node "$SRC/scripts/check.mjs" stage sermons/<slug>/exegesis.json
node "$SRC/scripts/check.mjs" sermon sermons/<slug>
```

(`$SRC` = sermon-sources 스킬 폴더.) 두 명령이 모두 통과하면 목사님께 보고한다.

- 짧은 요약
- 출처 통계: found·확인 필요 개수, 등급 A/B
- 다음 단계: `sermon-angles`
