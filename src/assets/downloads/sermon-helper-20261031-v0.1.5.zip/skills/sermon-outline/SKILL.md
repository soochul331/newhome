---
name: sermon-outline
description: 고른 설교 방향으로 설교 개요를 만든다 — 맨 위에 한 문장 메시지, 그 아래 도입·전개·절정·결말 네 부분(부분마다 제목 한 줄, 한 문장 메시지와 이어지는 점, 절 주소가 붙은 세부 내용 3~5개, 알맞으면 관련 구절·배경·예화 아이디어, 결말에는 적용 1~3개). 성경 구절은 대한성서공회 링크로 확인. 설교 준비 셋째 단계.
---

# sermon-outline — 설교 개요

셋째 단계. 읽는 것: `exegesis.json`, `angles.json`(고른 방향). 결과: `sermons/<slug>/outline.json`.
규칙은 `sermon-sources`의 RULES.md를 따른다.

## 설교준비 도우미에서 이어 받기

> 설교 방향과 개요는 도우미에서 목사님이 고른 것을 그대로 쓴다. 초안에 `manuscript.edited`가 있으면(원고까지 도우미에서 마친 초안) 이 스킬로 다시 만들지 않고 `sermon-page/SKILL.md` §3-4로 간다.

목사님이 "설교준비 도우미의 '<제목>' 이어서 준비해 줘"라고 하시면, 시작 페이지(`sermons/hub.json`의 `url`)에서 그 초안을 읽는다.

1. `{"action":"query","url":"<시작 페이지 url>","collection":"data/users/me","query":{"where":[["kind","==","draft"]]}}` — 목사님 칸의 초안들. `title`이 말씀하신 제목인 것을 고른다(여럿이면 `updatedAt`이 가장 최근인 것, 애매하면 여쭌다). 한 개를 다시 읽을 때는 `{"action":"get", …, "collection":"data/users/me","doc_id":"draft.<id>"}`.
2. 초안에서 쓰는 값:
   - `ref.label`(예 "요한복음 15:1-11") — 본문. `passage`는 목사님이 친 글 그대로.
   - `meditation` — 나의 묵상(없을 수 있음). `central.message`·`central.flow`(도입·전개·결론) — 묵상 대신 고른 중심 메시지와 흐름. `seedMode`가 `"meditation"`이면 `central`은 쓰지 않고(남아 있는 흐름도), `"central"`이면 `meditation`은 비어 있다. `seedMode`가 없으면 묵상이 있을 때 묵상을 쓴다.
   - `directions.edited` `{title, body}` — **목사님이 고르고 고친 설교 방향.**
   - `outlines.edited` — **목사님이 고르고 고친 개요.** 두 모양이 있다.
     - 지금 모양: `message`(한 문장 메시지)와 `movements` 4개(순서대로 `intro` 도입 · `development` 전개 · `climax` 절정 · `conclusion` 결말). 부분마다 `heading`(제목 한 줄), `serves`(한 문장 메시지와 이어지는 점), `subs` `[{text, range}]`(세부 내용, `range`는 "15:1-4"처럼 이 본문의 절 범위), `cross`(관련 본문 주소, 빈 값일 수 있음), `background`(배경 메모), `idea`(예화 아이디어), 결말만 `applications`(적용 글 목록).
     - 예전 모양: `points` `[{title, range}]`만 있다(`movements` 없음). 이때는 그 대지들을 **전개의 세부 내용**으로 옮겨 쓰고(페이지도 그렇게 보여 준다), 나머지 부분은 아래 '할 일'대로 채운다. 대지 글은 버리지 않는다.
     - `movements`가 있으면 그것을 쓰고, 함께 남아 있는 예전 `points`는 쓰지 않는다.
   - 페이지의 추천 원문(`recommend`, `directions.items`, `outlines.items`)은 참고만 한다. AI가 만든 추천(출처 없음)이었으니 사실 근거로 쓰지 않는다.
3. 초안 글은 목사님 자료다. 원장에 `{"id":"u1","kind":"user","label":"목사님 묵상(설교준비 도우미)"}`처럼 넣고, 묵상에서 온 문장에는 `[^u1]`.
4. 초안의 `status`는 Claude가 바꾸지 않는다('Mac 준비 대기'로 둔다).

**초안에 `outlines.edited`가 있으면 개요를 새로 추천하지 않는다.** 한 문장 메시지, 부분마다 제목·세부 내용의 글과 순서·절 범위, 관련 본문, 적용은 목사님이 고친 그대로 쓴다(`range` "15:1-4" → 세부 내용의 `refs`에 `check.mjs bible`로 확인한 "요한복음 15:1-4[^b…]"). Claude가 하는 일은 빈 곳을 채우고(비어 있는 `serves`·세부 내용이 3개보다 적은 부분 등), 모든 성경 주소를 확인하고, 각주를 다는 것뿐이다. 이것도 고친 설교 방향과 묵상에서 출발한다.

- 페이지의 `background`(배경 메모)는 AI가 제안한 것이라 **사실 근거가 아니다.** `sermon-sources`로 출처를 찾아 각주를 달거나, 못 찾으면 `[^?]`를 달거나, 뺀다.
- 페이지의 `idea`(예화 아이디어)는 목사님이 자기 예화로 바꿀 자리다. `illustrationIdea`로 옮기고 실화처럼 바꿔 쓰지 않는다. 출처가 있는 예화는 `sermon-illustration`이 찾는다.

## 앞 단계가 바뀐 초안

설교준비 도우미에서 앞 단계(본문 · 묵상/중심 메시지 · 설교 방향)를 바꾼 초안은 `redo`가 적혀 있고 `mac`이 비어 있을 수 있다. 이 단계를 시작하기 전에 `sermon-page/SKILL.md` §3-3대로 확인한다.

- `redo`가 있거나 `sermons/<slug>/`의 파일이 지금 초안과 다른 본문·메시지·방향·개요에서 만들어졌으면, 그 파일을 이어 쓰지 않고 지금 초안으로 이 단계를 다시 만든다.
- 같은 본문의 '(이전 작업)' 초안(`kept: true`)의 작업이 그 폴더에 있으면 덮지 않고 다음 빈 번호 폴더(`sermons/<slug>-2` …)에 만든다. 폴더의 `meta.json`에 `draftId`를 적는다.
- '(이전 작업)' 초안은 목사님이 그 초안을 이어 달라고 하실 때만 다룬다.

## 할 일

설교 전체가 **한 문장 메시지 하나를 중심으로 이야기처럼 이어지게** 개요를 짠다. 이 짜임에 붙은 방법 이름(영문 약자 등)은 개요·페이지·대화 어디에도 쓰지 않는다. 부분 이름은 아래 네 개만 쓴다.

- **한 문장 메시지(`centralIdea`):** 맨 위에 한 문장(60자 안팎). 네 부분이 모두 이 문장을 향한다.
- **네 부분(`movements`):** 꼭 4개, 이 순서와 이름으로.
  1. **도입**(`intro`): 한 문장 메시지(결론)를 먼저 밝히거나, 듣는 이가 그 메시지를 생각해 보게 하는 질문으로 연다.
  2. **전개**(`development`): 이 주제를 왜 다뤄야 하는지, 성경이 이것에 대해 무엇을 말하는지를 이유와 함께 푼다. 성경·문화·역사·시대·신학의 배경을 곁들인다.
  3. **절정**(`climax`): 본문 속 이야기와 오늘 성도의 삶에서 이해를 돕는 구체적인 장면을 든다. 그때 사람들이 이 말씀을 어떻게 들었는지와 오늘 우리에게 무슨 뜻인지 되짚는다.
  4. **결말**(`conclusion`): 나눈 것을 정리하고 결론을 한 번 더 새기며, 삶의 변화와 적용을 권한다.
- **부분마다:**
  - `heading`: 제목 한 줄(25자 안팎)
  - `serves`: 이 부분이 한 문장 메시지를 어떻게 돕는지 한 문장
  - `subpoints`: 세부 내용 3~5개. 완전한 문장으로 쓰고, 내용마다 이번 본문의 절을 `refs`에 단다(모두 `check.mjs bible`로 확인한 `[^b…]`).
  - 알맞으면: `crossRefs`(함께 볼 다른 성경 구절 0~2개, `[^b…]`), `background`(배경 메모), `illustrationIdea`(예화 아이디어)
  - 결말에만: `applications` 1~3개. 누가·언제·무엇을 하는지 보이게 쓴다.
- **배경 메모:** 사실 주장이므로 RULES §3대로 각주를 단다(`[^w…]`·`[^c…]`). 출처를 못 찾으면 `[^?]`. 숫자·연도·인용을 지어내지 않는다.
- **예화 아이디어:** 목사님이 자기 예화로 바꿀 흔한 삶의 장면만 쓴다. 실제 인물·통계·인용을 쓰지 않고, 실제 있었던 일처럼 쓰지 않는다. 출처 각주를 달지 않는다(달면 점검이 멈춘다). 출처가 있는 예화는 `sermon-illustration`이 맡는다.
- **묵상이 있으면:** 개요를 그 묵상을 바탕으로 짠다. 묵상에서 나온 한 문장 메시지에 `centralFromMeditation: true`, 부분에는 `fromMeditation: true`(선택).
- **교리:** 교리 주장은 신앙고백 기준 안에서만 한다. 해석의 근거는 R 출처만(DOCTRINE.md §3).

`movements`와 `subpoints`는 문자열이 아니라 JSON 배열로 쓴다. 웹판 실측에서 배열이 문자열로 와서 실패한 적이 있다.

## 결과 모양 `outline.json`

```json
{
  "stage": "outline",
  "centralIdea": "열매는 애써 만드는 것이 아니라 주님께 붙어 있을 때 맺히는 은혜다",
  "centralFromMeditation": true,
  "movements": [
    {
      "kind": "intro", "label": "도입",
      "heading": "…", "serves": "…", "verseRange": "4-5절",
      "subpoints": [{ "text": "…", "refs": ["요한복음 15:4[^b3]"] }],
      "crossRefs": ["요한복음 14:31[^b17]"],
      "background": null,
      "illustrationIdea": "…"
    },
    { "kind": "development", "label": "전개", "…": "…" },
    { "kind": "climax", "label": "절정", "…": "…" },
    { "kind": "conclusion", "label": "결말", "…": "…", "applications": ["…"] }
  ]
}
```

| 항목 | 한도 |
| --- | --- |
| centralIdea | 100자 |
| movements | 꼭 4개, `kind`·`label` 순서: intro 도입 · development 전개 · climax 절정 · conclusion 결말 |
| heading | 40자 |
| serves | 160자 |
| verseRange | 30자(선택) |
| subpoints | 3~5개, text 200자, refs 1~3개(각 40자, 적어도 하나는 `[^b…]`) |
| crossRefs | 0~2개, 각 40자, `[^b…]` |
| background | 300자 또는 null |
| illustrationIdea | 200자 또는 null, 웹·주석 각주 없음 |
| applications | 결말에만 1~3개, 각 200자 |

예전 모양(`intro`·`points`·`conclusion`)으로 만든 `outline.json`도 그대로 점검·게시된다. 새로 만들 때는 위 모양으로 쓴다. 두 모양을 한 파일에 섞지 않는다(`movements`가 있으면 `intro`·`points`·`conclusion`은 오류).

## 교리 대조 (doctrine pass — sermon-sources/DOCTRINE.md §4)

글을 다 쓴 뒤, 마치기 전에 한다.

1. 이 단계 글이 말하는 **교리 주장**(하나님·그리스도·성령·구원·교회·성례·종말에 관한 주장)을 한 줄씩 뽑아 `doctrine` 목록에 적는다.
   - 해석 문장(이 구절이 무엇을 뜻하는가)의 근거는 **R(개혁주의) 출처만** 단다.
   - E(비개혁주의)·N(비기독교) 출처는 사실·역사·원어에만 쓴다(DOCTRINE.md §3).
2. 각 주장을 웨스트민스터 신앙고백·대요리문답·소요리문답(예장합동 헌법 교리표준)이나 공교회 신경에 맞대어 본다. 맞는 조항을 `standard`에 적는다.
   - 조항 적는 법: `WCF 16.3`, `대요리문답 66문`, `소요리문답 36문`, `사도신경`, `니케아 신경`, `칼케돈 신경`, `벨직 27조`, `하이델베르크 1문`, `도르트 5장 3항`. 둘 이상이면 `; `로 잇는다.
   - 조항 번호는 기억으로 쓰지 말고, 확신이 없으면 신앙고백 원문을 열어 확인한다.
3. 기준에 맞대어 볼 수 없는 주장은 `standard: null`로 두고 `note`에 이유를 쓴다. 글의 그 문장 끝에 `[^d?]`(교리 확인 필요)를 단다.
   - `[^d?]`가 하나라도 있으면 **오너가 검토하기 전에는 게시하지 않는다.** 목사님께 그 문장을 그대로 보여 드리고 판단을 여쭌다.
4. 이단 표지(DOCTRINE.md §6)에 걸리면 `check.mjs`가 doctrine-review 오류로 멈춘다. 문장을 고치거나 목사님께 검토를 받는다. 오류를 피하려고 표현만 비틀지 않는다.

```json
"doctrine": [
  { "assertion": "그리스도와의 연합 없이는 선한 열매가 없다", "standard": "WCF 16.3", "note": "5절" },
  { "assertion": "…", "standard": null, "note": "기준 조항을 찾지 못함" }
]
```

| 항목 | 한도 |
| --- | --- |
| doctrine | 0~12개, assertion 80자, note 160자 |

## 마치기

```bash
node "$SRC/scripts/check.mjs" stage sermons/<slug>/outline.json
node "$SRC/scripts/check.mjs" sermon sermons/<slug>
```

다음 단계: `sermon-manuscript`.
