// Shared by render.mjs (server side, at render time) and the page script (client side, for AI-edited text).
// Keep it dependency-free and deterministic: the page embeds this file's source as-is (without the export keywords).

export function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

export const MARK_RE = /\[\^(w\d+|c\d+|b\d+|u\d+|\?|d\?)\]/g;
/** Visible label of a non-Reformed source (DOCTRINE.md §3). */
export const DOC_LABEL = { E: '비개혁주의 자료', N: '비기독교 자료' };

/** The markers of a text, in order (used to refuse an AI edit that drops or adds a marker). */
export function markersOf(text) {
  return [...String(text).matchAll(MARK_RE)].map((m) => m[1]);
}

/** Plain text without markers (for counting and downloads). */
export function stripMarkers(text) {
  return String(text).replace(MARK_RE, '');
}

/**
 * Text with source markers -> HTML.
 * ctx.web[id]   = { n, ok, doc }  web [^wN] and commentary [^cN] sources share one numbering;
 *                                  ok = found (numbered); otherwise the claim renders as 확인 필요; doc = R|E|N
 *                                  (E and N carry a visible label next to the footnote number)
 * ctx.bible[id] = { label, url, aiRecall }
 * ctx.user[id]  = { label }
 * ctx.ref(n)    -> unique id for this reference (so the footnote can link back), may be null on the client
 * ctx.fnHref(n) -> href of the footnote for number n
 */
export function renderInline(text, ctx) {
  const parts = String(text).split(MARK_RE);
  // split() with one capture group: [text, id, text, id, text ...]
  let html = '';
  let pending = '';
  const flushPending = () => {
    html += esc(pending);
    pending = '';
  };
  const unverified = () => {
    // wrap the sentence right before the marker: from the last sentence end in the pending text
    const m = /^([\s\S]*[.!?。…"”'’)\]]\s+)?([\s\S]*)$/.exec(pending);
    const head = m && m[1] ? m[1] : '';
    const tail = m ? m[2] : pending;
    html += esc(head) + '<span class="unv">' + esc(tail) + '</span><span class="badge warn">AI 기억·확인 필요</span>';
    pending = '';
  };
  for (let i = 0; i < parts.length; i++) {
    if (i % 2 === 0) {
      pending += parts[i];
      continue;
    }
    const id = parts[i];
    if (id === '?') {
      unverified();
      continue;
    }
    if (id === 'd?') {
      flushPending();
      html += '<span class="badge doc">교리 확인 필요</span>';
      continue;
    }
    const kind = id[0];
    if (kind === 'w' || kind === 'c') {
      const w = ctx.web[id];
      if (!w || !w.ok) {
        unverified();
        continue;
      }
      flushPending();
      const refId = ctx.ref ? ctx.ref(w.n) : null;
      html += '<sup class="fn"><a href="' + esc(ctx.fnHref(w.n)) + '" data-fn="' + w.n + '"' + (refId ? ' id="' + esc(refId) + '"' : '') + ' aria-label="출처 ' + w.n + '">' + w.n + '</a></sup>' + (DOC_LABEL[w.doc] ? '<span class="badge doc-' + w.doc.toLowerCase() + '">' + DOC_LABEL[w.doc] + '</span>' : '');
    } else if (kind === 'b') {
      const b = ctx.bible[id];
      flushPending();
      if (!b) {
        html += '<span class="badge warn">AI 기억·확인 필요</span>';
        continue;
      }
      html += ' <a class="bref" href="' + esc(b.url) + '" target="_blank" rel="noopener">' + esc(b.label) + '</a>' + (b.aiRecall ? '<span class="badge warn">AI 기억·확인 필요</span>' : '');
    } else if (kind === 'u') {
      flushPending();
      html += '<span class="badge user">목사님 묵상에서</span>';
    }
  }
  flushPending();
  return html;
}
