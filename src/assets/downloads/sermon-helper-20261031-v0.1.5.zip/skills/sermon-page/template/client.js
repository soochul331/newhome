// Sermon page runtime (the manuscript only). Runs without any capability (footnotes); lights up downloads and light edits only when
// claude.use() resolves them. Never calls sample on load; never reads window.claude.<capability> directly.
(function () {
  const DATA = JSON.parse(document.getElementById('sermon-data').textContent);
  const $ = (sel, el) => (el || document).querySelector(sel);
  const $$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));
  const ctxClient = { web: DATA.ctx.web, bible: DATA.ctx.bible, user: DATA.ctx.user, ref: null, fnHref: (n) => '#fn-' + n };

  // ---------------------------------------------------------------- footnote links (both ways), no hash changes
  function goTo(id) {
    const el = document.getElementById(id);
    if (!el) return;
    el.scrollIntoView({ block: /^H[1-6]$/.test(el.tagName) ? 'start' : 'center' });
    el.classList.add('flash');
    if (el.tabIndex < 0 && !/^(A|BUTTON)$/.test(el.tagName)) el.tabIndex = -1;
    el.focus({ preventScroll: true });
  }
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    e.preventDefault();
    goTo(a.getAttribute('href').slice(1));
  });

  // ---------------------------------------------------------------- capabilities (design for absence)
  const use = (name) => {
    try {
      return window.claude && typeof window.claude.use === 'function' ? Promise.resolve(window.claude.use(name)).catch(() => null) : Promise.resolve(null);
    } catch (e) {
      return Promise.resolve(null);
    }
  };
  const note = (msg) => { const n = $('#note'); if (n) n.textContent = msg || ''; };

  // ---------------------------------------------------------------- edits (db edits/<blockId>)
  const edits = {};
  function applyEdits() {
    for (const b of DATA.blocks) {
      const el = document.querySelector('[data-block="' + b.id + '"]');
      if (!el) continue;
      const txt = $('.txt', el);
      const e = edits[b.id];
      if (e && typeof e.text === 'string') {
        txt.innerHTML = renderInline(e.text, ctxClient) + ' <button type="button" class="linkbtn" data-orig="' + b.id + '" aria-expanded="false">원래 문장 보기</button><span class="orig" hidden>' + renderInline(b.raw, ctxClient) + '</span>';
        el.dataset.edited = 'true';
      } else if (el.dataset.edited === 'true') {
        txt.innerHTML = el.dataset.original;
        delete el.dataset.edited;
      }
    }
  }
  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-orig]');
    if (!t) return;
    e.stopPropagation();
    const box = t.nextElementSibling;
    box.hidden = !box.hidden;
    t.setAttribute('aria-expanded', String(!box.hidden));
    t.textContent = box.hidden ? '원래 문장 보기' : '원래 문장 접기';
  });
  $$('[data-block]').forEach((el) => { el.dataset.original = $('.txt', el).innerHTML; });

  (async () => {
    const db = await use('db');
    if (!db) return;
    try {
      db.collection('edits').onSnapshot(
        (snap) => {
          for (const k of Object.keys(edits)) delete edits[k];
          snap.docs.forEach((d) => { if (d.exists) edits[d.id] = d.data(); });
          applyEdits();
        },
        () => {},
      );
    } catch (e) { /* no edits for this view */ }
  })();

  // ---------------------------------------------------------------- downloads (txt / md)
  function exportText(kind) {
    const md = kind === 'md';
    const num = (text) => text.replace(MARK_RE, (m, id) => {
      if (id === '?') return md ? ' *(확인 필요)*' : ' (확인 필요)';
      if (id === 'd?') return md ? ' *(교리 확인 필요)*' : ' (교리 확인 필요)';
      if (id[0] === 'w' || id[0] === 'c') { const w = DATA.ctx.web[id]; return w && w.ok ? (md ? '[^' + w.n + ']' : '[' + w.n + ']') + (DOC_LABEL[w.doc] ? ' (' + DOC_LABEL[w.doc] + ')' : '') : ' (확인 필요)'; }
      if (id[0] === 'b') { const b = DATA.ctx.bible[id]; return b ? ' (' + b.label + (b.aiRecall ? ', AI 기억·확인 필요' : '') + ')' : ''; }
      if (id[0] === 'u') return ' (목사님 묵상에서)';
      return '';
    });
    const out = [];
    out.push(md ? '# ' + DATA.title : DATA.title);
    out.push(DATA.passage.label);
    out.push('');
    if (DATA.message) { out.push(md ? '> ' + DATA.message : '[한 문장 메시지] ' + DATA.message); out.push(''); }
    for (const b of DATA.blocks) {
      const e = edits[b.id];
      const text = num(e ? e.text : b.raw); // edited paragraphs carry no mark (owner 2026-10-26)
      if (b.heading) { out.push(md ? '## ' + b.heading : '[' + b.heading + ']'); out.push(''); }
      out.push(b.prefix ? b.prefix + text : text);
      out.push('');
    }
    if (DATA.sourceList.length) {
      out.push(md ? '## 각주' : '[각주]');
      out.push('');
      for (const s of DATA.sourceList) out.push(md ? '[^' + s.n + ']: ' + s.line : '[' + s.n + '] ' + s.line);
    }
    return out.join('\n') + '\n';
  }
  (async () => {
    const downloads = await use('downloads');
    if (!downloads) return;
    const box = $('#dl');
    box.hidden = false;
    $$('button[data-dl]', box).forEach((btn) => btn.addEventListener('click', async () => {
      const kind = btn.dataset.dl;
      try {
        await downloads.save({ filename: DATA.fileBase + '.' + kind, data: exportText(kind) });
        note('내려받기를 보냈어요.');
      } catch (e) {
        const code = e && e.code;
        if (code === 'declined') note('');
        else if (code === 'rate_limited') note('잠시 뒤에 다시 눌러 주세요.');
        else note('이 화면에서는 내려받기를 쓸 수 없어요.');
      }
    }));
  })();

  // ---------------------------------------------------------------- light edits (sample + db), owner/editors only
  const KIND = {
    shorter: { label: '더 짧게', ask: '핵심만 남겨 지금 길이의 70% 안팎으로 더 짧게' },
    softer: { label: '더 부드럽게', ask: '뜻은 그대로 두고 더 따뜻하고 부드러운 말투로' },
    stronger: { label: '더 힘 있게', ask: '뜻은 그대로 두고 더 힘 있고 분명한 말투로' },
  };
  function prompt(raw, kind) {
    return [
      '다음은 한국어 설교 준비 자료의 한 문단입니다. 이 문단을 ' + KIND[kind].ask + ' 고쳐 주세요.',
      '규칙:',
      '- 새로운 사실, 인물, 숫자, 인용, 성경 구절을 더하지 마세요.',
      '- 문단 안의 [^w1], [^c1], [^b2], [^u1], [^?], [^d?] 같은 표시는 글자 그대로, 같은 개수로 남기세요.',
      '- 원래 문체(존댓말 설교체 또는 서술체)를 유지하세요.',
      '- 고친 문단 하나만 쓰고, 설명이나 따옴표를 붙이지 마세요.',
      '문단:',
      '<<<',
      raw,
      '>>>',
    ].join('\n');
  }
  const sameMarkers = (a, b) => JSON.stringify(markersOf(a).sort()) === JSON.stringify(markersOf(b).sort());

  (async () => {
    const [sample, db, user] = await Promise.all([use('sample'), use('db'), use('user')]);
    if (!sample || !db || !user) return;
    let canEdit = false;
    try { canEdit = !!(await user.canEdit()); } catch (e) { canEdit = false; }
    if (!canEdit) return;
    const sheet = $('#sheet');
    const status = $('#sheet-status');
    const preview = $('#sheet-preview');
    let current = null;
    let result = null;
    let ctl = null;
    let off = false;
    $$('.blk.editable-candidate').forEach((el) => {
      el.classList.add('editable');
      el.tabIndex = 0;
      el.setAttribute('role', 'button');
      el.setAttribute('aria-label', '이 문단 고치기');
      const pick = () => {
        if (off) return;
        $$('.blk.selected').forEach((x) => x.classList.remove('selected'));
        el.classList.add('selected');
        current = DATA.blocks.find((b) => b.id === el.dataset.block);
        result = null;
        preview.hidden = true;
        $('#sheet-save').hidden = true;
        status.textContent = current.label + ' — 어떻게 고칠까요?';
        sheet.hidden = false;
      };
      el.addEventListener('click', (e) => { if (!e.target.closest('a, button')) pick(); });
      el.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } });
    });
    const close = () => {
      if (ctl) ctl.abort();
      sheet.hidden = true;
      $$('.blk.selected').forEach((x) => x.classList.remove('selected'));
      current = null;
    };
    $('#sheet-close').addEventListener('click', close);
    $$('#sheet [data-kind]').forEach((btn) => btn.addEventListener('click', async () => {
      if (!current) return;
      const kind = btn.dataset.kind;
      const base = edits[current.id] ? edits[current.id].text : current.raw;
      ctl = new AbortController();
      $$('#sheet [data-kind]').forEach((b) => (b.disabled = true));
      $('#sheet-save').hidden = true;
      preview.hidden = false;
      preview.textContent = '생각하는 중…';
      status.textContent = KIND[kind].label + ' 고치는 중';
      try {
        const r = await sample(prompt(base, kind), { signal: ctl.signal, cache: false, onText: (u) => { preview.textContent = u.text; } });
        const text = r.text.trim();
        if (!sameMarkers(base, text)) {
          preview.textContent = text;
          status.textContent = '출처 표시가 바뀌어서 저장하지 않아요. 다시 시도해 주세요.';
          result = null;
        } else {
          result = { text, kind };
          preview.innerHTML = renderInline(text, ctxClient);
          status.textContent = r.truncated ? '답이 중간에 끊겼어요. 저장하기 전에 확인해 주세요.' : '미리보기입니다. 저장하면 이 문단이 바뀌고, \'원래 문장 보기\'로 원래 문장을 볼 수 있어요.';
          $('#sheet-save').hidden = false;
        }
      } catch (e) {
        const code = e && e.code;
        if (code === 'not_granted' || code === 'sampling_disabled' || code === 'not_declared' || code === 'capability_disabled' || code === 'capability_removed') {
          off = true;
          close();
          $$('.blk.editable').forEach((el) => { el.classList.remove('editable'); el.removeAttribute('role'); el.removeAttribute('tabindex'); el.removeAttribute('aria-label'); });
          note('이 화면에서는 고치기를 쓸 수 없어요.');
          return;
        }
        preview.hidden = true;
        if (code === 'cancelled') status.textContent = '';
        else if (code === 'rate_limited') status.textContent = '나중에 다시 시도해 주세요.';
        else status.textContent = '고치지 못했어요. 잠시 뒤 다시 눌러 주세요.';
      } finally {
        $$('#sheet [data-kind]').forEach((b) => (b.disabled = false));
      }
    }));
    $('#sheet-save').addEventListener('click', async () => {
      if (!current || !result) return;
      const id = current.id;
      $('#sheet-save').disabled = true;
      try {
        await db.doc('edits/' + id).set({ text: result.text, kind: result.kind, savedAt: new Date().toISOString() });
        edits[id] = { text: result.text, kind: result.kind };
        applyEdits();
        note('저장했어요.');
        close();
      } catch (e) {
        status.textContent = '저장하지 못했어요. 저장 권한이 있는지 확인해 주세요.';
      } finally {
        $('#sheet-save').disabled = false;
      }
    });
    $('#edit-hint').hidden = false;
  })();
})();
