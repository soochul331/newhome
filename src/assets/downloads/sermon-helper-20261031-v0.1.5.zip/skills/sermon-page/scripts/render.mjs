#!/usr/bin/env node
// sermon-page 렌더러 — Node 18 이상, 다른 패키지 없음.
//   node render.mjs sermons/<slug>          → sermons/<slug>/page.html
// 같은 JSON이면 바이트까지 같은 HTML을 만든다(시각·난수 없음). 원고만 보여 주고, 각주는 sources.json에 있는 것만.
// 대한성서공회 읽기 링크 규칙은 sermon-start src/core/bible/link.ts를 옮겨 쓴 것(version=GAE만).

import { readFileSync, writeFileSync, existsSync, realpathSync } from 'node:fs';
import { join, dirname, basename } from 'node:path';
import { fileURLToPath } from 'node:url';
import { esc, renderInline, MARK_RE, stripMarkers, DOC_LABEL } from '../template/inline.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
const T = (f) => readFileSync(join(HERE, '..', 'template', f), 'utf8');

// The sermon page shows the manuscript only (owner 2026-10-26): title, passage, the one-point sentence, the manuscript
// in its parts, and footnotes at the bottom when the sources were checked. Direction, outline, exegesis,
// illustration and application stay in 설교준비 도우미 (the draft) and are not repeated here.
// a four-part manuscript names its parts (도입·전개·절정·결말); an older one keeps its own section headings only
const PART_LABEL = { intro: '도입', development: '전개', climax: '절정', conclusion: '결말' };
const READER = 'https://www.bskorea.or.kr/bible/korbibReadpage.php';
const BOOK_CODES = {
  1: 'gen', 2: 'exo', 3: 'lev', 4: 'num', 5: 'deu', 6: 'jos', 7: 'jdg', 8: 'rut', 9: '1sa', 10: '2sa', 11: '1ki', 12: '2ki', 13: '1ch', 14: '2ch', 15: 'ezr', 16: 'neh', 17: 'est', 18: 'job', 19: 'psa', 20: 'pro', 21: 'ecc', 22: 'sng',
  23: 'isa', 24: 'jer', 25: 'lam', 26: 'ezk', 27: 'dan', 28: 'hos', 29: 'jol', 30: 'amo', 31: 'oba', 32: 'jnh', 33: 'mic', 34: 'nam', 35: 'hab', 36: 'zep', 37: 'hag', 38: 'zec', 39: 'mal',
  40: 'mat', 41: 'mrk', 42: 'luk', 43: 'jhn', 44: 'act', 45: 'rom', 46: '1co', 47: '2co', 48: 'gal', 49: 'eph', 50: 'php', 51: 'col', 52: '1th', 53: '2th', 54: '1ti', 55: '2ti', 56: 'tit', 57: 'phm',
  58: 'heb', 59: 'jas', 60: '1pe', 61: '2pe', 62: '1jn', 63: '2jn', 64: '3jn', 65: 'jud', 66: 'rev',
};
/** Same as src/core/bible/link.ts readerLink: version=GAE, book code, chap, sec. */
export function readerLink(bookId, chap, verse) {
  const code = BOOK_CODES[bookId];
  if (!code) return `${READER}?version=GAE`;
  const q = new URLSearchParams({ version: 'GAE', book: code });
  if (chap) q.set('chap', String(chap));
  if (chap && verse) q.set('sec', String(verse));
  return `${READER}?${q.toString()}`;
}

const readJson = (dir, f) => (existsSync(join(dir, f)) ? JSON.parse(readFileSync(join(dir, f), 'utf8')) : null);
const jsonForScript = (v) => JSON.stringify(v).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
const kstDay = (iso) => (iso ? new Date(new Date(iso).getTime() + 9 * 3600e3).toISOString().slice(0, 10) : '');

const isFourMs = (ms) => (ms?.sections ?? []).some((x) => x.kind === 'development' || x.kind === 'climax');

/** Build the page model from a sermon folder. Pure function of the JSON files. */
export function buildModel(dir) {
  const ledger = readJson(dir, 'sources.json');
  const sources = ledger?.sources ?? [];
  const ms = readJson(dir, 'manuscript.json');
  const outline = readJson(dir, 'outline.json');
  const angles = readJson(dir, 'angles.json');
  const ex = readJson(dir, 'exegesis.json');
  const meta = readJson(dir, 'meta.json') ?? {};
  for (const s of sources) if (s.kind === 'bible' && /version=HAN/i.test(s.readerUrl ?? '')) throw new Error(`${s.id}: 개역한글(version=HAN) link refused`);

  // retired sources (replaced by another, kept in sources.json for the record) are not shown or counted;
  // commentary sources (owner's library, [^cN]) are numbered with the web sources
  const web = sources.filter((s) => (s.kind === 'web' || s.kind === 'commentary') && !s.retired);
  const bible = sources.filter((s) => s.kind === 'bible');
  const users = sources.filter((s) => s.kind === 'user');

  // manuscript blocks in page order (paragraphs, then the section's quoted verses)
  const four = isFourMs(ms);
  const blocks = [];
  const add = (id, label, raw, o = {}) => { if (typeof raw === 'string' && raw.length) blocks.push({ tab: 'manuscript', id, label, raw, ...o }); };
  (ms?.sections ?? []).forEach((s, i) => {
    (s.paragraphs ?? []).forEach((p, j) => add(`ms.${i}.p${j}`, `${s.heading} · 문단 ${j + 1}`, p, { group: `sec${i}`, heading: j === 0 ? s.heading : undefined, editable: true }));
    (s.quotes ?? []).forEach((q, j) => add(`ms.${i}.q${j}`, `${s.heading} · 인용 ${q.refText}`, q.text, { group: `sec${i}`, cite: q.refText }));
  });

  // numbering: checked sources in order of first appearance in the manuscript
  const byId = new Map(sources.map((s) => [s.id, s]));
  const num = new Map();
  for (const b of blocks) for (const m of b.raw.matchAll(MARK_RE)) {
    const s = byId.get(m[1]);
    if (s && (s.kind === 'web' || s.kind === 'commentary') && s.status === 'found' && !s.retired && !num.has(s.id)) num.set(s.id, num.size + 1);
  }
  const ctx = { web: {}, bible: {}, user: {} };
  for (const s of web) ctx.web[s.id] = { n: num.get(s.id) ?? 0, ok: s.status === 'found' && num.has(s.id), ...(s.doctrine ? { doc: s.doctrine } : {}) };
  for (const s of bible) ctx.bible[s.id] = { label: s.label, url: readerLink(s.bookId, s.chap, s.v1), aiRecall: s.wording === 'ai-recall' };
  for (const s of users) ctx.user[s.id] = { label: s.label };

  // needs-check = manuscript strings with [^?] (same rule as check.mjs claims.unverified)
  const unverified = blocks.filter((b) => /\[\^\?\]/.test(b.raw));
  const cited = (k) => sources.filter((s) => s.kind === k && blocks.some((b) => b.raw.includes(`[^${s.id}]`)));
  const counts = { sourced: num.size, bible: cited('bible').length, unverified: unverified.length };
  counts.text = `확인된 출처 ${counts.sourced} · 성경 구절 ${counts.bible} · 확인 필요 ${counts.unverified}`;
  // manuscript length = characters of its paragraphs and quotes, markers removed (spaces included)
  const msChars = blocks.reduce((k, b) => k + [...stripMarkers(b.raw)].length, 0);

  const ref = meta.ref ?? ex?.passage ?? null;
  const passageLabel = ref?.label ?? meta.passage ?? '';
  const title = meta.title ?? ms?.title ?? (angles && angles.chosen != null ? angles.angles[angles.chosen].title : passageLabel || basename(dir));
  const message = stripMarkers(ms?.message ?? outline?.centralIdea ?? '').trim();
  const category = meta.category ?? '미분류';
  const preparedAt = meta.preparedAt ?? kstDay(sources.map((s) => s.checkedAt).filter(Boolean).sort().at(-1));
  // a commentary shows author, book and page only: its text stays in the owner's library (never published)
  const sourceLine = (s) => s.kind === 'commentary' ? `${commentaryLabel(s)}${DOC_LABEL[s.doctrine] ? ` (${DOC_LABEL[s.doctrine]})` : ''}` : `${s.title ?? s.url} — ${[s.site, s.author].filter(Boolean).join(' · ')} — ${s.finalUrl ?? s.url} — 접속 ${s.accessedAt} — 「${s.quote}」${s.quotedFrom ? ` (2차 인용: ${s.quotedFrom})` : ''}${s.tier === 'B' ? ' (참고)' : ''}${DOC_LABEL[s.doctrine] ? ` (${DOC_LABEL[s.doctrine]})` : ''}`;
  const numbered = [...num.entries()].map(([id, n]) => ({ n, s: byId.get(id) }));
  return {
    dir, title, category, preparedAt, message, four, manuscript: ms, blocks, ctx, counts, unverified, numbered, msChars,
    checked: !!ledger, bible, users,
    passage: { label: passageLabel, url: ref?.bookId ? readerLink(ref.bookId, ref.chap, ref.v1) : null },
    data: {
      title, preparedAt, fileBase: basename(dir), message,
      passage: { label: passageLabel }, counts,
      ctx: { web: ctx.web, bible: ctx.bible, user: ctx.user },
      blocks: blocks.map((b) => ({ id: b.id, label: b.label, raw: b.raw, ...(b.heading ? { heading: b.heading } : {}), ...(b.cite ? { prefix: `${b.cite}: ` } : {}) })),
      sourceList: numbered.map(({ n, s }) => ({ n, line: sourceLine(s) })),
    },
    sourceLine,
  };
}

// ---------------------------------------------------------------- HTML
function blockHtml(m, b, tag, refs) {
  const ctx = { ...m.ctx, ref: (n) => refs.next(n), fnHref: (n) => `#fn-${n}` };
  const domId = `blk-${b.id.replace(/\./g, '-')}`;
  return `<${tag} class="blk${b.editable ? ' editable-candidate' : ''}" id="${domId}" data-block="${esc(b.id)}"><span class="txt">${renderInline(b.raw, ctx)}</span></${tag}>`;
}

function refTracker() {
  const seen = new Map(); // n -> count
  return {
    next(n) {
      const c = (seen.get(n) ?? 0) + 1;
      seen.set(n, c);
      return `ref-${n}-${c}`;
    },
  };
}

const commentaryLabel = (s) => `주석: ${s.author ?? '저자 미상'}, ${s.title}, ${s.page}쪽`;
function sourceHtml(s) {
  if (s.kind === 'commentary') return `<span class="src-title">${esc(commentaryLabel(s))}</span>${DOC_LABEL[s.doctrine] ? ` <span class="badge doc-${s.doctrine.toLowerCase()}">${DOC_LABEL[s.doctrine]}</span>` : ''}`;
  const who = [s.site, s.author].filter(Boolean).map(esc).join(' · ');
  return `<span class="src-title">${esc(s.title ?? s.url)}</span> — ${who} — <a class="url" href="${esc(s.finalUrl ?? s.url)}" target="_blank" rel="noopener">${esc(s.finalUrl ?? s.url)}</a> — 접속 ${esc(s.accessedAt)}<span class="quote">「${esc(s.quote)}」${s.quotedFrom ? ` <span class="badge user">2차 인용: ${esc(s.quotedFrom)}</span>` : ''}${s.tier === 'B' ? ' <span class="badge warn">참고</span>' : ''}${DOC_LABEL[s.doctrine] ? ` <span class="badge doc-${s.doctrine.toLowerCase()}">${DOC_LABEL[s.doctrine]}</span>` : ''}</span>`;
}

/** Footnotes at the bottom, only when the sources were checked and the manuscript cites one. */
function footnotes(m) {
  if (!m.checked || !m.numbered.length) return '';
  const items = m.numbered.map(({ n, s }) => `<li id="fn-${n}" value="${n}">${sourceHtml(s)} <a href="#ref-${n}-1" class="back" aria-label="본문으로 돌아가기">↩</a></li>`).join('');
  return `<aside class="fns" aria-labelledby="fns-h"><h2 id="fns-h">각주</h2><ol>${items}</ol></aside>`;
}

function manuscriptHtml(m, refs) {
  return (m.manuscript?.sections ?? []).map((s, i) => {
    const bs = m.blocks.filter((b) => b.group === `sec${i}`);
    const paras = bs.filter((b) => !b.cite).map((b) => blockHtml(m, b, 'p', refs)).join('');
    const quotes = bs.filter((b) => b.cite).map((b) => `<blockquote class="q">${blockHtml(m, b, 'div', refs)}<cite>${esc(b.cite)} · 개역개정</cite></blockquote>`).join('');
    const part = m.four && PART_LABEL[s.kind] ? `<p class="s-part-k">${PART_LABEL[s.kind]}</p>` : '';
    return `<section class="s-part" aria-labelledby="ms-sec-${i}">${part}<h2 id="ms-sec-${i}">${esc(s.heading)}</h2>${paras}${quotes}</section>`;
  }).join('');
}

export function renderPage(dir) {
  const m = buildModel(dir);
  const refs = refTracker();
  const body = m.manuscript ? manuscriptHtml(m, refs) : `<p class="placeholder">아직 원고가 없어요.</p>`;
  const inlineSrc = T('inline.mjs').replace(/^export /gm, '');
  const html = `<title>${esc(m.title)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;600;700&amp;family=Noto+Serif+KR:wght@400;700&amp;display=swap">
<style>
${T('style.css')}${T('page.css')}</style>
<div class="page ko" lang="ko">
<article class="sermon" aria-labelledby="s-title">
<header class="s-head">
<h1 id="s-title">${esc(m.title)}</h1>
<p class="s-passage">${m.passage.url ? `<a class="passage" href="${esc(m.passage.url)}" target="_blank" rel="noopener">${esc(m.passage.label)} · 개역개정 읽기</a>` : `<span class="passage">${esc(m.passage.label)}</span>`}</p>
<div class="s-tools"><div class="actions" id="dl" hidden><button type="button" class="btn" data-dl="txt">txt 내려받기</button><button type="button" class="btn" data-dl="md">md 내려받기</button></div>
<p class="note" id="edit-hint" hidden>문단을 누르면 '더 짧게 · 더 부드럽게 · 더 힘 있게'로 고칠 수 있어요. 고친 문단은 '원래 문장 보기'로 원래 문장과 견줘 볼 수 있어요.</p>
<p class="note" id="note" role="status" aria-live="polite"></p></div>
</header>
${m.message ? `<section class="s-message" aria-labelledby="s-message-h"><p class="s-message-k" id="s-message-h">한 문장 메시지</p><p class="s-one">${esc(m.message)}</p></section>\n` : ''}<div class="manuscript">
${body}
</div>
${footnotes(m)}
</article>
</div>
<div class="sheet" id="sheet" hidden role="dialog" aria-label="문단 고치기"><div class="col">
<p class="note" id="sheet-status" role="status" aria-live="polite"></p>
<div class="row"><button type="button" class="btn" data-kind="shorter">더 짧게</button><button type="button" class="btn" data-kind="softer">더 부드럽게</button><button type="button" class="btn" data-kind="stronger">더 힘 있게</button><button type="button" class="btn" id="sheet-close">닫기</button></div>
<div class="preview" id="sheet-preview" hidden></div>
<div class="row"><button type="button" class="btn primary" id="sheet-save" hidden>저장</button></div>
</div></div>
<script type="application/json" id="sermon-data">${jsonForScript(m.data)}</script>
<script>
${inlineSrc}
${T('client.js')}</script>
`;
  return { html, model: m };
}

const isMain = (() => {
  try { return !!process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url)); } catch { return false; }
})();
if (isMain) {
  const dir = process.argv[2];
  if (!dir) { console.error('usage: node render.mjs sermons/<slug>'); process.exit(2); }
  try {
    const { html, model } = renderPage(dir);
    writeFileSync(join(dir, 'page.html'), html);
    console.log(JSON.stringify({ wrote: join(dir, 'page.html'), bytes: Buffer.byteLength(html), title: model.title, counts: model.counts, footnotes: model.checked ? model.numbered.length : 0 }, null, 2));
  } catch (e) {
    console.error(String(e?.message ?? e));
    process.exit(1);
  }
}
