// 설교준비 도우미 — pure logic shared by the page script (embedded without the export keywords) and the node tests.
// No DOM, no capabilities, no clock, no randomness: same input -> same output.

/** Books are injected by the page (BOOKS from sermon-sources bible.json: id, name, abbrevs, code, chapters). */
export const READER = 'https://www.bskorea.or.kr/bible/korbibReadpage.php';
export function readerLink(book, chap, verse) {
  const q = new URLSearchParams({ version: 'GAE', book: book.code });
  if (chap) q.set('chap', String(chap));
  if (chap && verse) q.set('sec', String(verse));
  return `${READER}?${q.toString()}`;
}
export function findBook(books, name) {
  const n = String(name ?? '').normalize('NFC').replace(/\s+/g, '').replace(/[.]$/, '');
  if (!n) return null;
  return books.find((b) => b.name === n || b.abbrevs.includes(n) || b.code === n.toLowerCase()) ?? null;
}
export function refLabel(book, chap, v1, v2) {
  return `${book.name} ${chap}:${v1}${v2 && v2 !== v1 ? `-${v2}` : ''}`;
}
/** A reference is real when the book exists and the chapter and verses are inside its verse counts. */
export function checkRef(books, { book: name, bookId, chapter, verseStart, verseEnd }) {
  const b = bookId != null ? books.find((x) => x.id === bookId) : findBook(books, name);
  const chap = Number(chapter), v1 = Number(verseStart), v2 = verseEnd == null || verseEnd === '' ? v1 : Number(verseEnd);
  if (!b || !Number.isInteger(chap) || !Number.isInteger(v1) || !Number.isInteger(v2)) return null;
  const n = b.chapters[chap - 1];
  if (!n || v1 < 1 || v1 > n || v2 < v1 || v2 > n) return null;
  return { bookId: b.id, code: b.code, chap, v1, v2, label: refLabel(b, chap, v1, v2), url: readerLink(b, chap, v1) };
}
/**
 * Free text -> reference. "요한복음 15:1-11", "요 15:1-11", "요한복음 15장 1-11절", "요한복음 15장" (whole chapter), "시편 23편".
 * Returns {ref} or {error} (a short Korean reason to show under the field).
 */
export function parsePassage(books, text) {
  const t = String(text ?? '').normalize('NFC').trim();
  if (!t) return { error: null };
  const m = /^(.+?)\s*(\d{1,3})\s*(?:[:：]|[장편]\s*)?\s*(?:(\d{1,3})\s*(?:[-–~]\s*(\d{1,3}))?\s*절?)?$/.exec(t);
  if (!m) return { error: '본문 주소를 "요한복음 15:1-11"처럼 써 주세요.' };
  const b = findBook(books, m[1]);
  if (!b) return { error: `'${m[1].trim()}'라는 책을 찾지 못했어요.` };
  const chap = Number(m[2]);
  if (!b.chapters[chap - 1]) return { error: `${b.name}은 ${b.chapters.length}장까지 있어요.` };
  const v1 = m[3] ? Number(m[3]) : 1;
  const v2 = m[4] ? Number(m[4]) : m[3] ? v1 : b.chapters[chap - 1];
  const ref = checkRef(books, { bookId: b.id, chapter: chap, verseStart: v1, verseEnd: v2 });
  return ref ? { ref } : { error: `${b.name} ${chap}장은 ${b.chapters[chap - 1]}절까지 있어요.` };
}
/** A verse range inside the passage's book: "15:1-4", "1-4절" / "1-4" (passage chapter), "16:1". */
export function parseRange(books, ref, text) {
  const t = String(text ?? '').normalize('NFC').trim();
  let m = /^(\d{1,3})\s*[:：]\s*(\d{1,3})(?:\s*[-–~]\s*(\d{1,3}))?$/.exec(t);
  if (m) return checkRef(books, { bookId: ref.bookId, chapter: m[1], verseStart: m[2], verseEnd: m[3] });
  m = /^(\d{1,3})(?:\s*[-–~]\s*(\d{1,3}))?\s*절?$/.exec(t);
  if (m) return checkRef(books, { bookId: ref.bookId, chapter: ref.chap, verseStart: m[1], verseEnd: m[2] });
  return null;
}
export const rangeText = (r) => (r ? `${r.chap}:${r.v1}${r.v2 !== r.v1 ? `-${r.v2}` : ''}` : '');

// ---------------------------------------------------------------- AI prompts (sample.json) and result checks
export const RULES = [
  '개혁주의 신앙고백(웨스트민스터 신앙고백과 대소요리문답) 안에서 답하세요.',
  '성경 본문의 문장을 옮겨 쓰지 마세요. 성경은 "책 장:절" 주소로만 가리키세요.',
  '출처·저자·책 이름·통계·예화·실제 인물에 관한 이야기나 사실을 쓰지 말고, 이름도 대지 마세요.',
  '확실하지 않은 것은 지어내지 마세요.',
  '한국어 존댓말로 쓰세요.',
  '설명이나 다른 글 없이, 아래 모양의 JSON 하나만 답하세요.',
];
const block = (label, text) => `${label}:\n<<<\n${String(text ?? '').trim()}\n>>>`;
const prompt = (task, parts, shape) => [task, '', '지킬 것:', ...RULES.map((r) => `- ${r}`), '', ...parts, '', 'JSON 모양:', shape].join('\n');

export function promptPassages({ message, audience }) {
  return prompt('목사님이 설교할 성경 본문을 3개 추천해 주세요. 각 본문마다 왜 맞는지 한 줄로 쓰세요.',
    [block('전하고 싶은 메시지', message), block('듣는 사람들의 상황', audience)],
    '{"passages":[{"book":"요한복음","chapter":15,"verseStart":1,"verseEnd":11,"reason":"한 줄 이유"}]}');
}
export function promptFlow({ passage, central }) {
  return prompt('설교의 중심 메시지를 바탕으로 전체 메시지 흐름(도입 → 전개 → 결론)을 제안해 주세요. 각 부분은 한두 문장으로 짧게 쓰세요.',
    [block('설교 본문', passage || '아직 정하지 않음'), block('중심 메시지', central)],
    '{"intro":"도입 한두 문장","body":"전개 한두 문장","conclusion":"결론 한두 문장"}');
}
export function promptDirections({ passage, meditation, central, flow }) {
  const parts = [block('설교 본문', passage)];
  if (meditation) parts.push(block('목사님의 묵상', meditation));
  else parts.push(block('중심 메시지', central), block('메시지 흐름', flow ? `도입: ${flow.intro}\n전개: ${flow.body}\n결론: ${flow.conclusion}` : ''));
  return prompt(`이 본문으로 설교할 방향을 3개 추천해 주세요. ${meditation ? '목사님의 묵상을 존중해 그 묵상에서 출발하세요.' : '중심 메시지에서 출발하세요.'} 각 방향은 제목 하나와 한 문단 설명으로 쓰세요.`,
    parts, '{"directions":[{"title":"방향 제목","summary":"한 문단 설명"}]}');
}
// 개요: one sentence on top, then exactly four parts in this order. The page never names a method.
export const MOVES = [
  { key: 'intro', label: '도입', rule: '한 문장 메시지(결론)를 먼저 밝히거나, 듣는 이가 그 메시지를 생각해 보게 하는 질문으로 엽니다.' },
  { key: 'development', label: '전개', rule: '이 주제를 왜 다뤄야 하는지, 성경이 이것에 대해 무엇을 말하는지를 이유와 함께 풀고, 성경·문화·역사·시대·신학의 배경을 곁들입니다.' },
  { key: 'climax', label: '절정', rule: '본문 속 이야기와 오늘 성도의 삶에서 이해를 돕는 구체적인 장면을 들고, 그때 사람들이 이 말씀을 어떻게 들었는지와 오늘 우리에게 무슨 뜻인지 되짚습니다.' },
  { key: 'conclusion', label: '결말', rule: '나눈 것을 정리하고 결론을 한 번 더 새기며, 삶의 변화와 적용을 권합니다.' },
];
export const SUBS = { min: 3, max: 5 };
export const APPS = { min: 1, max: 3 };
// the outline asks for illustration ideas and background notes: rule 3 is narrowed for it, the rest stay
export const OUTLINE_RULES = [
  RULES[0], RULES[1],
  '출처·저자·책 이름·통계·실제 인물에 관한 이야기를 쓰지 말고, 이름도 대지 마세요. 인용문을 지어내지 마세요.',
  '예화는 실제 있었던 일처럼 쓰지 말고, 목사님이 자기 예화로 바꿔 쓸 "예화 아이디어"(흔한 삶의 장면)로만 쓰세요.',
  '배경 설명은 널리 알려진 일반적인 내용만 짧게 쓰고, 숫자·연도·인용을 지어내지 마세요(목사님이 확인한 뒤에 씁니다).',
  ...RULES.slice(3),
];
export function promptOutlines({ passage, ref, direction }) {
  const task = [
    `고른 설교 방향으로 개요를 하나 써 주세요. 설교 전체가 한 문장 메시지 하나를 중심으로 이야기처럼 이어지게 짭니다.`,
    `맨 위에 한 문장 메시지(message)를 쓰고, 그 아래 네 부분을 꼭 이 순서와 이름으로 쓰세요.`,
    ...MOVES.map((m, i) => `${i + 1}) ${m.label}: ${m.rule}`),
    `부분마다 heading(짧은 제목 한 줄), serves(이 부분이 한 문장 메시지를 어떻게 돕는지 한 문장), points(세부 내용 ${SUBS.min}~${SUBS.max}개, 완전한 문장, 내용마다 ${ref.label} 안의 절 주소)를 쓰세요.`,
    `알맞으면 cross(함께 볼 다른 성경 구절 하나), background(배경 메모), idea(예화 아이디어)를 더하고, 맞지 않으면 빈 값으로 두세요.`,
    `결말에는 applications(이번 주에 해 볼 구체적인 적용 ${APPS.min}~${APPS.max}개)를 쓰세요.`,
    '설교 방향 설명에 목사님의 요청이 적혀 있으면 개요에 그대로 반영하세요.',
  ].join('\n');
  const mv = (label, extra) => `{"label":"${label}","heading":"짧은 제목","serves":"한 문장 메시지를 돕는 점","points":[{"text":"완전한 문장","chapter":${ref.chap},"verseStart":${ref.v1},"verseEnd":${ref.v1}}],"cross":{"book":"책 이름","chapter":1,"verseStart":1,"verseEnd":1},"background":"","idea":""${extra || ''}}`;
  return [task, '', '지킬 것:', ...OUTLINE_RULES.map((r) => `- ${r}`), '',
    block('설교 본문', passage), block('설교 방향 제목', direction.title), block('설교 방향 설명', direction.body), '',
    'JSON 모양:', `{"outline":{"message":"한 문장 메시지","movements":[${MOVES.map((m) => mv(m.label, m.key === 'conclusion' ? ',"applications":["구체적인 적용"]' : '')).join(',')}]}}`].join('\n');
}

const str = (v, max) => (typeof v === 'string' && v.trim() ? v.trim().slice(0, max) : null);
/** Passages: keep real references only (bible.json), at most 3. */
export function checkPassages(books, v) {
  const list = Array.isArray(v?.passages) ? v.passages : [];
  const items = [];
  let dropped = 0;
  for (const p of list) {
    const ref = p && typeof p === 'object' ? checkRef(books, { book: p.book, chapter: p.chapter, verseStart: p.verseStart, verseEnd: p.verseEnd }) : null;
    const reason = str(p?.reason, 160);
    if (!ref || !reason || items.some((x) => x.label === ref.label)) { dropped++; continue; }
    if (items.length < 3) items.push({ ...ref, reason });
  }
  return { items, dropped };
}
export function checkFlow(v) {
  const f = { intro: str(v?.intro, 300), body: str(v?.body, 300), conclusion: str(v?.conclusion, 300) };
  return f.intro && f.body && f.conclusion ? f : null;
}
export function checkDirections(v) {
  const list = Array.isArray(v?.directions) ? v.directions : [];
  const items = list.map((d) => ({ title: str(d?.title, 80), body: str(d?.summary ?? d?.body, 800) })).filter((d) => d.title && d.body).slice(0, 3);
  return { items, dropped: list.length - items.length };
}
/**
 * Outlines: one sentence + exactly four parts in order (도입·전개·절정·결말), each with a heading, how it serves the
 * sentence and 3-5 sub-points whose verses exist in the passage's book (bible.json); 결말 has 1-3 applications.
 * A sub-point with a missing verse is dropped (counted); an outline that falls short of the shape is dropped.
 */
export function checkOutlines(books, ref, v) {
  // the page asks for one outline ({outline}); a list ({outlines}, older drafts and answers) is read the same way
  const list = v?.outline && typeof v.outline === 'object' ? [v.outline] : Array.isArray(v?.outlines) ? v.outlines : [];
  const items = [];
  let dropped = 0;
  for (const o of list) {
    const message = str(o?.message, 200);
    const mvs = Array.isArray(o?.movements) ? o.movements : [];
    const out = [];
    let ok = !!message && mvs.length === MOVES.length;
    MOVES.forEach((m, i) => {
      const x = mvs[i];
      if (!ok || str(x?.label, 10) !== m.label) { ok = false; return; }
      const subs = [];
      for (const p of Array.isArray(x.points) ? x.points : []) {
        const r = p && typeof p === 'object' ? checkRef(books, { bookId: ref.bookId, chapter: p.chapter ?? ref.chap, verseStart: p.verseStart, verseEnd: p.verseEnd }) : null;
        const text = str(p?.text, 300);
        if (!r || !text) { dropped++; continue; }
        if (subs.length < SUBS.max) subs.push({ text, range: rangeText(r) });
      }
      const cross = x.cross && typeof x.cross === 'object' ? checkRef(books, x.cross) : null;
      if (x.cross && typeof x.cross === 'object' && x.cross.book && !cross) dropped++;
      const mv = { key: m.key, label: m.label, heading: str(x.heading, 80), serves: str(x.serves, 300), subs, cross: cross ? cross.label : '', background: str(x.background, 400) || '', idea: str(x.idea, 300) || '' };
      if (m.key === 'conclusion') mv.applications = (Array.isArray(x.applications) ? x.applications : []).map((a) => str(a, 200)).filter(Boolean).slice(0, APPS.max);
      if (!mv.heading || !mv.serves || subs.length < SUBS.min || (mv.applications && mv.applications.length < APPS.min)) ok = false;
      out.push(mv);
    });
    if (ok && items.length < 3) items.push({ message, movements: out });
    else if (!ok) dropped++;
  }
  return { items, dropped };
}
const text0 = (v) => (typeof v === 'string' ? v : '');
/**
 * Any outline (a suggestion or the edited one) as {message, movements[4], migrated}. An outline saved before the four
 * parts ({points:[{title, range}]}) is shown with its points as the sub-points of 전개: nothing of it is lost.
 */
export function outlineOf(o) {
  if (Array.isArray(o?.movements)) {
    return {
      message: text0(o.message),
      movements: MOVES.map((m, i) => {
        const x = o.movements[i] && typeof o.movements[i] === 'object' ? o.movements[i] : {};
        const mv = { key: m.key, label: m.label, heading: text0(x.heading), serves: text0(x.serves), subs: (Array.isArray(x.subs) ? x.subs : []).map((s) => ({ text: text0(s?.text), range: text0(s?.range) })), cross: text0(x.cross), background: text0(x.background), idea: text0(x.idea) };
        if (m.key === 'conclusion') mv.applications = (Array.isArray(x.applications) ? x.applications : []).map(text0);
        return mv;
      }),
      migrated: false,
    };
  }
  const old = (Array.isArray(o?.points) ? o.points : []).map((p) => ({ text: text0(p?.title), range: text0(p?.range) }));
  return {
    message: '',
    movements: MOVES.map((m) => ({ key: m.key, label: m.label, heading: '', serves: '', subs: m.key === 'development' ? old : [], cross: '', background: '', idea: '', ...(m.key === 'conclusion' ? { applications: [] } : {}) })),
    migrated: true,
  };
}
/** What still keeps the edited outline from going on (Korean, shown under the form); [] = ready. */
export function outlineProblems(books, ref, o) {
  const v = outlineOf(o);
  const out = [];
  if (!filled(v.message)) out.push('한 문장 메시지를 적어 주세요.');
  for (const m of v.movements) {
    if (!filled(m.heading)) out.push(`${m.label}의 제목을 적어 주세요.`);
    if (!m.subs.some((s) => filled(s.text))) out.push(`${m.label}에 세부 내용을 하나 이상 적어 주세요.`);
    if (m.subs.some((s) => filled(s.range) && !parseRange(books, ref, s.range))) out.push(`${m.label}에 이 본문에 없는 절 범위가 있어요.`);
    if (filled(m.cross) && !parsePassage(books, m.cross).ref) out.push(`${m.label}의 관련 본문 주소를 확인해 주세요.`);
  }
  return out;
}
/** Empty sub-points and applications are left out when going on (filled ones are kept as written). */
export function cleanOutline(o) {
  const v = outlineOf(o);
  return { message: v.message.trim(), movements: v.movements.map((m) => ({ ...m, subs: m.subs.filter((s) => filled(s.text) || filled(s.range)), ...(m.applications ? { applications: m.applications.filter(filled) } : {}) })) };
}

// ---------------------------------------------------------------- 본문연구 · 예화 · 적용 · 원고 초안 (in the page, after 개요)
// Same pattern as 개요: one result written from the draft, read first, then one part edited at a time.
// What these steps may not do (owner 2026-10-26): quote, name books / authors / pages / URLs, present named people or
// numbers as fact; background is marked for checking; doctrine stays inside the confession (DOCTRINE.md §1).
export const WORK_RULES = [
  '예장합동 헌법의 교리표준(웨스트민스터 신앙고백·대소요리문답)과 공교회 신경(사도신경·니케아 신경·칼케돈 신경) 안에서만 교리를 말하세요. 이단·사이비로 결의된 단체나 가르침의 생각을 쓰지 마세요.',
  '인용문을 쓰지 마세요. 성경 본문의 문장도 옮겨 쓰지 말고 "책 장:절" 주소로만 가리키세요.',
  '책 이름·저자·쪽 번호·인터넷 주소(URL)를 쓰지 마세요.',
  '실제 인물의 이름이나 통계·숫자를 사실처럼 쓰지 마세요.',
  '배경 설명은 널리 알려진 일반적인 내용만 짧게 쓰고 연도·숫자를 지어내지 마세요(목사님이 확인한 뒤에 씁니다).',
  '예화는 실제 있었던 일처럼 쓰지 말고, 목사님이 자기 예화로 바꿔 쓸 흔한 삶의 장면(예화 아이디어)으로만 쓰세요.',
  ...RULES.slice(3),
];
// 예화 and 적용 are steps again (owner 2026-10-28), after 청중·분량 and before the 원고 초안 so the draft is written with
// them; their items (and the old ones from the 9-step drafts: `idea` for the body, no kind) go into the 원고 prompt.
export const WORK_KEYS = ['exegesis', 'illustration', 'application', 'manuscript'];
/** 예화 kinds: a common life scene the pastor retells as their own, or a scene from the Bible with its verses. */
export const ILL_KIND = { life: '생활 이야기', bible: '성경 인물', news: '시사' };
const KIND_OF = (v) => Object.keys(ILL_KIND).find((k) => k === v || ILL_KIND[k] === String(v ?? '').trim()) ?? null;
/** The 예화 prompt's rules: the work rules with the 예화 line for both kinds. */
export const ILL_RULES = [
  ...WORK_RULES.slice(0, 5),
  '생활 이야기 예화는 실제 있었던 일·실제 인물·뉴스·통계·인용이 아니라, 목사님이 자기 이야기로 바꿔 전할 흔한 삶의 장면으로만 쓰세요.',
  '성경 인물 예화는 성경 본문에 있는 내용만 쓰고 절을 적으세요.',
  ...WORK_RULES.slice(6),
];
/** Step 7's name (owner 2026-10-27): what is written there is a draft for the pastor to finish. */
export const MS_LABEL = '원고 초안';
/** The owner's words, verbatim: under the 원고 초안 heading and again above the manuscript parts. */
export const MS_NOTICE = '이 원고는 예시로 쓰여진 초안입니다. 그대로 사용하지 마세요. 성도들의 상황과 형편을 고려하여, 목회자의 언어와 마음을 담아 최종 설교문을 완성해 주세요.';
/** 원고 length: the Claude Code manuscript stage's 25-minute sermon (about 6,750 chars without spaces, four parts). */
export const MS_PART_CHARS = Math.round((1350 * 5) / 4);
export const MS_CHARS_PER_MIN = 270;
const PART_OF = (label) => MOVES.find((m) => m.label === String(label ?? '').trim() || m.key === label)?.key ?? null;
export const partLabel = (key) => MOVES.find((m) => m.key === key)?.label ?? '';
/**
 * Each step: its name, what its write button says, which list holds its parts, how a part is named on the choice buttons, and the
 * fields of one part (input | text | paras = paragraphs split by a blank line | part = 도입·전개·절정·결말 | range).
 */
export const WORK = {
  exegesis: { label: '본문연구', write: '본문연구 작성하기', rewrite: '다시 작성하기', list: 'groups', name: (x, i) => (filled(x.range) ? x.range + ' ' : '') + (filled(x.title) ? x.title : `묶음 ${i + 1}`),
    fields: [{ f: 'range', type: 'range', label: '절 범위' }, { f: 'title', type: 'input', label: '제목' }, { f: 'body', type: 'text', label: '풀이' }, { f: 'background', type: 'text', label: '배경 메모', note: '확인한 뒤 쓰세요' }] },
  illustration: { label: '예화', write: '예화 만들기', rewrite: '다시 만들기', list: 'items', add: '예화 더하기', name: (x, i) => `예화 ${i + 1}` + (filled(x.title) ? ` ${x.title}` : ''),
    fields: [{ f: 'kind', type: 'kind', label: '종류' }, { f: 'part', type: 'part', label: '들어갈 곳' }, { f: 'title', type: 'input', label: '제목' },
      { f: 'body', type: 'text', label: '예화 본문', note: '목사님 말로 바꿔 전해 주세요' }, { f: 'range', type: 'ref', label: '근거 절', note: '성경 인물 예화는 꼭 적어 주세요' }, { f: 'bridge', type: 'text', label: '이어 주는 말' }] },
  application: { label: '적용', write: '적용 만들기', rewrite: '다시 만들기', list: 'items', add: '적용 더하기', name: (_x, i) => `적용 ${i + 1}`,
    fields: [{ f: 'part', type: 'part', label: '들어갈 곳' }, { f: 'text', type: 'text', label: '적용', note: '이번 주에 해 볼 수 있게 구체적으로' }, { f: 'range', type: 'ref', label: '근거 절', note: '없어도 돼요' }] },
  manuscript: { label: MS_LABEL, write: '초안 작성하기', rewrite: '초안 다시 작성하기', list: 'sections', name: (x) => x.label,
    fields: [{ f: 'heading', type: 'input', label: '제목' }, { f: 'paragraphs', type: 'paras', label: '원고', note: '문단 사이는 빈 줄로 나눠 주세요' }] },
};
/** An illustration item as the page reads it: the 9-step drafts kept the body as `idea` and had no kind (생활 이야기). */
export const illBody = (x) => String(x?.body ?? x?.idea ?? '');
export const illKind = (x) => KIND_OF(x?.kind) ?? 'life';
/** A 근거 절 anywhere in the Bible: "15:4" / "4절" inside the passage's book, or a full address "사무엘상 17:1-11". */
export const anyRef = (books, ref, text) => (filled(text) ? (ref ? parseRange(books, ref, text) : null) || parsePassage(books, text).ref || null : null);
export const workList = (key, v) => (Array.isArray(v?.[WORK[key].list]) ? v[WORK[key].list] : []);
// the 예화 아이디어 and 배경 메모 the outline collected go to the 원고 too (`notes` false: the text before they did, for
// manuscript.inputs kept then)
export const outlineText = (o, notes = true) => {
  const v = outlineOf(o);
  return [`한 문장 메시지: ${v.message}`, ...v.movements.map((m) => [`${m.label}: ${m.heading}`, m.serves, ...m.subs.filter((x) => filled(x.text)).map((x) => `- ${x.text}${x.range ? ` (${x.range})` : ''}`),
    ...(notes && filled(m.idea) ? [`- 예화 아이디어: ${m.idea}`] : []), ...(notes && filled(m.background) ? [`- 배경 메모: ${m.background}`] : []),
    ...(m.applications || []).filter(filled).map((a) => `- 적용: ${a}`)].filter(filled).join('\n'))].join('\n\n');
};
/** The 예화 / 적용 made in their steps (with the ones the 9-step drafts made), empty ones left out. */
export const illustrationsOf = (d) => (Array.isArray(d?.illustration?.edited?.items) ? d.illustration.edited.items.filter((x) => x && (filled(x.title) || filled(x.idea) || filled(x.body))) : []);
export const applicationsOf = (d) => (Array.isArray(d?.application?.edited?.items) ? d.application.edited.items.filter((x) => x && filled(x.text)) : []);
// a 시사 예화 goes in with its outlet and date (never its address) and whether its quote was found in the article
const newsLine = (x) => (illKind(x) === 'news' && x.source ? `출처: ${x.source.site}${x.source.publishedAt ? `, ${String(x.source.publishedAt).slice(0, 10)}` : ''} (${x.verified ? '기사에서 확인됨' : '확인 필요'})` : '');
const illText = (d) => illustrationsOf(d).map((x) => [`[${partLabel(x.part)} · ${ILL_KIND[illKind(x)]}] ${x.title ?? ''}`.trim(), illBody(x), filled(x.range) ? `근거 절: ${x.range}` : '', newsLine(x), filled(x.bridge) ? `이어 주는 말: ${x.bridge}` : ''].filter(filled).join('\n')).join('\n\n');
const hasNews = (d) => illustrationsOf(d).some((x) => illKind(x) === 'news');
export const NEWS_MS_LINE = '시사 예화는 언론사 이름과 날짜를 말로 밝히고(인터넷 주소는 쓰지 마세요) 기사에 있는 사실만 말하세요. \'확인 필요\'로 표시된 시사 예화는 사실처럼 쓰지 말고, 빼거나 확인되지 않은 이야기라고 밝히세요.';
const appText = (d) => applicationsOf(d).map((x) => `[${partLabel(x.part) || partLabel('conclusion')}] ${x.text}${filled(x.range) ? ` (${x.range})` : ''}`).join('\n');
// 주석 메모 (owner 2026-10-28): the commentary notes the 본문연구 was written with, checked on their page by the tool.
// They go with the study into the 원고 초안 prompt (id, point, source; never the quote), which marks the paragraphs
// built on them; those marks are the 원고's footnotes.
export const NOTE_CLAIMS = ['doctrine', 'fact', 'history', 'language'];
export const NOTE_MAX = { group: 3, study: 10 };
/** A group's notes still in use: checked on their page ('found') and not taken out by hand. */
export const activeNotes = (g) => (Array.isArray(g?.notes) ? g.notes.filter((n) => n && !n.removed && n.status === 'found') : []);
export const allNotes = (v) => workList('exegesis', v).flatMap(activeNotes);
const noteSource = (n) => (n.kind === 'web' ? `${webLabel(n)} — ${n.url}` : commentaryLabel(n));
const studyText = (v) => workList('exegesis', v).map((g) => `${g.range} ${g.title}\n${g.body}${activeNotes(g).map((n) => `\n- 주석 메모 [${n.id}] (${CLAIM_KIND_LABEL[n.claim] ?? n.claim}) ${n.point} — ${noteSource(n)}`).join('')}`).join('\n\n');
/** The 원고 초안 marks the paragraphs it built on a 주석 메모 (only when the study has some). */
const msNotesOn = (d) => allNotes(d?.exegesis?.edited).length > 0;
const MS_NOTE_LINE = '본문연구의 주석 메모(예: [n1])를 바탕으로 쓴 문단은 {"text":"문단","notes":["n1"]} 모양으로 쓰고 그 메모 번호를 notes에 적으세요. 메모를 쓰지 않은 문단은 지금처럼 문자열로 두세요. 메모 번호를 지어내지 마세요.';
const msText = (v) => workList('manuscript', v).map((x) => `[${x.label}] ${x.heading}\n${x.paragraphs.join('\n')}`).join('\n\n');
/** 청중·분량 (step 6): the length the 원고 is written to (25 minutes when not set). */
export const MS_MINUTES = 25;
export function msTarget(d) {
  const m = Number(d?.setting?.minutes), c = Number(d?.setting?.chars);
  return m > 0 && c > 0 ? { minutes: m, chars: c } : lengthOf({ minutes: MS_MINUTES });
}
/** minutes <-> characters without spaces at the Claude Code stage's pace; whichever is given wins. */
export function lengthOf({ minutes, chars }) {
  if (chars !== undefined) { const c = Math.max(Math.round(Number(chars)) || 0, 0); return { chars: c, minutes: Math.round(c / MS_CHARS_PER_MIN) }; }
  const m = Math.max(Math.round(Number(minutes)) || 0, 0);
  return { minutes: m, chars: m * MS_CHARS_PER_MIN };
}
/** A new 청중·분량: 25 minutes, the audience from 본문 추천 when one was written there. */
export function newSetting(d) {
  return { service: '', place: '', category: '', audience: String(d?.recommend?.audience ?? ''), ...lengthOf({ minutes: MS_MINUTES }), by: 'user' };
}
/** '본교회 장년 · 주일 낮 · 25분(약 6,750자)' for the line above 초안 작성하기 (no break inside the brackets). */
export function settingLine(st) {
  const t = msTarget({ setting: st });
  return [st?.place, st?.service].filter(filled).concat(`${t.minutes}분(약\u00a0${t.chars.toLocaleString('en-US')}자)`).join(' · ');
}
const audienceText = (st) => [filled(st?.service) ? `예배: ${st.service}` : '', filled(st?.place) ? `장소·대상: ${st.place}` : '', String(st?.audience ?? '').trim()].filter(Boolean).join('\n');
function workContext(d, key) {
  const parts = [block('설교 본문', d.ref?.label), seedPath(d) === 'central' ? block('중심 메시지', d.central.message) : block('목사님의 묵상', d.meditation),
    block('설교 방향', `${d.directions?.edited?.title ?? ''}\n${d.directions?.edited?.body ?? ''}`), block('개요', outlineText(d.outlines?.edited))];
  if (key !== 'exegesis' && d.exegesis?.edited) parts.push(block('본문연구', studyText(d.exegesis.edited)));
  if (key !== 'exegesis' && audienceText(d.setting)) parts.push(block('듣는 사람들', audienceText(d.setting)));
  if (key === 'manuscript' && illustrationsOf(d).length) parts.push(block('만들어 둔 예화', illText(d)));
  if (key === 'manuscript' && applicationsOf(d).length) parts.push(block('만들어 둔 적용', appText(d)));
  return parts;
}
const workPrompt = (task, parts, shape, rules = WORK_RULES) => [task, '', '지킬 것:', ...rules.map((r) => `- ${r}`), '', ...parts, '', 'JSON 모양:', shape].join('\n');
const MS_SHAPE = `[${MOVES.map((m) => `{"label":"${m.label}","heading":"부분 제목","paragraphs":["문단"]}`).join(',')}]`;
const MS_SHAPE_NOTES = `[${MOVES.map((m) => `{"label":"${m.label}","heading":"부분 제목","paragraphs":["문단",{"text":"주석 메모를 바탕으로 쓴 문단","notes":["n1"]}]}`).join(',')}]`;
const msShape = (d) => (msNotesOn(d) ? MS_SHAPE_NOTES : MS_SHAPE);
/** The prompt for one in-page step, built from the draft as it is now. */
export function promptWork(key, d, style, excerpts) {
  const ref = d.ref;
  const ctx = workContext(d, key);
  if (key !== 'exegesis' && styleBlock(style)) ctx.push(styleBlock(style));
  const ex = key === 'exegesis' && Array.isArray(excerpts) && excerpts.length ? excerpts : null;
  if (key === 'exegesis') return workPrompt([
    `${ref.label}의 본문연구를 써 주세요. 본문을 처음부터 끝까지 절 묶음(단락) 2~5개로 나누고, 개요가 이 본문 어디에 서 있는지 보이게 하세요.`,
    '묶음마다 절 범위, 짧은 제목, 풀이(그 절들이 무엇을 말하는지, 문맥과 흐름을 쉬운 말로 3~5문장), 알맞으면 배경 메모(한두 문장, 없으면 빈 값)를 쓰세요.',
    ...(ex ? [
      '아래 주석 발췌를 먼저 읽고 풀이와 배경 메모에 반영하세요. 묶음마다 주석 메모(notes)를 적을 수 있습니다: 책 번호(key), 쪽(page), 그 쪽에 있는 글을 그대로 옮긴 인용(quote, 300자 이내), 이 메모가 풀이·배경의 무엇을 뒷받침하는지 한국어 한 문장(point), 주장의 종류(claim: doctrine · fact · history · language 가운데 하나).',
      `주석 메모는 묶음마다 많아야 ${NOTE_MAX.group}개, 본문연구 전체에 많아야 ${NOTE_MAX.study}개입니다. 아래 발췌에 있는 것만 쓰고 기억으로 지어내지 마세요. 맞는 것이 없으면 notes를 빈 목록으로 두세요.`,
      '교리 주장(doctrine)은 등급 R인 책으로만 뒷받침하세요. 등급 E·N인 책은 사실·역사·원어에만 쓰세요. 온라인 주석(책 번호가 web:으로 시작)은 쪽을 1로 쓰세요.',
      '풀이와 배경 메모 글에는 인용문이나 책 이름을 넣지 말고, 주석에서 온 인용은 notes의 quote에만 적으세요.',
    ] : []),
  ].join('\n'), ex ? [...ctx, `주석 발췌:\n<<<\n${excerptText(ex)}\n>>>`] : ctx,
  ex ? `{"study":{"groups":[{"chapter":${ref.chap},"verseStart":${ref.v1},"verseEnd":${ref.v1},"title":"짧은 제목","body":"풀이","background":"","notes":[{"key":"책 번호","page":12,"quote":"그 쪽의 글 그대로","point":"이 메모가 뒷받침하는 점 한 문장","claim":"history"}]}]}}`
    : `{"study":{"groups":[{"chapter":${ref.chap},"verseStart":${ref.v1},"verseEnd":${ref.v1},"title":"짧은 제목","body":"풀이","background":""}]}}`);
  if (key === 'manuscript') return workPrompt([
    '개요를 그대로 따라 설교 원고를 써 주세요. 네 부분을 꼭 이 순서와 이름으로 쓰고, 모두 개요 맨 위의 한 문장 메시지를 향하게 하며, 결말에서 그 문장을 한 번 더 말하세요.',
    ...MOVES.map((m, i) => `${i + 1}) ${m.label}: ${m.rule}`),
    `${msTarget(d).minutes}분 설교 분량입니다. 부분마다 약 ${Math.round(msTarget(d).chars / MOVES.length).toLocaleString('en-US')}자(공백 빼고), 문단 4~8개로 쓰세요.`,
    '그대로 소리 내어 읽을 수 있는 존댓말 설교체로 쓰고, 본문연구의 풀이를 바탕으로 하세요. 개요의 예화 아이디어는 실화처럼 풀지 말고, 쓰더라도 지어낸 장면임을 밝히세요.',
    '전개나 절정에 예화(성도의 삶에서 흔히 보는 장면)를 적어도 하나, 될 수 있으면 둘 넣으세요. 개요의 예화 아이디어와 만들어 둔 예화가 있으면 그것을 먼저 쓰고, 없으면 지어낸 장면임이 드러나게 쓰세요.',
    '결말에는 개요의 적용을 모두 담아 구체적으로 권하세요.',
    ...(illustrationsOf(d).length ? ['만들어 둔 예화를 하나도 빼지 말고 각각 그 들어갈 곳에 넣으세요. 생활 이야기는 목사님 자신이 겪은 장면처럼 풀고, 성경 인물 예화는 그 절을 함께 밝히세요.'] : []),
    ...(hasNews(d) ? [NEWS_MS_LINE] : []),
    ...(applicationsOf(d).length ? ['만들어 둔 적용을 하나도 빼지 말고 각각 그 들어갈 곳(정하지 않았으면 결말)에 넣으세요.'] : []),
    ...(msNotesOn(d) ? [MS_NOTE_LINE] : []),
    ...(reqTexts(d).length ? ['목사님이 적은 \'꼭 반영할 것\'을 원고에 꼭 반영하세요.'] : []),
  ].join('\n'), reqTexts(d).length ? [...ctx, block('꼭 반영할 것', reqTexts(d).map((t) => `- ${t}`).join('\n'))] : ctx,
  `{"manuscript":{"sections":${msShape(d)}}${pendingRequests(d).length ? ',"reply":"한두 문장: 꼭 반영할 것을 원고에 어떻게 넣었는지"' : ''}}`);
  if (key === 'illustration') return workPrompt([
    '원고 초안에 넣을 예화를 3~4개 써 주세요. 적어도 하나는 성경 인물 예화, 적어도 하나는 생활 이야기로 쓰세요.',
    '생활 이야기는 실제 있었던 일·실제 인물·뉴스·통계·인용이 아니라 목사님이 자기 이야기로 바꿔 전할 흔한 삶의 장면입니다. 성경 인물 예화는 성경에 나오는 장면을 목사님 말로 풀고, 그 장면의 성경 주소(책·장·절)를 적습니다.',
    '예화마다 종류(kind: 생활 이야기 또는 성경 인물), 들어갈 부분(도입·전개·절정·결말 가운데 하나), 짧은 제목, 예화 본문(3~6문장), 이어 주는 말(예화에서 말씀으로 넘어가는 한두 문장)을 쓰세요. 생활 이야기는 book을 null로 두세요.',
    '개요의 예화 아이디어가 있으면 살려 쓰고, 듣는 사람들의 형편에 맞는 장면을 고르세요.',
  ].join('\n'), ctx, '{"illustrations":[{"kind":"성경 인물","part":"전개","title":"짧은 제목","body":"예화 본문","book":"사무엘상","chapter":17,"verseStart":45,"verseEnd":47,"bridge":"이어 주는 말"},{"kind":"생활 이야기","part":"도입","title":"짧은 제목","body":"예화 본문","book":null,"bridge":"이어 주는 말"}]}', ILL_RULES);
  if (key === 'application') return workPrompt([
    '원고 초안에 넣을 적용을 2~3개 써 주세요. 이번 주에 성도가 실제로 해 볼 수 있게 구체적으로(언제·어디서·무엇을) 한두 문장씩 쓰세요.',
    `적용마다 들어갈 부분(도입·전개·절정·결말 가운데 하나, 대개 결말)과, 알맞으면 근거가 되는 성경 주소(${ref.label} 안이나 다른 본문)를 쓰세요. 없으면 book을 null로 두세요.`,
    '개요의 적용이 있으면 살려 쓰세요.',
  ].join('\n'), ctx, `{"applications":[{"part":"결말","text":"구체적인 적용","book":"${(BOOK_NAME_OF(ref) ?? '요한복음')}","chapter":${ref.chap},"verseStart":${ref.v1},"verseEnd":${ref.v1}}]}`);
  return null;
}
const BOOK_NAME_OF = (ref) => String(ref?.label ?? '').replace(/\s*\d.*$/, '') || null;
const LINK_RE = /https?:\/\/|www\./i;
/** A verse range inside the passage itself (the in-page steps stay in the text being preached). */
function passageRange(books, ref, p) {
  const r = p && typeof p === 'object' ? checkRef(books, { bookId: ref.bookId, chapter: p.chapter ?? ref.chap, verseStart: p.verseStart, verseEnd: p.verseEnd }) : null;
  return r && r.chap === ref.chap && r.v1 >= ref.v1 && r.v2 <= ref.v2 ? r : null;
}
/**
 * A group's proposed notes -> the ones that keep the rules: a book and page that were read, a quote of at most 300
 * characters, a claim its doctrine class allows (the class from the tool), a point; deduped, capped per group and per
 * study. `count` carries the study-wide numbering and what was dropped. Their status stays 'proposed' until checked.
 */
function checkNotes(list, excerpts, count) {
  const out = [];
  for (const x of Array.isArray(list) ? list : []) {
    const book = excerpts.find((e) => e.key === x?.key);
    const page = Number(x?.page);
    const quote = String(x?.quote ?? '').normalize('NFC').replace(/\s+/g, ' ').trim();
    const point = str(x?.point, 200), claim = String(x?.claim ?? '');
    if (!book || !book.pages.some((p) => p.page === page) || !quote || [...quote].length > SOURCE_QUOTE_MAX || !point || !NOTE_CLAIMS.includes(claim)) { count.dropped++; continue; }
    if (!claimAllowed(book.doctrine, claim)) { count.dropped++; count.doctrine++; continue; }
    if (out.some((n) => n.key === book.key && n.page === page && n.quote === quote)) continue;
    if (out.length >= NOTE_MAX.group || count.n >= NOTE_MAX.study) { count.dropped++; continue; }
    out.push({ id: 'n' + ++count.n, key: book.key, page, quote, point, claim, author: book.author ?? null, title: book.title, doctrine: book.doctrine, kind: book.kind === 'web' ? 'web' : 'library', ...(book.kind === 'web' ? { url: book.url, checkedAt: book.checkedAt ?? null } : {}), status: 'proposed' });
  }
  return out;
}
/**
 * One in-page step's answer -> {value, dropped} or {value: null} when it does not fit the shape. An answer with an
 * internet address anywhere is not used. Parts with a verse outside the passage are dropped (counted).
 */
export function checkWork(key, books, ref, v, extra) {
  // the commentary notes carry quotes from the pages read (their own check is checkNotes); the rest may hold no link
  const bare = key === 'exegesis' && Array.isArray(v?.study?.groups) ? { ...v, study: { ...v.study, groups: v.study.groups.map((g) => (g && typeof g === 'object' ? { ...g, notes: undefined } : g)) } } : v;
  if (LINK_RE.test(JSON.stringify(bare ?? null))) return { value: null, dropped: 0 };
  let dropped = 0;
  if (key === 'exegesis') {
    // extra: the excerpts the study was written from (notes only then)
    const groups = [];
    const notes = { n: 0, dropped: 0, doctrine: 0 };
    for (const g of Array.isArray(v?.study?.groups) ? v.study.groups : []) {
      const r = passageRange(books, ref, g), title = str(g?.title, 80), body = str(g?.body, 1200);
      if (!r || !title || !body) { dropped++; continue; }
      if (groups.length < 5) groups.push({ range: rangeText(r), title, body, background: str(g.background, 400) || '', ...(Array.isArray(extra) ? { notes: checkNotes(g.notes, extra, notes) } : {}) });
    }
    return { value: groups.length ? { groups } : null, dropped, ...(Array.isArray(extra) ? { notes: { dropped: notes.dropped, doctrine: notes.doctrine } } : {}) };
  }
  if (key === 'manuscript') {
    // extra: the ids of the study's notes; a paragraph is a string or {text, notes: [ids]} (the ids become footnotes)
    const ids = new Set(Array.isArray(extra) ? extra : []);
    const list = Array.isArray(v?.manuscript?.sections) ? v.manuscript.sections : [];
    if (list.length !== MOVES.length) return { value: null, dropped, links: [] };
    const links = [];
    const sections = MOVES.map((m, i) => {
      const x = list[i];
      const paras = (Array.isArray(x?.paragraphs) ? x.paragraphs : []).map((p) => (typeof p === 'string' ? { text: str(p, 1200), notes: [] } : { text: str(p?.text, 1200), notes: Array.isArray(p?.notes) ? p.notes : [] })).filter((p) => p.text).slice(0, 12);
      paras.forEach((p, pi) => { for (const id of new Set(p.notes.map(String))) if (ids.has(id)) links.push({ section: i, paragraph: pi, noteId: id }); });
      return str(x?.label, 10) === m.label && str(x?.heading, 80) && paras.length ? { key: m.key, label: m.label, heading: str(x.heading, 80), paragraphs: paras.map((p) => p.text) } : null;
    });
    return sections.every(Boolean) ? { value: { sections }, dropped, links } : { value: null, dropped, links: [] };
  }
  // a 근거 절 in any book (bible.json): {book, chapter, verseStart, verseEnd}; null when absent or not real
  const anyVerse = (x) => (x && filled(x.book) ? checkRef(books, { book: x.book, chapter: x.chapter, verseStart: x.verseStart, verseEnd: x.verseEnd }) : null);
  const verseText = (r) => (r ? (r.bookId === ref.bookId ? rangeText(r) : r.label) : '');
  if (key === 'illustration') {
    const items = [];
    for (const x of Array.isArray(v?.illustrations) ? v.illustrations : []) {
      const kind = KIND_OF(x?.kind), part = PART_OF(x?.part), title = str(x?.title, 80), body = str(x?.body, 1200), r = anyVerse(x);
      // a 시사 예화 comes only from 시사 예화 찾기 (with its article); not from here
      if (!kind || kind === 'news' || !part || !title || !body || (kind === 'bible' && !r)) { dropped++; continue; }
      if (items.length < 4) items.push({ kind, part, title, body, range: verseText(r), bridge: str(x.bridge, 400) || '' });
    }
    return { value: items.length ? { items } : null, dropped };
  }
  if (key === 'application') {
    const items = [];
    for (const x of Array.isArray(v?.applications) ? v.applications : []) {
      const text = str(x?.text, 400), r = anyVerse(x);
      if (!text || (filled(x?.book) && !r)) { dropped++; continue; }
      if (items.length < 3) items.push({ part: PART_OF(x.part) ?? 'conclusion', text, range: verseText(r) });
    }
    return { value: items.length ? { items } : null, dropped };
  }
  return { value: null, dropped };
}
/** Without AI each step starts with empty parts, filled by choosing them one at a time. */
export function blankWork(key) {
  if (key === 'exegesis') return { groups: [0, 1, 2].map(() => ({ range: '', title: '', body: '', background: '' })) };
  if (key === 'illustration') return { items: [blankItem(key)] };
  if (key === 'application') return { items: [blankItem(key)] };
  return { sections: MOVES.map((m) => ({ key: m.key, label: m.label, heading: '', paragraphs: [] })) };
}
/** One empty 예화 / 적용 (더하기). */
export const blankItem = (key) => (key === 'illustration' ? { kind: 'life', part: 'development', title: '', body: '', range: '', bridge: '' } : { part: 'conclusion', text: '', range: '' });
/** What keeps a step from going on (Korean, shown under the reading view); [] = ready. */
export function workProblems(key, books, ref, v) {
  const list = workList(key, v);
  const out = [];
  const inPassage = (r) => r && r.chap === ref.chap && r.v1 >= ref.v1 && r.v2 <= ref.v2;
  const badRange = (x) => filled(x.range) && !inPassage(parseRange(books, ref, x.range));
  if (key === 'exegesis') {
    if (!list.some((g) => filled(g.body))) out.push('풀이를 하나 이상 적어 주세요.');
    if (list.some(badRange)) out.push('이 본문에 없는 절 범위가 있어요.');
  } else if (key === 'manuscript') {
    for (const x of list) if (!x.paragraphs.some(filled)) out.push(`${x.label} 원고를 적어 주세요.`);
  } else {
    // 예화 · 적용 are optional; what is written must hold together
    if (key === 'illustration' && list.some((x) => illKind(x) === 'bible' && (filled(x.title) || filled(illBody(x))) && !anyRef(books, ref, x.range))) out.push('성경 인물 예화에는 근거 절을 적어 주세요.');
    if (list.some((x) => filled(x.range) && !anyRef(books, ref, x.range))) out.push('근거 절의 성경 주소를 확인해 주세요.');
  }
  return out;
}
/** Empty parts are left out when going on (the four manuscript parts always stay). */
export function cleanWork(key, v) {
  const L = WORK[key].list;
  if (key === 'manuscript') return { ...v, sections: workList(key, v).map((x) => ({ ...x, paragraphs: x.paragraphs.filter(filled) })) };
  if (key === 'illustration') return { ...v, [L]: workList(key, v).filter((x) => filled(x.title) || filled(illBody(x))) };
  if (key === 'application') return { ...v, [L]: workList(key, v).filter((x) => filled(x.text)) };
  return { ...v, [L]: workList(key, v).filter((g) => filled(g.body) || filled(g.title)) };
}
// ---------------------------------------------------------------- 이렇게 써 주세요 (owner 2026-10-27)
// The owner writes what the 원고 should say or change; with a 원고 the AI rewrites it and answers in a line, without
// one the request waits for 원고 작성하기. The log is for reading only: just the last few requests go into a prompt.
export const REQ_LABEL = '이렇게 써 주세요';
export const REQ_BUTTON = '반영하기';
export const REQ_MAX = 20;
export const REQ_TEXT_MAX = 1000;
export const REQ_CONTEXT = 3;
const REPLY_MAX = 300;
export const requestsOf = (d) => (Array.isArray(d?.manuscript?.requests) ? d.manuscript.requests : []);
/** Requests not answered yet (written before there was a 원고): 원고 작성하기 honors them. */
export const pendingRequests = (d) => requestsOf(d).filter((r) => r.reply == null);
const reqTexts = (d) => requestsOf(d).slice(-REQ_CONTEXT).map((r) => r.text);
/**
 * Keep one request on the draft: text trimmed and cut at REQ_TEXT_MAX, reply null while it waits for 원고 작성하기;
 * only the newest REQ_MAX are kept. -> the entry, or null for an empty text.
 */
export function pushRequest(d, text, reply, at = new Date().toISOString()) {
  const t = String(text ?? '').trim().slice(0, REQ_TEXT_MAX);
  if (!t) return null;
  if (!d.manuscript) d.manuscript = { edited: null };
  const entry = { at, text: t, reply: reply == null ? null : String(reply).trim().slice(0, REPLY_MAX) };
  d.manuscript.requests = [...requestsOf(d), entry].slice(-REQ_MAX);
  return entry;
}
/** The waiting requests get the reply from 원고 작성하기 (or a plain one when the answer had none). */
export function settleRequests(d, reply) {
  const r = str(reply, REPLY_MAX) || '말씀하신 내용을 넣어 원고를 썼어요.';
  for (const x of pendingRequests(d)) x.reply = r;
  return requestsOf(d);
}
/** The prompt for 반영하기 on a 원고 that exists: the whole 원고 as JSON, the request, the 청중·분량 and the rules. */
export function promptRevise(d, request, style) {
  const cur = workList('manuscript', d.manuscript?.edited).map((x) => ({ label: x.label, heading: x.heading, paragraphs: x.paragraphs }));
  const earlier = reqTexts(d);
  return workPrompt([
    '지금 원고를 목사님의 요청대로 고쳐 주세요. 요청한 내용만 바꾸고, 나머지 문장과 흐름은 될 수 있는 대로 그대로 두세요.',
    `네 부분(${MOVES.map((m) => m.label).join('·')})을 꼭 이 순서와 이름으로 두고, 모두 개요 맨 위의 한 문장 메시지를 향하게 하세요.`,
    `분량은 요청이 없으면 지금과 비슷하게 두세요(${msTarget(d).minutes}분 설교, 공백 빼고 약 ${msTarget(d).chars.toLocaleString('en-US')}자). 존댓말 설교체로 쓰세요.`,
    ...(msNotesOn(d) ? [MS_NOTE_LINE] : []),
    'reply에는 무엇을 어떻게 바꿨는지 한두 문장으로 쓰세요.',
  ].join('\n'), [...workContext(d, 'manuscript'), ...(styleBlock(style) ? [styleBlock(style)] : []), ...(earlier.length ? [block('앞서 반영한 요청', earlier.map((t) => `- ${t}`).join('\n'))] : []),
    block('지금 원고(JSON)', JSON.stringify({ sections: msWithNotes(d, cur) })), block('이번 요청', String(request ?? '').trim().slice(0, REQ_TEXT_MAX))],
  `{"manuscript":{"sections":${msShape(d)}},"reply":"한두 문장: 무엇을 어떻게 바꿨는지"}`);
}
/** 반영하기's answer -> {value: the 원고 (checkWork's shape) | null, reply, links} (a link anywhere drops it, as in checkWork). */
export function reviseChecks(books, ref, v, noteIds) {
  const r = checkWork('manuscript', books, ref, v, noteIds);
  return { value: r.value, reply: r.value ? str(v?.reply, REPLY_MAX) || '말씀하신 내용대로 원고를 고쳤어요.' : null, links: r.links };
}
/** The 원고 as sent back to the AI: the paragraphs that carry note marks as {text, notes} (so a rewrite keeps them). */
function msWithNotes(d, cur) {
  if (!msNotesOn(d)) return cur;
  const live = new Set(allNotes(d.exegesis.edited).map((n) => n.id));
  const links = (d.manuscript?.notes || []).filter((l) => !l.removed && live.has(l.noteId));
  return cur.map((x, si) => ({ ...x, paragraphs: x.paragraphs.map((t, pi) => { const ids = links.filter((l) => l.section === si && l.paragraph === pi).map((l) => l.noteId); return ids.length ? { text: t, notes: ids } : t; }) }));
}
/** checkWork / reviseChecks links -> manuscript.notes (f1…; the anchor is the whole paragraph). */
export const msNoteLinks = (links) => (links || []).map((l, i) => ({ id: 'f' + (i + 1), section: l.section, paragraph: l.paragraph, anchor: '', noteId: l.noteId }));
/** The ids of the study's notes in use (what a 원고 answer may mark). */
export const noteIdsOf = (d) => allNotes(d?.exegesis?.edited).map((n) => n.id);
// ---------------------------------------------------------------- 내 문체 (owner 2026-10-27)
// The viewer's own past sermons are read once (2-5, each cut at 20,000 characters) and only what the AI derives from
// them is kept (settings.style); the sermons themselves are never saved. The derived style guides the 원고 초안.
export const STYLE_NAME = '나의 설교 스타일';
export const STYLE_MIN = 2;
export const STYLE_MAX = 5;
export const STYLE_CHARS = 20000;
/** sample.limits maxPromptBytes 262,144 at about 3 bytes a Korean character, with room for the instructions. */
export const STYLE_SINGLE = 60000;
export const STYLE_EXPECTED = 3000;
export const STYLE_FIELDS = [
  { f: 'summary', label: '한마디로', max: 1200 },
  { f: 'voice', label: '말투와 부르는 말', max: 600 },
  { f: 'sentences', label: '문장 길이와 리듬', max: 600 },
  { f: 'structure', label: '설교 흐름의 습관', max: 600 },
  { f: 'rhetoric', label: '질문·반복·강조', max: 600 },
  { f: 'illustrations', label: '예화를 꺼내는 방식', max: 600 },
  { f: 'vocabulary', label: '자주 쓰는 표현', list: 10, each: 60 },
  { f: 'avoid', label: '쓰지 않는 표현', list: 10, each: 100 },
  { f: 'samples', label: '대표 문장', list: 5, each: 300 },
];
/** One sermon for the analysis: cut at STYLE_CHARS. -> {name, text, chars (before the cut), cut}. */
export function styleItem(name, text) {
  const t = String(text ?? '').replace(/\r\n?/g, '\n').trim();
  return { name: String(name ?? '').trim().slice(0, 80) || '설교문', text: t.slice(0, STYLE_CHARS), chars: t.length, cut: t.length > STYLE_CHARS };
}
/**
 * How many calls the analysis takes: one call when all sermons fit (≤ STYLE_SINGLE characters together), else one
 * call per sermon and a merge. -> {calls: [{kind:'one'|'each', items:[i…]} …, {kind:'merge'}?]} or {error}.
 */
export function analysisPlan(texts) {
  const list = Array.isArray(texts) ? texts.map((t) => String(typeof t === 'string' ? t : t?.text ?? '')) : [];
  if (list.length < STYLE_MIN) return { error: `설교문을 ${STYLE_MIN}편 이상 올려 주세요.` };
  if (list.length > STYLE_MAX) return { error: `설교문은 ${STYLE_MAX}편까지 올릴 수 있어요.` };
  if (list.some((t) => !t.trim())) return { error: '빈 설교문이 있어요.' };
  const total = list.reduce((k, t) => k + Math.min(t.length, STYLE_CHARS), 0);
  if (total <= STYLE_SINGLE) return { calls: [{ kind: 'one', items: list.map((_t, i) => i) }] };
  return { calls: [...list.map((_t, i) => ({ kind: 'each', items: [i] })), { kind: 'merge' }] };
}
const STYLE_SHAPE = '{"style":{"summary":"3~5문장","voice":"존댓말 종결 패턴·호칭(예: 성도 여러분)","sentences":"문장 길이·리듬","structure":"도입·전개·절정·결말 습관","rhetoric":"질문·반복·강조 습관","illustrations":"예화를 꺼내는 방식","vocabulary":["자주 쓰는 표현 10개 이내"],"avoid":["쓰지 않는 표현·피하는 것"],"samples":["본인 설교문에서 뽑은 대표 문장 3~5개, 각 300자 이내"]}}';
const STYLE_RULES = [
  '내용(교리·해석)이 아니라 글의 모양(말투·문장·흐름·습관)만 읽으세요.',
  '대표 문장은 설교문에 있는 문장을 한 글자도 바꾸지 말고 그대로 뽑되, 한 문장에 300자를 넘기지 마세요.',
  '설교문에 나온 사람 이름·교회 이름·연락처는 어디에도 쓰지 마세요.',
  '설명은 존댓말 한국어로, 목사님이 읽고 바로 알 수 있게 쓰세요.',
];
/** The analysis prompt for one or more sermons (their text in blocks). */
export function promptStyle(items) {
  return [`아래 설교문 ${items.length}편은 한 목사님이 쓴 설교입니다. 이 설교문에서 문체와 말버릇을 읽어, 앞으로 원고를 쓸 때 따를 문체 지침을 만들어 주세요.`,
    '', '지킬 것:', ...STYLE_RULES.map((r) => `- ${r}`), '', ...items.map((x, i) => block(`설교문 ${i + 1}`, x.text)), '', 'JSON 모양:', STYLE_SHAPE].join('\n');
}
/** The merge prompt: the per-sermon results become one. */
export function promptStyleMerge(styles) {
  return [`아래는 한 목사님의 설교문 ${styles.length}편을 하나씩 읽은 문체 분석 결과입니다. 문체 분석 결과를 하나로 합쳐, 여러 편에 공통으로 보이는 습관을 앞에 두세요.`,
    '', '지킬 것:', ...STYLE_RULES.map((r) => `- ${r}`), '- 대표 문장은 아래 결과에 있는 것 가운데서만 고르세요.', '', ...styles.map((x, i) => block(`분석 ${i + 1}`, JSON.stringify(x))), '', 'JSON 모양:', STYLE_SHAPE].join('\n');
}
const noSpace = (t) => String(t ?? '').normalize('NFC').replace(/\s+/g, '');
/**
 * The analysis answer -> the style to keep, or null. Strings and lists are capped (STYLE_FIELDS); a sample longer
 * than 300 characters is dropped, and with `texts` given only samples found in them are kept. A link anywhere refuses it.
 */
export function checkStyle(v, texts) {
  if (LINK_RE.test(JSON.stringify(v ?? null))) return null;
  const x = v?.style && typeof v.style === 'object' ? v.style : v;
  if (!x || typeof x !== 'object') return null;
  const hay = Array.isArray(texts) ? texts.map(noSpace) : null;
  const out = {};
  for (const F of STYLE_FIELDS) {
    if (!F.list) { out[F.f] = str(x[F.f], F.max) || ''; continue; }
    let list = (Array.isArray(x[F.f]) ? x[F.f] : []).filter((t) => typeof t === 'string' && t.trim()).map((t) => t.trim());
    list = F.f === 'samples' ? list.filter((t) => t.length <= F.each && (!hay || hay.some((h) => h.includes(noSpace(t))))) : list.map((t) => t.slice(0, F.each));
    out[F.f] = [...new Set(list)].slice(0, F.list);
  }
  return out.summary ? out : null;
}
/** The style is followed when the doc has one and it is switched on. */
export const styleOn = (doc) => (doc && doc.style && doc.enabled !== false ? doc.style : null);
/** The '문체 지침' block for a prompt ('' without a style). */
export function styleBlock(style) {
  if (!style || !filled(style.summary)) return '';
  const lines = ['목사님의 평소 설교 문체를 따라 쓰세요. 대표 문장은 말투를 느끼는 데만 쓰고 그대로 옮기지 마세요.'];
  for (const F of STYLE_FIELDS) {
    const v = style[F.f];
    if (F.list ? Array.isArray(v) && v.length : filled(v)) lines.push(`${F.label}: ${F.list ? v.join(' / ') : v}`);
  }
  return block('문체 지침', lines.join('\n'));
}
/** The doc kept in settings.style (the sermons themselves are not in it). */
export function styleDoc(style, items, at = new Date().toISOString()) {
  return { kind: 'settings', style, from: { count: items.length, names: items.map((x) => x.name), chars: items.reduce((k, x) => k + x.text.length, 0) }, at, enabled: true, userEdited: false };
}
// ---------------------------------------------------------------- 바뀐 내용 반영하기 (owner 2026-10-27)
// What the 원고 초안 was written from is kept as short hashes (manuscript.inputs; manuscript.basis already holds the
// 본문연구 copy the redo check compares). An earlier step changed after that -> the bar above the parts offers SYNC_BUTTON.
export const SYNC_BUTTON = '바뀐 내용 반영하기';
export const MS_INPUTS = [['passage', '설교 본문'], ['seed', '묵상/중심 메시지'], ['direction', '설교 방향'], ['outline', '개요'], ['exegesis', '본문연구'], ['setting', '청중·분량'], ['style', STYLE_NAME], ['illustration', '예화'], ['application', '적용']];
/** 32-bit FNV-1a as 8 hex digits. */
const fnv = (s) => { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); } return (h >>> 0).toString(16).padStart(8, '0'); };
/** The inputs the 원고 초안 is written from, one hash each (the 원고 itself is not one of them). */
export function msBasis(d, style) {
  const t = msTarget(d);
  const text = {
    passage: d?.ref?.label ?? d?.passage ?? '',
    seed: seedPath(d) === 'central' ? d.central.message : String(d?.meditation ?? ''),
    direction: `${d?.directions?.edited?.title ?? ''}\n${d?.directions?.edited?.body ?? ''}`,
    outline: d?.outlines?.edited ? outlineText(d.outlines.edited) : '',
    exegesis: d?.exegesis?.edited ? studyText(d.exegesis.edited) : '',
    setting: `${audienceText(d?.setting)}\n${t.minutes}/${t.chars}`,
    style: styleBlock(style),
    illustration: illustrationsOf(d).length ? JSON.stringify(illustrationsOf(d)) : '',
    application: applicationsOf(d).length ? JSON.stringify(applicationsOf(d)) : '',
  };
  return Object.fromEntries(MS_INPUTS.map(([k]) => [k, fnv(String(text[k]).trim())]));
}
/** A 원고 초안 whose inputs were not kept yet gets them from what the draft holds now; inputs kept before 예화 joined
 * them get the 예화 hash, and the outline's new one when the outline itself is as it was then (no bar by itself). */
export function fillInputs(d, style) {
  const M = d?.manuscript;
  if (!M?.edited) return d;
  const now = msBasis(d, style);
  if (!M.inputs || typeof M.inputs !== 'object') M.inputs = now;
  else if (M.inputs.illustration === undefined) {
    if (M.inputs.outline === fnv(String(d.outlines?.edited ? outlineText(d.outlines.edited, false) : '').trim())) M.inputs.outline = now.outline;
    M.inputs.illustration = now.illustration;
  }
  if (M.inputs.application === undefined) M.inputs.application = now.application; // kept before 적용 joined them
  return d;
}
/** The inputs that changed since the 원고 초안 was written, in step order: [{key, label}] ([] without a 원고 or inputs). */
export function msChanged(d, style) {
  const was = d?.manuscript?.inputs;
  if (!d?.manuscript?.edited || !was || typeof was !== 'object') return [];
  const now = msBasis(d, style);
  return MS_INPUTS.filter(([k]) => was[k] !== now[k]).map(([key, label]) => ({ key, label }));
}
/** The prompt for SYNC_BUTTON: the whole 원고 as JSON, brought to what changed and to the length set now. */
export function promptSync(d, changed, style) {
  const cur = workList('manuscript', d.manuscript?.edited).map((x) => ({ label: x.label, heading: x.heading, paragraphs: x.paragraphs }));
  const t = msTarget(d);
  const earlier = reqTexts(d);
  return workPrompt([
    `앞 단계에서 바뀐 것(${changed.map((x) => x.label).join(', ')})에 맞게 지금 원고를 고쳐 주세요. 바뀐 것과 관련된 부분만 고치고 나머지는 그대로 두세요.`,
    `네 부분(${MOVES.map((m) => m.label).join('·')})을 꼭 이 순서와 이름으로 두고, 모두 개요 맨 위의 한 문장 메시지를 향하게 하세요.`,
    `${t.minutes}분 설교 분량으로 맞추세요(공백 빼고 약 ${t.chars.toLocaleString('en-US')}자, 부분마다 약 ${Math.round(t.chars / MOVES.length).toLocaleString('en-US')}자). 존댓말 설교체로 쓰세요.`,
    ...(changed.some((x) => x.key === 'illustration') ? ['만들어 둔 예화를 각각 그 들어갈 곳에 자연스럽게 넣으세요(성경 인물 예화는 그 절과 함께). 빠진 예화는 원고에서도 빼세요.'] : []),
    ...(changed.some((x) => x.key === 'application') ? ['만들어 둔 적용을 각각 그 들어갈 곳(대개 결말)에 넣으세요. 빠진 적용은 원고에서도 빼세요.'] : []),
    ...(msNotesOn(d) ? [MS_NOTE_LINE] : []),
    'reply에는 무엇을 어떻게 바꿨는지 한두 문장으로 쓰세요.',
  ].join('\n'), [...workContext(d, 'manuscript'), ...(styleBlock(style) ? [styleBlock(style)] : []), ...(earlier.length ? [block('앞서 반영한 요청', earlier.map((x) => `- ${x}`).join('\n'))] : []),
    block('지금 원고(JSON)', JSON.stringify({ sections: msWithNotes(d, cur) }))],
  `{"manuscript":{"sections":${msShape(d)}},"reply":"한두 문장: 무엇을 어떻게 바꿨는지"}`);
}
/** Characters of the manuscript without spaces, and the minutes that makes at the Claude Code stage's pace. */
export function msLength(v) {
  const chars = workList('manuscript', v).reduce((k, x) => k + x.paragraphs.join('').replace(/\s/g, '').length, 0);
  return { chars, minutes: Math.round(chars / MS_CHARS_PER_MIN) };
}

// ---------------------------------------------------------------- 9 출처 확인 in the page (host:sermon-sources, Claude desktop app)
// The commentary tool on the viewer's own computer picks the books and reads a few located pages; one AI call proposes
// footnotes; every quote is checked on its page by the tool; only checked ones are kept. DOCTRINE.md: doctrine only
// from R books, E/N for facts, history, language (and illustration from E), X never.
export const HOST = 'host:sermon-sources';
export const HOST_TOOLS = ['status', 'select', 'pages', 'verify', 'web-pages', 'web-verify', 'web-search', 'web-read'];
export const SOURCE_BUDGET = { books: 3, pagesPerBook: 4, chars: 24000, footnotes: 12, web: { pages: 4, chars: 24000 } };
export const SOURCE_CLAIMS = ['doctrine', 'fact', 'history', 'language', 'illustration'];
export const SOURCE_QUOTE_MAX = 300;
/** Same rule as sermon-sources check.mjs claimAllowed (copied: this file runs inside the page). */
export function claimAllowed(cls, claim) {
  if (cls === 'X') return false;
  if (claim === 'doctrine') return cls === 'R';
  if (claim === 'illustration') return cls === 'R' || cls === 'E';
  return SOURCE_CLAIMS.includes(claim);
}
export const DOC_LABEL = { E: '비개혁주의 자료', N: '비기독교 자료' };
/** The books to read from the tool's `select` answer: located, never X, R first, a few pages each. */
export function pickBooks(sel, budget = SOURCE_BUDGET) {
  const top = Array.isArray(sel?.top) ? sel.top : [];
  const ok = top.filter((b) => b && typeof b.key === 'string' && b.doctrine !== 'X' && b.located?.found && Number.isInteger(b.located.start));
  const rank = { R: 0, E: 1, N: 2 };
  return ok.sort((a, b) => (rank[a.doctrine] ?? 3) - (rank[b.doctrine] ?? 3)).slice(0, budget.books)
    .map((b) => ({ key: b.key, author: b.author ?? null, title: String(b.title ?? ''), doctrine: b.doctrine, from: b.located.start, to: Math.min(b.located.end ?? b.located.start, b.located.start + budget.pagesPerBook - 1) }));
}
/** Excerpts kept inside the character budget, in reading order (later pages are cut first). */
export function budgetExcerpts(list, budget = SOURCE_BUDGET) {
  let left = budget.chars;
  const out = [];
  for (const x of list) {
    if (x.doctrine === 'X') continue;
    const pages = [];
    for (const p of x.pages || []) {
      if (left <= 0) break;
      const text = [...String(p.text ?? '')].slice(0, left).join('');
      if (!text.trim()) continue;
      pages.push({ page: p.page, text });
      left -= [...text].length;
    }
    if (pages.length) out.push({ key: x.key, author: x.author ?? null, title: x.title, doctrine: x.doctrine, pages });
  }
  return out;
}
/** 확인이 필요한 문장: sentences written as fact (not Bible references, application, exhortation or illustrations). */
export const CLAIM_MAX = 24;
// ---------------------------------------------------------------- 웹에서 찾기 (owner 2026-10-28): the claims still without support
// One AI call makes a short query per claim; the host searches (NAVER API HUB) and reads the top pages (A sites first);
// one AI call proposes footnotes from those pages only; each quote is checked on its page. Never touches the 원고.
export const SEARCH_CLAIMS = 8;
export const SEARCH_READS = { perClaim: 2, total: 8 };
export const SEARCH_NOTE = { 'no-keys': '검색 키가 아직 없어요. 내 자료 연결하기를 봐 주세요.', 'bad-keys': '검색 키가 맞지 않아요. 내 자료 연결하기를 봐 주세요.', quota: '오늘 검색 횟수를 다 썼어요. 내일 다시 해 주세요.', unreachable: '검색이 잠시 안 돼요. 잠시 뒤 다시 눌러 주세요.' };
/** The key file path the commentary tool reports (status, or a no-keys / bad-keys answer), e.g. '~/.claude/.env.local'; else null. */
export const keysFileOf = (p) => (p && typeof p === 'object' && typeof p.keysFile === 'string' && p.keysFile.trim() ? p.keysFile.trim().slice(0, 300) : null);
export const keysFileLine = (file) => `키 파일 자리: ${file}`;
/** The connected commentary folders the tool's status reports ([{path, exists, files, pdfs}], at most 20); null when the
 * payload has no `libraries` (an older tool). */
export const LIBRARIES_MAX = 20;
const count = (v) => (v == null || v === '' || !Number.isFinite(Number(v)) ? null : Math.max(0, Math.floor(Number(v))));
export const librariesOf = (p) => (p && typeof p === 'object' && Array.isArray(p.libraries)
  ? p.libraries.filter((l) => l && typeof l === 'object' && typeof l.path === 'string' && l.path.trim()).slice(0, LIBRARIES_MAX)
    .map((l) => ({ path: l.path.trim().slice(0, 300), exists: l.exists !== false, files: count(l.files), pdfs: count(l.pdfs), ...catalogOf(l.catalog) }))
  : null);
/** The catalog report's numbers for a folder (tool 0.4.4+), kept only when files and pdfs are there. */
const catalogOf = (c) => {
  if (!c || typeof c !== 'object') return {};
  const o = { files: count(c.files), pdfs: count(c.pdfs), duplicates: count(c.duplicates) ?? 0, pdfWithBook: count(c.pdfWithBook) ?? 0 };
  return o.files == null || o.pdfs == null ? {} : { catalog: o };
};
const libNum = (v) => Number(v).toLocaleString('ko-KR'); // 2869 → 2,869
/** What follows the folder path in 내 자료 연결하기: the catalog report's numbers when the tool sends them (the same
 * numbers Claude Code reports), otherwise the live file count. */
export const libraryTail = (l) => {
  if (!l.exists) return ' — 폴더를 찾지 못했어요';
  const c = l.catalog;
  if (c) return ` — 파일 ${libNum(c.files)}개, PDF ${libNum(c.pdfs)}개${c.duplicates ? `(겹치는 파일 ${libNum(c.duplicates)}개 제외)` : ''}, 성경 책을 알아본 PDF ${libNum(c.pdfWithBook)}개`;
  return l.files == null ? ' — 폴더를 읽지 못했어요' : ` — 파일 ${libNum(l.files)}개, PDF ${libNum(l.pdfs ?? 0)}개`;
};
export const LIBRARY_LEAD = '연결한 주석 폴더: ';
export const LIBRARIES_NONE = '아직 연결한 주석 폴더가 없어요. Claude Code에 "내 주석 폴더는 <폴더 경로>야. 연결해 줘"라고 말씀해 주세요.';
export const HOST_FOUND = '주석 도구가 연결돼 있어요';
export const HOST_MISSING = '이 화면에서는 주석 도구를 찾지 못했어요. Claude 데스크톱 앱에서 이 페이지를 열면 연결돼요.';
/** A tool_error still carries the tool's answer (its JSON text): status reports a missing folder that way. */
export const toolErrorPayload = (e) => { try { const b = e?.result?.content?.find?.((x) => x && x.type === 'text'); const v = JSON.parse(b.text); return v && typeof v === 'object' ? v : null; } catch { return null; } };
/** The search note for an error code; for missing or wrong keys it names the key file when the tool told us where. */
export const searchErrorNote = (code, keysFile) => (SEARCH_NOTE[code] || SEARCH_NOTE.unreachable) + ((code === 'no-keys' || code === 'bad-keys') && keysFile ? ' ' + keysFileLine(keysFile) : '');
export function promptClaimQueries({ passage, claims }) {
  return prompt(`아래 설교 원고(${passage})의 문장들을 확인할 인터넷 검색어를 문장마다 하나씩 만들어 주세요. 검색어는 핵심 낱말 2~5개로 짧게(40자 이내) 쓰고, 사전에서 찾을 개념이면 kind를 encyc, 그 밖에는 web으로 쓰세요.`,
    [block('확인할 문장', claims.map((c, i) => `${i + 1}. (${CLAIM_KIND_LABEL[c.kind] ?? c.kind}) ${c.anchor}`).join('\n'))],
    '{"queries":[{"claim":1,"query":"검색어","kind":"web"}]}');
}
/** -> [{claim (0-based), query, kind}]: one per claim at most, a real claim number, a short query. */
export function checkClaimQueries(v, n) {
  const out = [];
  for (const x of Array.isArray(v?.queries) ? v.queries : []) {
    const i = Number(x?.claim) - 1, query = str(x?.query, 60), kind = x?.kind === 'encyc' ? 'encyc' : 'web';
    if (!Number.isInteger(i) || i < 0 || i >= n || !query || out.some((q) => q.claim === i)) continue;
    out.push({ claim: i, query, kind });
  }
  return out;
}
const TIER_RANK = { A: 0, B: 1 };
/** The pages to read: per claim the first few by tier (A first), each page once, at most `total`. */
export function pickReads(perClaim, { each = SEARCH_READS.perClaim, total = SEARCH_READS.total } = {}) {
  const seen = new Set(), out = [];
  for (const [claim, results] of perClaim) {
    const best = [...(results || [])].filter((r) => r && r.doctrine !== 'X' && !seen.has(r.url)).sort((a, b) => (TIER_RANK[a.tier] ?? 2) - (TIER_RANK[b.tier] ?? 2)).slice(0, each);
    for (const r of best) { if (out.length >= total) return out; seen.add(r.url); out.push({ claim, ...r }); }
  }
  return out;
}
/** Read pages (web-read answers) as excerpts for promptFootnotes: key web:<prefix><n>, one 쪽 (1), the site as author. */
export function readExcerpts(reads, prefix = 's') {
  return (reads || []).filter((r) => r && r.text && r.doctrine !== 'X' && /^https?:\/\//.test(r.url)).map((r, i) => ({ key: `web:${prefix}${i + 1}`, author: r.site, title: r.title || r.site, doctrine: r.doctrine, kind: 'web', url: r.url, checkedAt: r.checkedAt ?? null, pages: [{ page: 1, text: r.text }] }));
}
// ---------------------------------------------------------------- 시사 예화 (owner 2026-10-28): from news articles only
export const NEWS_ITEMS = 2;
export const NEWS_RECENT_DAYS = 730;
export const NEWS_RULES = [
  WORK_RULES[0],
  '기사에 있는 사실만 쓰세요. 기사에 없는 사람·장소·숫자·말을 지어내지 마세요.',
  '인용(quote)은 그 기사에 있는 글을 300자 이내로 그대로 옮기고, 예화 본문에는 따옴표 인용을 넣지 마세요.',
  '성경 본문의 문장을 옮겨 쓰지 말고 "책 장:절" 주소로만 가리키세요.',
  '인터넷 주소(URL)를 쓰지 마세요.',
  ...RULES.slice(4),
];
export function promptNewsQueries(d) {
  return workPrompt('이 설교에 쓸 시사 예화(최근 뉴스)를 찾을 뉴스 검색어를 2~3개 만들어 주세요. 설교 방향·개요·듣는 사람들에 맞는 우리 사회의 장면을 찾을 수 있게 핵심 낱말 2~5개로 짧게(40자 이내) 쓰고, 사람 이름은 넣지 마세요.',
    workContext(d, 'illustration'), '{"queries":["검색어"]}');
}
export const checkNewsQueries = (v) => [...new Set((Array.isArray(v?.queries) ? v.queries : []).map((q) => str(q, 40)).filter(Boolean))].slice(0, 3);
/** The articles to read: A sites first, each once, at most `max`. */
export const pickArticles = (results, max = 3) => pickReads([[0, results]], { each: max, total: max });
export function promptNewsIllustrations(d, articles) {
  const art = articles.map((a, i) => `[기사 a${i + 1}] ${a.site}${a.publishedAt ? ` · ${String(a.publishedAt).slice(0, 10)}` : ''} · ${a.title}\n${a.text}`).join('\n\n');
  return workPrompt([
    `아래 기사만 바탕으로 원고 초안에 넣을 시사 예화를 1~${NEWS_ITEMS}개 써 주세요.`,
    '예화마다 기사 번호(article), 들어갈 부분(도입·전개·절정·결말 가운데 하나), 짧은 제목, 예화 본문(기사가 전한 대로 2~4문장, 지어낸 내용 없이), 그 기사에서 그대로 옮긴 인용(quote, 300자 이내), 이어 주는 말(예화에서 말씀으로 넘어가는 한두 문장)을 쓰세요.',
    '설교에 맞는 기사가 없으면 빈 목록으로 답하세요.',
  ].join('\n'), [...workContext(d, 'illustration'), block('기사', art)],
  '{"illustrations":[{"article":"a1","part":"도입","title":"짧은 제목","body":"기사가 전한 대로 2~4문장","quote":"기사의 글 그대로","bridge":"이어 주는 말"}]}', NEWS_RULES);
}
/** -> 시사 예화 items: a real article (its source comes from the search, never from the answer), a part, a quote of at most 300. */
export function checkNewsIllustrations(v, articles) {
  if (/https?:\/\/|www\./i.test(JSON.stringify(v?.illustrations ?? null))) return [];
  const out = [];
  for (const x of Array.isArray(v?.illustrations) ? v.illustrations : []) {
    const a = articles[Number(String(x?.article ?? '').replace(/^a/, '')) - 1];
    const part = PART_OF(x?.part), title = str(x?.title, 80), body = str(x?.body, 800), quote = String(x?.quote ?? '').normalize('NFC').replace(/\s+/g, ' ').trim();
    if (!a || !part || !title || !body || !quote || [...quote].length > SOURCE_QUOTE_MAX || out.some((o) => o.source.url === a.url && o.title === title)) continue;
    if (out.length < NEWS_ITEMS) out.push({ kind: 'news', part, title, body, range: '', bridge: str(x.bridge, 400) || '', quote, source: { title: a.title, url: a.url, site: a.site, publishedAt: a.publishedAt ?? null, tier: a.tier, doctrine: a.doctrine }, verified: false });
  }
  return out;
}
/** The 시사 예화 whose quote was found in the article: excerpts for 출처 확인 (key web:n<k>) so the 원고 gets them as footnotes. */
export const newsExcerpts = (d) => illustrationsOf(d).filter((x) => illKind(x) === 'news' && x.verified && x.source?.url && x.quote)
  .map((x, i) => ({ key: `web:n${i + 1}`, author: x.source.site, title: x.source.title, doctrine: x.source.doctrine ?? 'E', kind: 'web', url: x.source.url, checkedAt: x.checkedAt ?? null, quote: x.quote, pages: [{ page: 1, text: x.quote }] }));
export const CLAIM_KIND_LABEL = { fact: '사실', history: '역사', language: '원어', doctrine: '교리' };
export const commentaryLabel = (f) => `주석: ${f.author || '저자 미상'}, ${f.title}, ${f.page}쪽`;
/** The hosts of the listed online commentaries (sermon-sources web-commentaries.json): web-pages excerpts only from them. */
export const WEB_HOSTS = ['biblehub.com'];
const listedHref = (u) => { try { const x = new URL(u); return x.protocol === 'https:' && WEB_HOSTS.includes(x.hostname) ? x.href : null; } catch { return null; } };
/** A web footnote's link: an http(s) address (the host checked it against the blocklist when it searched or built it). */
export const webHref = (u) => { try { const x = new URL(u); return x.protocol === 'https:' || x.protocol === 'http:' ? x.href : null; } catch { return null; } };
/** Online commentaries (host tool web-pages) as excerpts: one '쪽' (1) each, key 'web:<id>', never X, inside the web budget. */
export function webExcerpts(pages, budget = SOURCE_BUDGET.web) {
  let left = budget.chars;
  const out = [];
  for (const p of Array.isArray(pages) ? pages : []) {
    if (out.length >= budget.pages || left <= 0) break;
    if (!p || typeof p.key !== 'string' || !p.key.startsWith('web:') || p.doctrine === 'X' || !['R', 'E', 'N'].includes(p.doctrine) || !listedHref(p.url)) continue;
    const text = [...String(p.text ?? '')].slice(0, left).join('');
    if (!text.trim()) continue;
    left -= [...text].length;
    out.push({ key: p.key, author: p.author ?? null, title: String(p.title ?? ''), doctrine: p.doctrine, kind: 'web', url: p.url, checkedAt: p.checkedAt ?? null, pages: [{ page: 1, text }] });
  }
  return out;
}
export const webLabel = (f) => `${f.author || '저자 미상'}, ${f.title}`;
export const isWeb = (f) => f?.kind === 'web' || String(f?.key ?? '').startsWith('web:');
/** The excerpts as the AI reads them (출처 확인 and the 본문연구 with notes). */
export const excerptText = (excerpts) => excerpts.map((x) => `[책 ${x.key}] ${x.author || '저자 미상'}, ${x.title} — 등급 ${x.doctrine}\n${x.pages.map((p) => `<${p.page}쪽>\n${p.text}`).join('\n')}`).join('\n\n');
/** The one AI call: footnote proposals for the preacher's manuscript from the excerpts only. */
export function promptFootnotes({ passage, manuscript, excerpts }) {
  const ms = workList('manuscript', manuscript).map((x) => `[${x.label}]\n${x.paragraphs.map((t, j) => `(${j + 1}) ${t}`).join('\n')}`).join('\n\n');
  const ex = excerptText(excerpts);
  return [
    `아래 설교 원고(${passage})의 문장 가운데, 아래 주석 발췌가 뒷받침하는 문장에 각주를 제안해 주세요. 원고의 문장은 고치지 마세요.`,
    `각주마다 원고의 부분 이름(도입·전개·절정·결말)과 문단 번호, 각주를 붙일 원고 문장(원고에 있는 그대로), 책 번호(key), 쪽, 그 쪽에 있는 글을 그대로 옮긴 인용(${SOURCE_QUOTE_MAX}자 이내), 주장의 종류(claim)를 쓰세요. 많아야 ${SOURCE_BUDGET.footnotes}개입니다.`,
    'claim은 doctrine(교리) · fact(사실) · history(역사) · language(원어) · illustration(예화) 가운데 하나입니다.',
    '',
    '지킬 것:',
    '- 교리 주장(doctrine)은 등급 R인 책으로만 뒷받침하세요. 등급 E·N인 책은 사실·역사·원어에만 쓰고(E는 예화도), 교리 근거로 쓰지 마세요.',
    '- 인용은 발췌의 그 쪽에 있는 글자 그대로만 옮기세요. 고쳐 쓰거나 이어 붙이거나 지어내지 마세요.',
    '- 발췌가 뒷받침하지 않는 문장에는 각주를 달지 마세요. 맞는 것이 없으면 빈 목록으로 답하세요.',
    `같은 답에 claims도 쓰세요: 원고에서 사실·역사·배경·원어·교리를 사실처럼 말하는 문장을 모두(많아야 ${CLAIM_MAX}개) 고르세요. 성경 주소, 설교자의 적용·권면, 예화는 고르지 마세요.`,
    'claims마다 부분 이름과 문단 번호, 원고 문장(원고에 있는 그대로), 종류(kind: fact · history · language · doctrine 가운데 하나)를 쓰고, 주석 발췌 가운데 그 문장을 뒷받침하는 쪽이 있으면 책 번호(key)와 쪽을, 없으면 둘 다 null을 쓰세요.',
    ...(excerpts.some((x) => x.kind === 'web') ? ['- 온라인 주석(책 번호가 web:으로 시작)은 한 쪽뿐이니 쪽을 1로 쓰세요.'] : []),
    '- 설명이나 다른 글 없이, 아래 모양의 JSON 하나만 답하세요.',
    '',
    `설교 원고:\n<<<\n${ms}\n>>>`,
    `주석 발췌:\n<<<\n${ex}\n>>>`,
    '',
    'JSON 모양:',
    '{"footnotes":[{"part":"전개","paragraph":1,"sentence":"원고 문장 그대로","key":"책 번호","page":12,"quote":"그 쪽의 글 그대로","claim":"fact"}],"claims":[{"part":"전개","paragraph":1,"sentence":"원고 문장 그대로","kind":"history","key":"책 번호 또는 null","page":12}]}',
  ].join('\n');
}
const squash = (t) => String(t ?? '').normalize('NFC').replace(/\s+/g, ' ').trim();
/**
 * AI proposals -> footnotes that keep the rules (before the tool checks the quotes): a real part and paragraph, a
 * book and page that were read, a quote of at most 300 characters, a claim its doctrine class allows (the class
 * comes from the tool, never from the answer). The sentence becomes the anchor when it is in the paragraph.
 */
export function checkFootnotes(v, { manuscript, excerpts }) {
  const sections = workList('manuscript', manuscript);
  const out = [];
  const dropped = { shape: 0, doctrine: 0 };
  for (const x of Array.isArray(v?.footnotes) ? v.footnotes : []) {
    const si = sections.findIndex((s) => s.label === String(x?.part ?? '').trim());
    const pi = Number(x?.paragraph) - 1;
    const book = excerpts.find((e) => e.key === x?.key);
    const page = Number(x?.page);
    const quote = squash(x?.quote);
    const claim = String(x?.claim ?? '');
    if (si < 0 || !Number.isInteger(pi) || !sections[si].paragraphs[pi] || !book || !book.pages.some((p) => p.page === page) || !quote || [...quote].length > SOURCE_QUOTE_MAX || !SOURCE_CLAIMS.includes(claim)) { dropped.shape++; continue; }
    if (!claimAllowed(book.doctrine, claim)) { dropped.doctrine++; continue; }
    const sentence = squash(x.sentence);
    const anchor = sentence && squash(sections[si].paragraphs[pi]).includes(sentence) ? sentence : '';
    if (out.some((f) => f.key === book.key && f.page === page && f.quote === quote && f.section === si && f.paragraph === pi)) continue;
    if (out.length < SOURCE_BUDGET.footnotes) out.push({ section: si, paragraph: pi, anchor, key: book.key, author: book.author, title: book.title, page, quote, claim, doctrine: book.doctrine, ...(book.kind === 'web' ? { kind: 'web', url: book.url, checkedAt: book.checkedAt } : {}) });
  }
  return { items: out, dropped };
}
/**
 * The answer's claims -> sentences of the manuscript stated as fact: a real part and paragraph, the sentence found in
 * that paragraph, a known kind. 'supported' only when a footnote that passed the tool's check sits on the same
 * paragraph (on this sentence, or on the paragraph as a whole); the claim's own key/page is never trusted.
 */
export function checkClaims(v, { manuscript, footnotes = [] }) {
  const sections = workList('manuscript', manuscript);
  const items = [];
  let dropped = 0;
  for (const x of Array.isArray(v?.claims) ? v.claims : []) {
    const si = sections.findIndex((s) => s.label === String(x?.part ?? '').trim());
    const pi = Number(x?.paragraph) - 1;
    const sentence = squash(x?.sentence);
    const kind = String(x?.kind ?? '');
    if (si < 0 || !Number.isInteger(pi) || !sections[si].paragraphs[pi] || !sentence || !squash(sections[si].paragraphs[pi]).includes(sentence) || !CLAIM_KIND_LABEL[kind]) { dropped++; continue; }
    if (items.some((c) => c.section === si && c.paragraph === pi && c.anchor === sentence)) continue;
    if (items.length >= CLAIM_MAX) { dropped++; continue; }
    const supported = footnotes.some((f) => !f.removed && f.section === si && f.paragraph === pi && (!f.anchor || f.anchor === sentence));
    items.push({ section: si, paragraph: pi, anchor: sentence, kind, status: supported ? 'supported' : 'unsupported' });
  }
  return { items, dropped };
}
/** Footnotes still in use, in manuscript order, numbered 1..n (a removed one keeps its row with removed: true). */
/** The 원고's footnotes from the 주석 메모 it was written on (manuscript.notes -> the notes still in use). */
export function noteFootnotes(d) {
  const notes = new Map(allNotes(d?.exegesis?.edited).map((n) => [n.id, n]));
  return (Array.isArray(d?.manuscript?.notes) ? d.manuscript.notes : []).filter((l) => l && !l.removed && notes.has(l.noteId)).map((l) => {
    const { id: noteId, point: _p, status: _s, ...src } = notes.get(l.noteId);
    return { ...src, id: l.id, section: l.section, paragraph: l.paragraph, anchor: '', noteId, status: 'found' };
  });
}
export function footnotesOf(d) {
  // the 원고's own (from the 본문연구's notes) first, then 출처 확인's; one quote on one paragraph only once
  const own = noteFootnotes(d);
  const same = (a, b) => a.section === b.section && a.paragraph === b.paragraph && a.key === b.key && a.page === b.page && a.quote === b.quote;
  const list = [...own, ...(d?.sourceCheck?.footnotes || []).filter((f) => !f.removed && !own.some((o) => same(o, f)))];
  const sections = workList('manuscript', d?.manuscript?.edited);
  const at = (f) => { const t = squash(sections[f.section]?.paragraphs?.[f.paragraph]); const i = f.anchor ? t.indexOf(f.anchor) : -1; return i < 0 ? t.length : i + f.anchor.length; };
  return list.filter((f) => sections[f.section]?.paragraphs?.[f.paragraph] != null)
    .sort((a, b) => a.section - b.section || a.paragraph - b.paragraph || at(a) - at(b))
    .map((f, i) => ({ ...f, n: i + 1 }));
}
/** A paragraph cut into pieces with the footnote numbers that follow each piece (after its anchor, else at the end). */
export function placeNotes(text, notes) {
  const t = squash(text);
  const cuts = notes.map((f) => { const i = f.anchor ? t.indexOf(f.anchor) : -1; return { at: i < 0 ? t.length : i + f.anchor.length, n: f.n }; }).sort((a, b) => a.at - b.at || a.n - b.n);
  const out = [];
  let from = 0;
  for (const c of cuts) {
    if (out.length && out.at(-1).end === c.at) { out.at(-1).notes.push(c.n); continue; }
    out.push({ text: t.slice(from, c.at), notes: [c.n], end: c.at });
    from = c.at;
  }
  out.push({ text: t.slice(from), notes: [], end: t.length });
  return out.filter((p) => p.text || p.notes.length).map(({ text, notes }) => ({ text, notes }));
}
/** The ring's share of 0-100 per stage of the check: select, pages per book, the one AI call, verify per quote. */
export const RING = { select: [0, 20], pages: [20, 26], web: [26, 30], propose: [30, 88], verify: [88, 94], search: [94, 100] };
/** The AI answer's expected length (a dozen footnotes). */
export const RING_ANSWER_CHARS = 4000;
/** The two long stages ease by elapsed time toward one short of their end (select: first opening of Drive files can
 * take a minute or two; propose: minutes). */
export const RING_TAU_MS = { select: 40000, propose: 90000 };
/** Where the stage alone puts the ring: done/total for pages, web and verify; for select and the AI call the elapsed time
 * eased toward one short of the end, and for the AI call the streamed length if further. */
export function ringAt({ stage, done = 0, total = 0, chars = 0, ms = 0 }) {
  const [a, b] = RING[stage] || [0, 0];
  if (RING_TAU_MS[stage]) {
    const t = 1 - Math.exp(-Math.max(ms, 0) / RING_TAU_MS[stage]);
    const f = stage === 'propose' ? Math.max(Math.min(chars / RING_ANSWER_CHARS, 1), t) : t;
    return a + (b - 1 - a) * Math.min(f, 1); // never the end before the stage is over
  }
  return a + (b - a) * (total > 0 ? Math.min(Math.max(done, 0) / total, 1) : 0);
}
/** The line under the ring for the long stages: how long so far and how long it usually takes. */
export const RING_HINT = { select: '주석을 처음 여는 본문이면 1~2분 걸릴 수 있어요', propose: '보통 1~3분 걸려요' };
export function elapsedKo(ms) {
  const s = Math.floor(Math.max(ms, 0) / 1000);
  return s < 60 ? `${s}초째` : `${Math.floor(s / 60)}분${s % 60 ? ` ${s % 60}초` : ''}째`;
}
export const ringWait = (stage, ms) => (RING_HINT[stage] && ms >= 1000 ? `${elapsedKo(ms)} · ${RING_HINT[stage]}` : '');
/** select gives up when the app's reply time runs out while the commentary files are still being fetched; the files
 * fetched by then are cached, so it is tried once more. */
export const SELECT_RETRY = ['cancelled', 'server_unavailable'];
export async function retryOnce(call, codes, onRetry) {
  try { return await call(); } catch (e) {
    if (!codes.includes(e?.code)) throw e;
    onRetry?.(e);
    return call();
  }
}
/** How long an AI call may take before the page stops waiting: 5 minutes for the footnote proposals, a generous
 * 10 for the others (the grant is asked for before the clock starts, so the consent dialog is not counted). */
export const AI_LIMIT_MS = { propose: 300000, other: 600000 };
/**
 * The page always gets control back from an AI call: the call's promise raced against the Stop signal (rejects
 * {code:'cancelled'} at once) and the time limit (rejects {code:'timeout'}). Whatever comes later (a late answer or
 * error) is ignored.
 */
export function raceSample(p, signal, ms) {
  return new Promise((resolve, reject) => {
    let over = false, timer = null;
    const end = (fn, v) => { if (over) return; over = true; clearTimeout(timer); signal?.removeEventListener('abort', onAbort); fn(v); };
    const fail = (code) => end(reject, Object.assign(new Error(code), { code }));
    const onAbort = () => fail('cancelled');
    if (signal?.aborted) return onAbort();
    signal?.addEventListener('abort', onAbort);
    if (ms > 0) timer = setTimeout(() => fail('timeout'), ms);
    Promise.resolve(p).then((v) => end(resolve, v), (e) => end(reject, e));
  });
}
/** The AI path's bounds: use('sample') (the platform answers within 10 s), the permissions probe (use + state, which
 * may never answer in the desktop app), and the one request when the state is still open. */
export const AI_BOUNDS_MS = { use: 20000, probe: 3000, request: 20000 };
/**
 * The whole path of one AI call, bounded from the press and ended at once by Stop (signal):
 *   use('sample') within 20 s (else 'use_timeout'; null -> 'unavailable');
 *   permissions probe (use('permissions') + state('sample')) within 3 s - never blocking: no answer, an error or
 *   'granted' all go straight on; only 'prompt' asks once with request(['sample']) within 20 s, and then goes on too;
 *   the call itself within callMs ('timeout'); it asks for consent by itself if it still needs to.
 * Without `call` it stops before the call. Resolves {value, consent}; rejects with e.code and e.consent.
 * consent = {use, state, request: {outcome, ms} | null, stalled: 'use'|'state'|'request'|'call'|null}.
 */
export async function aiPath({ use, call, signal, callMs = 0, bounds = AI_BOUNDS_MS, now = () => Date.now() }) {
  const c = { use: null, state: null, request: null, stalled: 'use' };
  const fail = (code) => Object.assign(new Error(code), { code });
  const timed = async (key, p, ms) => {
    const t0 = now();
    try { const v = await raceSample(p, signal, ms); c[key] = { outcome: String(v ?? 'none'), ms: now() - t0 }; return v; } catch (e) {
      if (e?.code === 'cancelled') throw e;
      c[key] = { outcome: e?.code === 'timeout' ? 'timeout' : 'error', ms: now() - t0 };
      return undefined;
    }
  };
  try {
    let sample = null;
    const t0 = now();
    try { sample = await raceSample(use('sample'), signal, bounds.use); } catch (e) {
      if (e?.code === 'cancelled') throw e;
      c.use = { outcome: 'timeout', ms: now() - t0 };
      throw fail('use_timeout');
    }
    c.use = { outcome: sample ? 'ok' : 'null', ms: now() - t0 };
    if (!sample) { c.stalled = null; throw fail('unavailable'); }
    c.stalled = 'state';
    const state = await timed('state', (async () => { const perm = await use('permissions'); return perm ? perm.state('sample') : 'none'; })(), bounds.probe);
    if (state === 'prompt') {
      c.stalled = 'request';
      await timed('request', (async () => { const perm = await use('permissions'); return (await perm.request(['sample']))?.sample; })(), bounds.request);
    }
    if (!call) { c.stalled = null; return { value: undefined, consent: c }; }
    c.stalled = 'call';
    const value = await raceSample(call(sample), signal, callMs);
    c.stalled = null;
    return { value, consent: c };
  } catch (e) {
    const out = fail(String(e?.code ?? 'failed')); // a fresh error: the platform's may be frozen
    out.text = e?.text;
    out.consent = c;
    throw out;
  }
}
/** The ring after an event: {stage, ...} moves it (never back), {end:'done'} snaps it to 100, {end:'fail'} freezes it
 * where it is; after either end nothing moves it. ring = {pct, stage, state:'run'|'done'|'fail'}. */
export function ringNext(ring, ev) {
  if (ring.state !== 'run') return ring;
  if (ev.end === 'done') return { ...ring, pct: 100, state: 'done' };
  if (ev.end === 'fail') return { ...ring, state: 'fail' };
  return { pct: Math.max(ring.pct, ringAt(ev)), stage: ev.stage, state: 'run' };
}
export const ringStart = () => ({ pct: 0, stage: 'select', state: 'run' });
/** 원고 작성하기 ring: the streamed answer's length against the length expected (the characters asked for, plus the
 * spaces and JSON around them). */
export const MS_JSON_FACTOR = 1.15;
export const msExpected = (d) => Math.round(msTarget(d).chars * MS_JSON_FACTOR);
/** 1..99 while the answer streams (100 only when it is in and read). */
export const ringPctOf = (received, expected) => Math.min(Math.max(Math.floor((Math.max(Number(received) || 0, 0) / (expected > 0 ? expected : 1)) * 100), 1), 99);
/** The small ring beside an AI button (owner 2026-10-28): the answer length expected per kind of call (characters of
 * the JSON answer). 개요 follows its fixture (2,787 characters); the others are what a real answer runs to (the test
 * fixtures are shorter). 본문연구 with commentary excerpts adds room for each 주석 메모 it may write (NOTE_MAX.study). */
export const AI_EXPECTED = { passages: 500, flow: 400, directions: 900, outline: 2800, exegesis: 3200, illustration: 1800, application: 600, news: 1400, style: 1600, footnotes: 1800, queries: 400 };
export const AI_NOTE_CHARS = 600;
export const aiExpected = (kind, excerpts = false) => (AI_EXPECTED[kind] || 1000) + (kind === 'exegesis' && excerpts ? AI_NOTE_CHARS * NOTE_MAX.study : 0);
/** Time alone eases the small ring toward 95 (about 25 characters a second, so a call that sends its whole answer at
 * the end still moves); the streamed length takes over when it is further. 1..99 while running. */
export const AI_CHARS_PER_S = 25;
export function aiRingPct({ chars = 0, expected = 1, ms = 0 }) {
  const tau = (Math.max(expected, 1) / AI_CHARS_PER_S) * 1000;
  const byTime = Math.floor(95 * (1 - Math.exp(-Math.max(ms, 0) / tau)));
  return Math.min(Math.max(ringPctOf(chars, expected), byTime, 1), 99);
}
/** 본문연구 with the commentary tool: each stage's share of the small ring (the AI call by its streamed length). */
export const EX_RING = { select: [0, 10], pages: [10, 30], web: [30, 40], write: [40, 90], verify: [90, 100] };
/** A stage with no count to follow (select, web, the news search) eases by time toward one short of its end. */
export const EX_TAU_MS = 20000;
export function stagePct(table, { stage, ai = false, done = 0, total = 0, chars = 0, expected = 1, ms = 0 }) {
  const [a, b] = table[stage] || [0, 0];
  let f;
  if (ai) f = aiRingPct({ chars, expected, ms }) / 100;
  else if (total > 0) f = Math.min(Math.max(done, 0) / total, 1);
  else f = 1 - Math.exp(-Math.max(ms, 0) / EX_TAU_MS);
  return Math.min(Math.max(Math.floor(a + (b - 1 - a) * Math.min(f, 1)), 1), 99);
}
export const exRingPct = (x) => stagePct(EX_RING, { ...x, ai: x.stage === 'write' });
/** 시사 예화 찾기: the query call, the news search, reading the articles, the 예화 call, the quotes checked. */
export const NEWS_RING = { queries: [0, 15], search: [15, 30], read: [30, 45], write: [45, 92], verify: [92, 100] };
export const newsRingPct = (x) => stagePct(NEWS_RING, { ...x, ai: x.stage === 'queries' || x.stage === 'write' });
/** The live line on the 본문연구 stage that is running: how long so far, and for the AI call how much has come. */
export const EX_DOING = { probe: '주석 도구에 허락을 기다리는 중이에요 (앱 위쪽의 허용 창을 확인해 주세요)', select: '주석을 고르는 중', pages: '주석을 읽는 중', web: '온라인 주석을 읽는 중', write: '본문연구를 쓰는 중', verify: '인용을 확인하는 중' };
export const exLive = (stage, ms, chars = 0) => stage === 'probe' ? elapsedKo(ms) : elapsedKo(ms) + ' · ' + EX_DOING[stage] + (stage === 'write' && chars > 0 ? ' · 받은 글 ' + chars.toLocaleString('en-US') + '자' : '');
/** A host tool call in the 본문연구 run that has not answered in this long is passed with its stage's note. */
export const EX_HOST_MS = 60000;

// ---------------------------------------------------------------- 지난 설교: criteria, rows, filters
export const OTHER = '기타(직접 입력)';
export const NONE = '미분류';
export function defaultCriteria() {
  return {
    kind: 'settings',
    criteria: [
      { key: 'date', name: '설교한 날', type: 'date' },
      { key: 'service', name: '예배', options: ['주일 낮', '주일 오후/저녁', '수요', '금요', '새벽', '특별(절기·행사)'] },
      { key: 'place', name: '장소·대상', options: ['본교회 장년', '청년부', '학생부', '수련회', '외부 집회', OTHER] },
      { key: 'category', name: '분류', options: ['주일설교', '강해 시리즈'], none: NONE },
    ],
  };
}
/** Settings from the db merged over the defaults (unknown keys ignored, names and options kept as the user set them). */
export function criteriaOf(doc) {
  const d = defaultCriteria();
  const saved = Array.isArray(doc?.criteria) ? doc.criteria : [];
  d.criteria = d.criteria.map((c) => {
    const s = saved.find((x) => x && x.key === c.key);
    if (!s) return c;
    return { ...c, name: str(s.name, 40) ?? c.name, ...(c.options ? { options: Array.isArray(s.options) ? [...new Set(s.options.map((o) => str(o, 40)).filter(Boolean))] : c.options } : {}) };
  });
  return d;
}
const recs = (r) => (Array.isArray(r?.preached) ? r.preached.filter((p) => p && typeof p === 'object') : []);
export const lastDate = (r) => recs(r).map((p) => String(p.date ?? '')).filter(Boolean).sort().at(-1) ?? '';
/** Newest first: last preached date, then prepared date, then title. */
export function sortRows(rows) {
  return [...rows].sort((a, b) => (lastDate(b) || String(b.preparedAt ?? '')).localeCompare(lastDate(a) || String(a.preparedAt ?? '')) || String(a.title ?? '').localeCompare(String(b.title ?? '')));
}
/** filter = {category, service, place, year}; '' means any; category NONE matches rows without one. */
export function filterRows(rows, f = {}) {
  return rows.filter((r) => {
    if (f.category) { const c = r.category || NONE; if (c !== f.category) return false; }
    if (f.service && !recs(r).some((p) => p.service === f.service)) return false;
    if (f.place && !recs(r).some((p) => p.place === f.place)) return false;
    if (f.year && !recs(r).some((p) => String(p.date ?? '').startsWith(f.year))) return false;
    return true;
  });
}
export const yearsOf = (rows) => [...new Set(rows.flatMap((r) => recs(r).map((p) => String(p.date ?? '').slice(0, 4))).filter((y) => /^\d{4}$/.test(y)))].sort().reverse();
/** Rows whose value changes when a criterion value is renamed (to) or removed (to = null): [{id, row}]. */
export function renameValue(rows, key, from, to) {
  const out = [];
  for (const r of rows) {
    if (key === 'category') { if (r.category === from) out.push({ id: r.id, row: { ...r, category: to } }); continue; }
    const p = recs(r);
    if (p.some((x) => x[key] === from)) out.push({ id: r.id, row: { ...r, preached: p.map((x) => (x[key] === from ? { ...x, [key]: to } : x)) } });
  }
  return out;
}
/** The 지난 설교 row id the skills give a passage: reader code, chapter, first verse, last verse ('jhn-15-1-11'). */
export const rowIdOf = (ref) => (ref?.code ? `${ref.code}-${ref.chap}-${ref.v1}${ref.v2 !== ref.v1 ? `-${ref.v2}` : ''}` : null);
export const usesOf = (rows, key, value) => rows.filter((r) => (key === 'category' ? r.category === value : recs(r).some((x) => x[key] === value))).length;

// ---------------------------------------------------------------- drafts
export const STEPS = ['passage', 'direction', 'outline', 'exegesis', 'setting', 'illustration', 'application', 'manuscript', 'sources'];
export function newDraft(id) {
  return { kind: 'draft', id, passage: '', ref: null, recommend: null, meditation: '', central: null, directions: null, outlines: null, step: 'passage', status: '작성 중' };
}
export const KEPT_MARK = ' (이전 작업)';
/** A copy kept when an earlier step changed carries `kept: true` and says so in its title. */
export const draftTitle = (d) => (d?.directions?.edited?.title || d?.ref?.label || d?.passage || '제목 없는 설교') + (d?.kept ? KEPT_MARK : '');
/** The sentence to say to Claude Code on the computer to check the sources of this draft. */
export const handoffSentence = (d) => `설교준비 도우미의 '${draftTitle(d)}' 이어서 준비해 줘`;
/** Doc ids in the viewer's own collection data/users/<id>: draft.<id>, sermon.<rowId>, settings.criteria, settings.style. */
export const DOC = { draft: (id) => `draft.${id}`, sermon: (id) => `sermon.${id}`, settings: 'settings.criteria', style: 'settings.style' };
// ---------------------------------------------------------------- 마무리하기 (owner 2026-10-28)
// A finished draft leaves 준비중인 설교 (draft.finished; the draft itself is never deleted) and has its 지난 설교 row
// (sermon.<rowIdOf(ref)>, row.draftId), whose main link opens the draft's 설교 원고 inside this page.
export const FINISH_BUTTON = '마무리하기';
export const NO_CATEGORY = '분류 없음';
/** 'YYYY-MM-DD' of a moment in the viewer's own time zone. */
export const localDay = (t) => { const x = new Date(t); return Number.isNaN(x.getTime()) ? '' : `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`; };
const VERSE_RE = /([1-3]?[가-힣]+)\s?(\d+):(\d+)(?:[-~](\d+))?/g;
/** The distinct real Bible references (bible.json) written in the 원고's paragraphs. */
export function bibleCount(books, d) {
  const seen = new Set();
  for (const x of workList('manuscript', d?.manuscript?.edited)) for (const t of x.paragraphs) for (const m of String(t).matchAll(VERSE_RE)) {
    const r = books ? parsePassage(books, `${m[1]} ${m[2]}:${m[3]}${m[4] ? '-' + m[4] : ''}`).ref : null;
    if (r) seen.add(r.label);
  }
  return seen.size;
}
/** -> {draft: a copy with `finished`, id: the row id (null without a passage), row: the fresh 지난 설교 row}. */
export function finishDraft(d, now = new Date(), books = null) {
  const at = new Date(now).toISOString();
  const cat = d?.setting?.category;
  const row = { kind: 'sermon', title: draftTitle(d), passageLabel: d?.ref?.label ?? d?.passage ?? '', category: filled(cat) && cat !== NONE ? cat : null, url: d?.mac?.pageUrl || null,
    preparedAt: localDay(now), updatedAt: at, counts: { sourced: footnotesOf(d).length, bible: bibleCount(books, d), unverified: 0 }, preached: [], draftId: d?.id ?? null };
  return { draft: { ...d, finished: at }, id: rowIdOf(d?.ref), row };
}
/** A row already there (written when the sermon page was published) keeps its 설교한 기록, 분류, counts and url. */
export function mergeRow(existing, fresh) {
  if (!existing) return fresh;
  return { ...existing, title: fresh.title, passageLabel: fresh.passageLabel, preparedAt: fresh.preparedAt, updatedAt: fresh.updatedAt, draftId: fresh.draftId,
    url: existing.url || fresh.url, preached: Array.isArray(existing.preached) ? existing.preached : fresh.preached,
    category: existing.category !== undefined ? existing.category : fresh.category, counts: existing.counts && typeof existing.counts === 'object' ? existing.counts : fresh.counts };
}
export function kindOf(docId) {
  if (docId === DOC.settings) return 'settings';
  if (docId === DOC.style) return 'style';
  if (docId.startsWith('draft.')) return 'draft';
  if (docId.startsWith('sermon.')) return 'sermon';
  return null;
}
/**
 * Two windows on one draft (owner 2026-10-27): the saved copy is newer than the one this page loaded or last wrote
 * (both are updatedAt). Then this page takes the saved copy instead of writing its older one over it.
 */
export function newerRemote(local, remote) {
  const r = Date.parse(String(remote ?? ''));
  if (Number.isNaN(r)) return false;
  const l = Date.parse(String(local ?? ''));
  return Number.isNaN(l) || r > l;
}

// ---------------------------------------------------------------- 준비 단계 (step menu, wizard)
/**
 * Work order of the prep steps (owner 2026-10-26; 6 청중·분량 2026-10-27; 7 예화 · 8 적용 back before the 원고 초안
 * 2026-10-28). 1-9 happen on this page (`seed` is 나의 묵상 or 중심 메시지; 1 and 2 share the start composer). 10 출처 확인 is optional (in the page or by the Claude Code skills, which check
 * the sources and make the sermon page; its state is read from the draft's `mac` field, which only those skills write.
 */
export const STEP_LIST = [
  { key: 'passage', hash: 'step-passage', label: '설교 본문' },
  { key: 'seed', hash: 'step-seed', label: '나의 묵상 / 중심 메시지' },
  { key: 'direction', hash: 'step-direction', label: '설교 방향' },
  { key: 'outline', hash: 'step-outline', label: '개요' },
  { key: 'exegesis', hash: 'step-exegesis', label: '본문연구' },
  { key: 'setting', hash: 'step-setting', label: '청중·분량' },
  { key: 'illustration', hash: 'step-illustration', label: '예화' },
  { key: 'application', hash: 'step-application', label: '적용' },
  { key: 'manuscript', hash: 'step-manuscript', label: MS_LABEL },
  { key: 'sources', hash: 'step-sources', label: '출처 확인', mac: true, optional: true },
];
/** draft.status stays 'Mac 준비 대기' in the data (older drafts and the skills read it); the page shows this. */
export const statusLabel = (st) => (st === 'Mac 준비 대기' ? '출처 확인 준비 대기' : String(st ?? ''));
export const MAC_KEYS = STEP_LIST.filter((s) => s.mac).map((s) => s.key);
const PAGE_ON = ['passage', 'seed', 'direction', 'outline', 'exegesis', 'setting', 'illustration', 'application', 'manuscript'];
// older links: #step-handoff and the old steps on the computer open 출처 확인 (#step-illustration / #step-application are steps again)
const OLD_HASH = { 'step-handoff': 'sources', 'step-page': 'sources' };
export const stepOfHash = (h) => STEP_LIST.find((s) => s.hash === h)?.key ?? OLD_HASH[h] ?? null;
const MAC_STATES = ['todo', 'working', 'done'];
/** The sermon page link the skill wrote, only when it is a claude.ai artifact address. */
export const artifactUrl = (u) => (typeof u === 'string' && /^https:\/\/claude\.ai\/(artifact|code\/artifact)\/[A-Za-z0-9_-]+$/.test(u) ? u : null);
/**
 * mac: {sources: 'todo'|'working'|'done', pageUrl?} — anything else reads as 'todo'. Older drafts wrote the steps on
 * the computer as {exegesis, manuscript, illustration, application, page}: their `page` stands for 출처 확인.
 */
/** A manuscript written in the page, with at least one filled paragraph (what 출처 확인 can footnote). */
export const hasManuscript = (d) => workList('manuscript', d?.manuscript?.edited).some((x) => (x?.paragraphs || []).some((t) => String(t ?? '').trim()));
export function macOf(d) {
  const m = d?.mac && typeof d.mac === 'object' ? d.mac : {};
  const sources = MAC_STATES.includes(m.sources) ? m.sources : MAC_STATES.includes(m.page) ? m.page : 'todo';
  return { sources, pageUrl: sources === 'done' ? artifactUrl(m.pageUrl) : null };
}
/** Which way the draft starts: 'meditation' when there is a meditation, 'central' with a central message, else null. */
export function seedPath(d) {
  if (String(d?.meditation ?? '').trim()) return 'meditation';
  if (String(d?.central?.message ?? '').trim()) return 'central';
  return null;
}
/** Which way the one 나의 묵상 box is written: 'central' (a one-sentence central message) or 'meditation'.
 * Kept as draft.seedMode once switched; an older draft with a separate central message (and no meditation) is 'central'. */
export const seedMode = (d) => (d?.seedMode === 'central' || d?.seedMode === 'meditation' ? d.seedMode : d?.central && !String(d?.meditation ?? '').trim() ? 'central' : 'meditation');
export const seedLabel = (d) => ({ meditation: '나의 묵상', central: '중심 메시지' }[seedPath(d)] ?? STEP_LIST[1].label);
const filled = (s) => !!String(s ?? '').trim();
const handedOff = (d) => d?.step === 'sources' || d?.step === 'handoff' || d?.status === 'Mac 준비 대기';
/** A step holds work: something written (or a suggestion shown) that a change before it would redo. */
export function hasWork(d, key) {
  if (key === 'direction') return !!d?.directions;
  if (key === 'outline') return outlineWork(d);
  if (WORK_KEYS.includes(key)) return !!d?.[key]?.edited;
  return false;
}
const NEXT = { outline: 'exegesis', exegesis: 'setting', illustration: 'application', application: 'manuscript' };
/** An older draft handed to the computer wrote its steps there as mac.{exegesis, manuscript, illustration, application}
 * = 'done' (read raw: macOf keeps only 출처 확인). */
export const doneOnComputer = (d, key) => WORK_KEYS.includes(key) && !!d?.mac && typeof d.mac === 'object' && d.mac[key] === 'done';
/** Content of a step is complete (confirmed with 다음 단계로: the next step was opened; 출처 확인: the skill wrote 'done'). */
export function stepDone(d, key) {
  if (key === 'passage') return !!d?.ref;
  if (key === 'seed') return !!seedPath(d);
  if (key === 'direction') return !!(d?.directions?.edited && filled(d.directions.edited.title) && filled(d.directions.edited.body) && d.outlines);
  if (key === 'outline') return !!(d?.outlines?.edited && (outlineOf(d.outlines.edited).movements.some((m) => filled(m.heading) || m.subs.some((x) => filled(x.text)))) && (d.exegesis || handedOff(d)));
  if (doneOnComputer(d, key)) return true;
  // drafts from the 8-step days went from 청중·분량 straight to the 원고 초안
  if (key === 'setting') return !!(d?.setting && Number(d.setting.minutes) > 0 && (d.illustration || d.application || d.manuscript));
  if (key === 'illustration') return !!(d?.illustration?.edited && (d.application || d.manuscript));
  if (key === 'manuscript') return !!(d?.manuscript?.edited && (handedOff(d) || d.sourceCheck)); // gone on to 출처 확인
  if (key === 'exegesis') return !!(d?.exegesis?.edited && (d.setting || d.manuscript)); // drafts from before 청중·분량 went straight on
  if (WORK_KEYS.includes(key)) return !!(d?.[key]?.edited && d[NEXT[key]]);
  if (key === 'sources') return !!d?.sourceCheck?.footnotes?.length || d?.mac?.sources === 'done'; // never from an old page: 'done'
  if (MAC_KEYS.includes(key)) return macOf(d)[key] === 'done';
  return false;
}
/** A step can be opened when it has been reached once (its content is kept even after going back). */
export function stepReachable(d, key) {
  if (key === 'passage' || key === 'seed') return true;
  if (key === 'direction') return !!d?.directions;
  if (key === 'outline') return !!d?.outlines;
  if (key === 'setting') return !!(d?.setting || d?.exegesis || d?.manuscript) || doneOnComputer(d, 'exegesis') || handedOff(d);
  // 예화 · 적용 open once 청중·분량 (or a later step) is there: a draft from the 8-step days can still make them
  if (key === 'illustration') return !!(d?.illustration || d?.setting || d?.application || d?.manuscript) || doneOnComputer(d, key);
  if (key === 'application') return !!(d?.application || d?.illustration || d?.manuscript) || doneOnComputer(d, key);
  if (WORK_KEYS.includes(key)) return !!d?.[key] || doneOnComputer(d, key);
  return handedOff(d);
}
/**
 * The step to look at now. In the composer: 설교 본문 until the passage is real, then 나의 묵상 / 중심 메시지.
 * A draft handed to the computer before the in-page steps existed (step 'handoff') opens 출처 확인.
 */
export function currentStep(d) {
  const s = d?.step;
  if (s === 'direction' || s === 'outline' || s === 'setting' || WORK_KEYS.includes(s)) return s;
  if (s === 'sources' || s === 'handoff') return 'sources';
  return d?.ref ? 'seed' : 'passage';
}
/**
 * [{key, hash, label, n, mac, optional, state: 'done'|'current'|'todo', review, reachable, work}] in work order.
 * The current step wins over done for steps on this page (going back shows it as current); 출처 확인 finished by
 * the skill stays done. `work` is the skill's own word ('todo'|'working'|'done') for 출처 확인.
 */
export function stepProgress(d) {
  const cur = currentStep(d);
  const review = Array.isArray(d?.review) ? d.review : [];
  const m = macOf(d);
  return STEP_LIST.map((s, i) => {
    const done = stepDone(d, s.key);
    const state = s.mac ? (done ? 'done' : s.key === cur ? 'current' : 'todo') : s.key === cur ? 'current' : done ? 'done' : 'todo';
    return { ...s, label: s.key === 'seed' ? seedLabel(d) : s.label, n: i + 1, mac: !!s.mac, optional: !!s.optional, state, here: s.key === cur, review: state !== 'todo' && review.includes(s.key), reachable: stepReachable(d, s.key), ...(s.mac ? { work: m[s.key] } : {}) };
  });
}
export const currentLabel = (d) => stepProgress(d).find((s) => s.here).label;
/** The page-side screen for a step key: 1-2 → the composer, every other step has its own screen. */
export const screenOf = (key) => (key === 'passage' || key === 'seed' ? 'passage' : key);
const SCREENS = ['passage', 'direction', 'outline', 'exegesis', 'setting', 'illustration', 'application', 'manuscript', 'sources'];
const hasContent = (d, key) => (key === 'direction' ? !!d.directions?.edited : key === 'outline' ? !!d.outlines?.edited : WORK_KEYS.includes(key) ? !!d[key]?.edited : false);
/** Later page steps that already hold content get marked '다시 확인' when an earlier step changes (content is kept). */
export function markLater(d, key) {
  const from = key === 'passage' || key === 'seed' ? 2 : PAGE_ON.indexOf(key) + 1;
  const review = new Set(Array.isArray(d.review) ? d.review : []);
  for (const k of PAGE_ON.slice(from).filter((x) => x !== 'setting')) if (stepDone(d, k) || (stepReachable(d, k) && hasContent(d, k))) review.add(k);
  d.review = STEP_LIST.map((s) => s.key).filter((k) => review.has(k));
  return d.review;
}
export function clearReview(d, ...keys) {
  if (Array.isArray(d.review)) d.review = d.review.filter((k) => !keys.includes(k));
  return d.review;
}
export const REVIEW_NOTE = '앞 단계가 바뀌었어요 — 다시 확인해 주세요';
/** What the summary card at the top shows on a step: only what was chosen before it. */
export function summaryOf(d) {
  const at = SCREENS.indexOf(screenOf(currentStep(d)));
  if (at <= 0) return [];
  const out = []; // the passage is the heading above the card (ref-head), not a row in it
  const path = seedPath(d);
  if (path) out.push({ key: 'seed', label: seedLabel(d), text: path === 'meditation' ? d.meditation.trim() : d.central.message.trim() });
  if (at >= 2 && d.directions?.edited) out.push({ key: 'direction', label: '설교 방향', title: d.directions.edited.title, text: d.directions.edited.body });
  if (at >= 3 && d.outlines?.edited) { const o = outlineOf(d.outlines.edited); out.push({ key: 'outline', label: '개요', message: o.message.trim(), moves: o.movements.map((m) => ({ label: m.label, heading: m.heading.trim() || m.subs.find((x) => filled(x.text))?.text || '' })) }); }
  return out;
}
/** "10월 26일 09:05" in the viewer's local time; '' for a missing or broken time. */
export function timeLabel(iso) {
  const t = new Date(String(iso ?? ''));
  if (!iso || Number.isNaN(t.getTime())) return '';
  const p = (n) => String(n).padStart(2, '0');
  return `${t.getMonth() + 1}월 ${t.getDate()}일 ${p(t.getHours())}:${p(t.getMinutes())}`;
}
const escHtml = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const STATE_WORD = { done: '마침', current: '지금 단계', todo: '아직' };
/** The step list (sidebar submenu and the phone stepper share it). Rendered by the node renderer and by the page. */
export function stepsHtml(progress) {
  return progress.map((s) => '<li class="st st-' + s.state + (s.here ? ' st-here' : '') + (s.review ? ' st-review' : '') + (s.optional ? ' st-optional' : '') + '"><a href="#' + s.hash + '" data-step="' + s.key + '"'
    + (s.here ? ' aria-current="step"' : '') + (s.reachable ? '' : ' aria-disabled="true"') + '>'
    + '<span class="st-mark" aria-hidden="true">' + (s.state === 'done' ? '✓' : s.here ? '→' : s.n) + '</span>'
    + '<span class="st-text"><span class="st-label"><span class="sr">' + s.n + '단계 </span>' + escHtml(s.label) + '</span>'
    + (s.optional ? '<span class="st-opt">선택</span>' : '')
    + (s.work === 'working' ? '<span class="st-work">작업 중</span>' : '')
    + (s.review ? '<span class="st-flag">다시 확인</span>' : '')
    + '<span class="sr"> (' + STATE_WORD[s.state] + ')</span></span></a></li>').join('');
}

// ---------------------------------------------------------------- 앞 단계가 바뀌면 뒤 단계를 다시 (redo)
// What later work was built from is kept with it: directions.basis = the passage and meditation / central message
// the directions came from; outlines.basis = the direction the outlines came from; exegesis.basis = the outline;
// manuscript.basis = the 본문연구. Comparing them with what is
// on the page now tells whether an earlier step really changed (spaces and punctuation alone are not a change).
const clone = (v) => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
export const sameText = (a, b) => String(a ?? '').normalize('NFC').replace(/[\s\p{P}\p{S}]/gu, '') === String(b ?? '').normalize('NFC').replace(/[\s\p{P}\p{S}]/gu, '');
const seedText = (x) => (filled(x?.meditation) ? x.meditation : x?.central?.message ?? '');
const dirText = (e) => `${e?.title ?? ''}\n${e?.body ?? ''}`;
const META = new Set(['by', 'userEdited', 'basis', 'migrated', 'key']);
/** Every written text of a value, in order (who wrote it and other bookkeeping left out). */
const textOf = (v) => (typeof v === 'string' ? v : Array.isArray(v) ? v.map(textOf).join('\n') : v && typeof v === 'object' ? Object.keys(v).filter((k) => !META.has(k)).map((k) => textOf(v[k])).join('\n') : '');
export const basisSeed = (d) => ({ passage: d.passage, ref: clone(d.ref), meditation: d.meditation, central: clone(d.central), ...(d.seedMode ? { seedMode: d.seedMode } : {}) });
export const basisDir = (d) => ({ chosen: d.directions?.chosen ?? null, edited: clone(d.directions?.edited ?? null) });
/** The step each in-page step is built from (its basis holds a copy of that step's edited value). */
export const FROM = { exegesis: 'outline', manuscript: 'exegesis' };
const editedOf = (d, key) => (key === 'outline' ? d.outlines?.edited : d[key]?.edited) ?? null;
export const basisOf = (d, key) => clone(editedOf(d, FROM[key]));
const outlineWork = (d) => !!(d?.outlines && ((d.outlines.items || []).length || d.outlines.edited));
/** Older drafts have no basis yet: what they hold now is what their later steps were built from. */
export function ensureBasis(d) {
  if (d?.directions && !d.directions.basis) d.directions.basis = basisSeed(d);
  if (d?.outlines && !d.outlines.basis && d.directions?.edited) d.outlines.basis = basisDir(d);
  for (const k of WORK_KEYS) if (d?.[k] && d[k].basis === undefined) d[k].basis = basisOf(d, k);
  return d;
}
/** The later steps built from step `key` that hold work (their basis says what `key` was). */
const builtFrom = (d, key) => WORK_KEYS.filter((k) => FROM[k] === key && hasWork(d, k));
/** The earliest earlier step that really changed and has later work: 'passage' | 'seed' | 'direction' | 'outline' | 'exegesis' | null. */
export function changedFrom(d) {
  const b = d?.directions?.basis;
  if (b) {
    if (!sameText(d.ref?.label ?? d.passage, b.ref?.label ?? b.passage)) return 'passage';
    if (!sameText(seedText(d), seedText(b)) || (filled(d.meditation) !== filled(b.meditation))) return 'seed';
  }
  const o = d?.outlines?.basis;
  if (o && outlineWork(d) && !sameText(dirText(d.directions?.edited), dirText(o.edited))) return 'direction';
  for (const key of ['outline', 'exegesis']) {
    const later = builtFrom(d, key).filter((k) => d[k].basis != null);
    if (later.some((k) => !sameText(textOf(editedOf(d, key)), textOf(d[k].basis)))) return key;
  }
  return null;
}
const indexOf = (key) => STEP_LIST.findIndex((s) => s.key === key);
/** Opening `key` goes past the screen of a changed step (1-2 share one screen)? Then that change is settled first. */
// 청중·분량 is built from nothing before it: a change is settled when going on to the 원고
export const redoBefore = (d, key) => { const f = changedFrom(d); return f && key !== 'setting' && indexOf(key) > indexOf(f === 'passage' ? 'seed' : f) ? f : null; };
/** 예화 · 적용 are the pastor's own material: a change before them never clears them (they are marked 다시 확인, and
 * the 원고 초안 picks up their changes through 바뀐 내용 반영하기). */
const KEEP_ON_REDO = ['illustration', 'application'];
/** The later steps that hold work and will be done again after a change at `from` (for the dialog). */
export function laterWork(d, from) {
  const out = [];
  if (from === 'passage' && (filled(d.meditation) || filled(d.central?.message))) out.push({ key: 'seed', label: seedLabel(d) });
  const after = indexOf(from === 'passage' ? 'seed' : from);
  for (const s of STEP_LIST.filter((x, i) => i > after && !x.mac && !KEEP_ON_REDO.includes(x.key))) if (hasWork(d, s.key)) out.push({ key: s.key, label: s.label });
  const m = macOf(d);
  for (const s of STEP_LIST.filter((x) => x.mac)) if (m[s.key] !== 'todo') out.push({ key: s.key, label: s.label });
  return out;
}
const restore = (to, from, d) => {
  const b = d.directions?.basis;
  if (b && (from === 'passage' || from === 'seed')) { to.passage = b.passage; to.ref = clone(b.ref); to.meditation = b.meditation; to.central = clone(b.central); if (b.seedMode) to.seedMode = b.seedMode; else delete to.seedMode; }
  const o = d.outlines?.basis;
  if (o && from === 'direction') { to.directions.chosen = o.chosen; to.directions.edited = clone(o.edited); }
  const later = ['outline', 'exegesis'].includes(from) ? builtFrom(d, from).find((k) => d[k].basis != null) : null;
  if (later) { const v = clone(d[later].basis); if (from === 'outline') to.outlines.edited = v; else to[from].edited = v; }
  return to;
};
/** '이전 작업 남겨 두기': the whole draft as it was before the change, as a separate draft (all its steps intact). */
export function keptCopy(d, from, id, at, mac) {
  const c = restore(clone(d), from, d);
  c.id = id;
  c.kept = true;
  // it opens where its work had reached (the open draft was at the changed step)
  const reached = [...WORK_KEYS].reverse().find((k) => c[k]);
  c.step = c.status === 'Mac 준비 대기' ? 'sources' : reached ?? (outlineWork(c) ? 'outline' : c.directions ? 'direction' : 'passage');
  c.updatedAt = at;
  if (mac !== undefined) c.mac = clone(mac);
  delete c.title;
  delete c.redo;
  return c;
}
/** 취소: the earlier step goes back to what the later work was built from. */
export const revertChange = (d, from) => restore(d, from, d);
/** Go on from the changed step: what came after it is cleared (the change itself is kept). Mutates and returns d. */
export function redoFrom(d, from, at) {
  if (from === 'passage') { d.meditation = ''; d.central = null; }
  if (from === 'passage' || from === 'seed') { d.directions = null; d.outlines = null; d.step = 'passage'; }
  if (from === 'direction') { d.outlines = { items: [], chosen: null, edited: null, basis: basisDir(d) }; d.step = 'outline'; }
  // the in-page steps after the change start empty; the next one is opened with what it is now built from
  const after = indexOf(from === 'passage' ? 'seed' : from);
  for (const k of WORK_KEYS) if (indexOf(k) > after && !KEEP_ON_REDO.includes(k)) d[k] = null;
  const next = { outline: ['exegesis'], exegesis: ['manuscript'] }[from];
  if (next) { for (const k of next) d[k] = { edited: null, basis: basisOf(d, k) }; d.step = next[0]; }
  if (d.mac !== undefined) d.mac = {};
  if (d.status === 'Mac 준비 대기') d.status = '작성 중';
  d.review = [];
  d.redo = { from, at };
  return d;
}
