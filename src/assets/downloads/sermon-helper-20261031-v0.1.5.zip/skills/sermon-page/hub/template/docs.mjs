// 설교준비 도우미 — reading sermon files for 나의 설교 스타일 in the page (embedded without the export keywords, like core.mjs).
// Pure functions over bytes: no DOM, no network. Inflating is done here (inflateRaw), pdf.js is passed in (the page loads it from cdnjs only when a PDF is chosen). Nothing leaves the device.

const u16 = (b, o) => b[o] | (b[o + 1] << 8);
const u32 = (b, o) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;
const utf16 = (b) => new TextDecoder('utf-16le').decode(b);
const utf8 = (b) => new TextDecoder('utf-8').decode(b);
/** Characters that are not white space (a PDF with fewer than 50 is a scanned image). */
export const nonSpace = (t) => String(t ?? '').replace(/\s/g, '').length;
const tidy = (t) => t.split('\n').map((l) => l.replace(/[ \t]+$/g, '')).join('\n').replace(/\n{3,}/g, '\n\n').trim();

// ---------------------------------------------------------------- raw deflate (RFC 1951)
// HWP sections often carry a few bytes after the end of the deflate data, which the browser's DecompressionStream
// refuses; this reader stops at the final block and ignores what follows.
const LEN_BASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
const LEN_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
const DIST_BASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
const DIST_EXTRA = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
const CL_ORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
/** Code lengths -> {count per length, symbols sorted by code} (canonical Huffman). */
const huff = (lens) => {
  const count = new Uint16Array(16), sym = new Uint16Array(lens.length), offs = new Uint16Array(16);
  for (const l of lens) count[l]++;
  count[0] = 0;
  for (let i = 1; i < 16; i++) offs[i] = offs[i - 1] + count[i - 1];
  lens.forEach((l, i) => { if (l) sym[offs[l]++] = i; });
  return { count, sym };
};
let FIXED = null;
export function inflateRaw(src) {
  let pos = 0, bit = 0, out = new Uint8Array(Math.max(1024, src.length * 4)), n = 0;
  const need = (k) => { if (n + k > out.length) { const o = new Uint8Array(Math.max(out.length * 2, n + k)); o.set(out.subarray(0, n)); out = o; } };
  const bits = (k) => {
    let v = 0;
    for (let i = 0; i < k; i++) {
      if (pos >= src.length) throw new Error('deflate: out of data');
      v |= ((src[pos] >> bit) & 1) << i;
      if (++bit === 8) { bit = 0; pos++; }
    }
    return v;
  };
  const decode = (h) => {
    let code = 0, first = 0, index = 0;
    for (let len = 1; len < 16; len++) {
      code |= bits(1);
      const c = h.count[len];
      if (code - first < c) return h.sym[index + code - first];
      index += c; first = (first + c) << 1; code <<= 1;
    }
    throw new Error('deflate: bad code');
  };
  for (let last = 0; !last;) {
    last = bits(1);
    const type = bits(2);
    if (type === 0) {
      if (bit) { bit = 0; pos++; }
      const len = u16(src, pos);
      pos += 4;
      if (pos + len > src.length) throw new Error('deflate: out of data');
      need(len); out.set(src.subarray(pos, pos + len), n); n += len; pos += len;
      continue;
    }
    let lit, dist;
    if (type === 1) {
      if (!FIXED) { const l = new Array(288).fill(8, 0, 144).fill(9, 144, 256).fill(7, 256, 280).fill(8, 280, 288); FIXED = [huff(l), huff(new Array(30).fill(5))]; }
      [lit, dist] = FIXED;
    } else if (type === 2) {
      const hl = bits(5) + 257, hd = bits(5) + 1, hc = bits(4) + 4;
      const cl = new Array(19).fill(0);
      for (let i = 0; i < hc; i++) cl[CL_ORDER[i]] = bits(3);
      const ch = huff(cl), lens = [];
      while (lens.length < hl + hd) {
        const s = decode(ch);
        if (s < 16) lens.push(s);
        else if (s === 16) { if (!lens.length) throw new Error('deflate: bad repeat'); const p = lens[lens.length - 1]; for (let r = 3 + bits(2); r--;) lens.push(p); }
        else for (let r = s === 17 ? 3 + bits(3) : 11 + bits(7); r--;) lens.push(0);
      }
      lit = huff(lens.slice(0, hl)); dist = huff(lens.slice(hl, hl + hd));
    } else throw new Error('deflate: bad block');
    for (;;) {
      const s = decode(lit);
      if (s < 256) { need(1); out[n++] = s; continue; }
      if (s === 256) break;
      const li = s - 257;
      if (li >= 29) throw new Error('deflate: bad length');
      const len = LEN_BASE[li] + bits(LEN_EXTRA[li]);
      const di = decode(dist);
      if (di >= 30) throw new Error('deflate: bad distance');
      const d = DIST_BASE[di] + bits(DIST_EXTRA[di]);
      if (d > n) throw new Error('deflate: distance too far');
      need(len);
      for (let i = 0; i < len; i++, n++) out[n] = out[n - d];
    }
  }
  return out.slice(0, n);
}

// ---------------------------------------------------------------- OLE compound file (the container of a .hwp)
const CFB_SIG = [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1];
const END = 0xfffffffa; // ids at or above this end a chain
/** A compound file -> {read(path)}: path like 'FileHeader' or 'BodyText/Section0'; names() lists the streams. */
export function cfb(b) {
  if (b.length < 512 || CFB_SIG.some((x, i) => b[i] !== x)) throw new Error('not a compound file');
  const ss = 1 << u16(b, 30), ms = 1 << u16(b, 32);
  const sector = (id) => b.subarray((id + 1) * ss, (id + 2) * ss);
  // FAT sectors: 109 in the header, the rest in a DIFAT chain
  const fatIds = [];
  for (let i = 0; i < 109; i++) { const id = u32(b, 76 + i * 4); if (id < END) fatIds.push(id); }
  for (let id = u32(b, 68), n = 0; id < END && n < u32(b, 72); n++) {
    const s = sector(id);
    for (let i = 0; i < ss / 4 - 1; i++) { const x = u32(s, i * 4); if (x < END) fatIds.push(x); }
    id = u32(s, ss - 4);
  }
  const fat = [];
  for (const id of fatIds) { const s = sector(id); for (let i = 0; i < ss / 4; i++) fat.push(u32(s, i * 4)); }
  const chain = (start, next) => { const out = []; for (let id = start; id < END && out.length <= next.length; id = next[id]) out.push(id); return out; };
  const join = (parts, size) => { const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0)); let o = 0; for (const p of parts) { out.set(p, o); o += p.length; } return size == null ? out : out.subarray(0, size); };
  const dir = join(chain(u32(b, 48), fat).map(sector));
  const entries = [];
  for (let o = 0; o + 128 <= dir.length; o += 128) {
    const len = u16(dir, o + 64);
    entries.push({ name: len > 2 ? utf16(dir.subarray(o, o + len - 2)) : '', type: dir[o + 66], left: u32(dir, o + 68), right: u32(dir, o + 72), child: u32(dir, o + 76), start: u32(dir, o + 116), size: u32(dir, o + 120) });
  }
  const root = entries[0];
  const cutoff = u32(b, 56);
  const miniFat = [];
  for (const id of chain(u32(b, 60), fat)) { const s = sector(id); for (let i = 0; i < ss / 4; i++) miniFat.push(u32(s, i * 4)); }
  let mini = null;
  const paths = new Map();
  const walk = (id, prefix, seen) => {
    if (id >= END || id >= entries.length || seen.has(id)) return;
    seen.add(id);
    const e = entries[id];
    walk(e.left, prefix, seen);
    walk(e.right, prefix, seen);
    const p = prefix + e.name;
    if (e.type === 2) paths.set(p, e);
    if (e.type === 1) walk(e.child, p + '/', seen);
  };
  walk(root.child, '', new Set());
  return {
    names: () => [...paths.keys()],
    read(path) {
      const e = paths.get(path);
      if (!e) return null;
      if (e.size < cutoff) {
        mini = mini || join(chain(root.start, fat).map(sector));
        return join(chain(e.start, miniFat).map((id) => mini.subarray(id * ms, (id + 1) * ms)), e.size);
      }
      return join(chain(e.start, fat).map(sector), e.size);
    },
  };
}

// ---------------------------------------------------------------- HWP 5.0
export const HWPTAG_PARA_TEXT = 0x10 + 51;
/** FileHeader: is it HWP 5, compressed, locked (password or 배포용)? */
export function hwpHeader(h) {
  if (!h || h.length < 40 || String.fromCharCode(...h.subarray(0, 17)) !== 'HWP Document File') return null;
  const flags = u32(h, 36);
  return { version: u32(h, 32), compressed: !!(flags & 1), locked: !!(flags & 2) || !!(flags & 4) };
}
/** One PARA_TEXT record's data -> its text: controls under 32 are skipped (8 units for inline/extended ones). */
export function paraText(d) {
  const n = d.length >> 1;
  let out = '', run = 0;
  const flush = (i) => { if (i > run) out += utf16(d.subarray(run * 2, i * 2)); };
  for (let i = 0; i < n;) {
    const c = u16(d, i * 2);
    if (c >= 32) { i++; continue; }
    flush(i);
    if (c === 10 || c === 13) out += '\n';
    else if (c === 9) out += ' ';
    else if (c === 30 || c === 31) out += ' '; // 묶음 빈칸, 고정폭 빈칸
    i += c === 0 || c === 10 || c === 13 || (c >= 24 && c <= 31) ? 1 : 8;
    run = Math.min(i, n);
  }
  flush(n);
  return out.endsWith('\n') ? out : out + '\n';
}
/** A section's records -> text: every PARA_TEXT is one paragraph; other records are skipped by their size. */
export function hwpRecordsText(b) {
  let out = '';
  for (let o = 0; o + 4 <= b.length;) {
    const h = u32(b, o);
    let size = h >>> 20;
    o += 4;
    if (size === 0xfff) { size = u32(b, o); o += 4; }
    if ((h & 0x3ff) === HWPTAG_PARA_TEXT) out += paraText(b.subarray(o, o + size));
    o += size;
  }
  return out;
}
/** A .hwp file -> {text} | {locked: true}. Throws on anything else. */
export async function hwpText(bytes, inflate = inflateRaw) {
  const f = cfb(bytes);
  const head = hwpHeader(f.read('FileHeader'));
  if (!head) throw new Error('not an HWP 5 file');
  if (head.locked) return { locked: true };
  const secs = f.names().map((p) => [p, /^BodyText\/Section(\d+)$/.exec(p)]).filter((x) => x[1]).sort((a, b) => a[1][1] - b[1][1]).map((x) => x[0]);
  const parts = [];
  for (const p of secs) { const raw = f.read(p); parts.push(hwpRecordsText(head.compressed ? await inflate(raw) : raw)); }
  return { text: tidy(parts.join('\n')) };
}

// ---------------------------------------------------------------- ZIP (the container of a .hwpx)
/** The entries of a zip: [{name, method, size, csize, data}] (data still compressed when method 8). */
export function unzip(b) {
  let e = -1;
  for (let o = b.length - 22; o >= Math.max(0, b.length - 65557); o--) if (u32(b, o) === 0x06054b50) { e = o; break; }
  if (e < 0) throw new Error('not a zip');
  const out = [];
  for (let i = 0, o = u32(b, e + 16); i < u16(b, e + 10); i++) {
    if (u32(b, o) !== 0x02014b50) throw new Error('bad zip directory');
    const method = u16(b, o + 10), csize = u32(b, o + 20), size = u32(b, o + 24), nl = u16(b, o + 28), xl = u16(b, o + 30), cl = u16(b, o + 32), lo = u32(b, o + 42);
    const name = utf8(b.subarray(o + 46, o + 46 + nl));
    const start = lo + 30 + u16(b, lo + 26) + u16(b, lo + 28);
    out.push({ name, method, size, csize, data: b.subarray(start, start + csize) });
    o += 46 + nl + xl + cl;
  }
  return out;
}
const entryBytes = async (x, inflate) => (x.method === 0 ? x.data : x.method === 8 ? inflate(x.data) : Promise.reject(new Error('zip method ' + x.method)));
const ENT = { lt: '<', gt: '>', amp: '&', quot: '"', apos: "'" };
const unescapeXml = (s) => s.replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, k) => (k[0] === '#' ? String.fromCodePoint(k[1] === 'x' || k[1] === 'X' ? parseInt(k.slice(2), 16) : Number(k.slice(1))) : ENT[k] ?? m));
/**
 * One HWPX section's XML -> one line per paragraph (<hp:p>), its <hp:t> text in order. A paragraph that holds a table
 * gives its own text first, then the table's paragraphs, in document order.
 */
export function hwpxSectionText(xml) {
  const lines = [], stack = [];
  let inT = 0;
  const emit = (s) => { const t = s.replace(/\s+/g, ' ').trim(); if (t) lines.push(t); };
  for (const m of xml.matchAll(/<(\/?)(?:[\w.-]+:)?([\w.-]+)[^>]*?(\/?)>|([^<]+)/g)) {
    const [, close, name, self, text] = m;
    if (text !== undefined) { if (inT && stack.length) stack[stack.length - 1] += unescapeXml(text); continue; }
    if (name === 'p') {
      if (self) continue;
      if (!close) { if (stack.length) { emit(stack[stack.length - 1]); stack[stack.length - 1] = ''; } stack.push(''); }
      else if (stack.length) emit(stack.pop());
    } else if (name === 't' && !self) inT += close ? -1 : 1;
    else if ((name === 'tab' || name === 'lineBreak') && inT && stack.length) stack[stack.length - 1] += ' ';
  }
  while (stack.length) emit(stack.shift());
  return lines.join('\n');
}
/** A .hwpx file -> its text (sections in number order, a blank line between them). */
export async function hwpxText(bytes, inflate = inflateRaw) {
  const zip = unzip(bytes);
  const mt = zip.find((x) => x.name === 'mimetype');
  if (mt && utf8(await entryBytes(mt, inflate)).trim() !== 'application/hwp+zip') throw new Error('not an HWPX file');
  const secs = zip.map((x) => [x, /^Contents\/section(\d+)\.xml$/i.exec(x.name)]).filter((x) => x[1]).sort((a, b) => a[1][1] - b[1][1]);
  const parts = [];
  for (const [x] of secs) parts.push(hwpxSectionText(utf8(await entryBytes(x, inflate))));
  return tidy(parts.filter(Boolean).join('\n\n'));
}

// ---------------------------------------------------------------- PDF (pdf.js text content)
export const PDF_PAGES = 80;
/** One page's text items -> lines: a new line on hasEOL or when the baseline moves by more than half a line. */
export function pdfPageText(items) {
  let out = '', lastY = null;
  for (const it of items || []) {
    if (typeof it?.str !== 'string') continue;
    const y = Array.isArray(it.transform) ? it.transform[5] : null;
    if (lastY != null && y != null && Math.abs(y - lastY) > Math.max(2, (it.height || 0) / 2) && out && !out.endsWith('\n')) out += '\n';
    out += it.str;
    if (it.hasEOL) out += '\n';
    if (y != null && it.str) lastY = y;
  }
  return tidy(out);
}
/** A PDF through pdf.js -> {text, pages, cut}: every page up to PDF_PAGES, a blank line between pages. */
export async function pdfText(pdfjs, bytes, max = PDF_PAGES) {
  const doc = await pdfjs.getDocument({ data: bytes, isEvalSupported: false }).promise;
  const n = Math.min(doc.numPages, max);
  const pages = [];
  for (let i = 1; i <= n; i++) pages.push(pdfPageText((await (await doc.getPage(i)).getTextContent()).items));
  if (doc.destroy) doc.destroy();
  return { text: pages.filter(Boolean).join('\n\n'), pages: n, cut: doc.numPages > max };
}
