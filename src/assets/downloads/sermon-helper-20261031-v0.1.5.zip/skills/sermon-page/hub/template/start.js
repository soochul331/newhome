// 설교준비 도우미 runtime. Works without any capability (manual writing, no saving); lights up saving (db + user)
// and AI suggestions (sample) only when claude.use() resolves them. Never calls sample on load.
(function () {
  const BOOKS = JSON.parse(document.getElementById('bible-data').textContent).books;
  const $ = (s, el) => (el || document).querySelector(s);
  const $$ = (s, el) => Array.from((el || document).querySelectorAll(s));
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const use = (name) => {
    try {
      return window.claude && typeof window.claude.use === 'function' ? Promise.resolve(window.claude.use(name)).catch(() => null) : Promise.resolve(null);
    } catch (e) {
      return Promise.resolve(null);
    }
  };
  // no badges on this page (owner 2026-10-26): users know the suggestions come from AI
  const safeUrl = (u) => (typeof u === 'string' && /^https:\/\/claude\.ai\/(artifact|code\/artifact)\/[A-Za-z0-9_-]+$/.test(u) ? u : null);
  const num = (v) => (Number.isFinite(Number(v)) && Number(v) >= 0 ? Math.floor(Number(v)) : 0);
  const newId = () => Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);

  // ---------------------------------------------------------------- views (hash routes #start #drafts #past)
  const VIEWS = ['start', 'drafts', 'past', 'guide', 'style'];
  function show(view) {
    if (!VIEWS.includes(view)) view = 'start';
    if (view === 'guide' && S.host == null) probeHost(); // 내 자료 연결하기 shows the tool and the connected folders
    for (const v of VIEWS) {
      $('#' + v + '-view').hidden = v !== view;
      const a = $('.menu a[href="#' + v + '"]');
      if (v === view) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    }
    // narrow screens: the menu row scrolls sideways; keep the current item inside it (no page scroll)
    const row = $('.menu'), cur = $('.menu a[aria-current="page"]');
    if (!cur) return;
    const rr = row.getBoundingClientRect(), cr = cur.getBoundingClientRect();
    if (cr.left < rr.left) row.scrollLeft -= rr.left - cr.left + 8;
    else if (cr.right > rr.right) row.scrollLeft += cr.right - rr.right + 8;
  }
  // #step-passage … #step-page open a prep step inside the start view (wired after the state below)
  const fromHash = () => {
    const h = (location.hash || '').slice(1);
    const step = stepOfHash(h);
    if (step) { show('start'); openStep(step, { push: false }); } else if (h.startsWith('past/')) openPast(decodeURIComponent(h.slice(5))); else show(VIEWS.includes(h) ? h : 'start');
  };

  // ---------------------------------------------------------------- state
  const S = { uid: null, db: null, col: null, docs: new Map(), draft: newDraft(newId()), sample: null, aiOff: false, aiBusy: null, filter: { category: '', service: '', place: '', year: '' } };
  const status = (msg) => { $('#save-status').textContent = msg || ''; };
  const aiStatus = (msg) => { $('#ai-status').textContent = msg || ''; };

  // ---------------------------------------------------------------- saving: one write at a time per doc, only on change
  const written = new Map(); // docId -> JSON last written (or received)
  // key order differs between what the page builds and what the db hands back: compare with sorted keys
  const canon = (v) => JSON.stringify(v, (_k, x) => (x && typeof x === 'object' && !Array.isArray(x) ? Object.fromEntries(Object.keys(x).sort().map((k) => [k, x[k]])) : x));
  const inflight = new Map(); // docId -> pending data
  async function save(docId, data) {
    if (!S.col) return;
    const { updatedAt: _u, ...same } = data; // a new timestamp alone is not a change
    const json = canon(same);
    if (written.get(docId) === json && !inflight.has(docId)) return;
    if (inflight.has(docId)) { inflight.set(docId, data); return; }
    inflight.set(docId, null);
    try {
      written.set(docId, json);
      await S.col.doc(docId).set(data);
      status('저장했어요');
    } catch (e) {
      written.delete(docId);
      status('저장하지 못했어요. 잠시 뒤 다시 고쳐 보세요.');
    }
    const next = inflight.get(docId);
    inflight.delete(docId);
    if (next) save(docId, next);
  }
  async function remove(docId) {
    if (!S.col) return;
    try { await S.col.doc(docId).delete(); written.delete(docId); } catch (e) { status('지우지 못했어요.'); }
  }
  let timer = null;
  function saveDraft(now) {
    const d = S.draft;
    if (!d.passage && !d.meditation && !d.central && !d.directions) return; // an empty draft is not kept
    clearTimeout(timer);
    timer = null;
    const go = () => {
      timer = null;
      // another window saved this draft after this page loaded or wrote it: take that copy, never write the older one over it
      const id = DOC.draft(d.id), remote = S.docs.get(id);
      if (S.draft === d && (S.remoteWaiting || (remote && !inflight.has(id) && newerRemote(S.base, remote.updatedAt)))) { if (remote) adoptRemote(remote); else S.remoteWaiting = false; return; }
      const at = new Date().toISOString();
      // mac.* belongs to the Mac skills: always send back what was last read, never this page's own idea of it
      const data = { ...d, ...macField(d), title: draftTitle(d), createdAt: d.createdAt || (d.createdAt = at), updatedAt: at };
      const { updatedAt: _u, ...same } = data;
      if (S.draft === d && (inflight.has(id) || written.get(id) !== canon(same))) S.base = at; // only a write that really goes out
      return save(id, data);
    };
    if (now) return go();
    timer = setTimeout(go, 800);
  }

  const macField = (d) => { const saved = S.docs.get(DOC.draft(d.id)); const m = saved && saved.mac !== undefined ? saved.mac : d.mac; return m === undefined ? {} : { mac: m }; };

  // ---------------------------------------------------------------- 새 설교 시작: passage
  const passageIn = $('#f-passage');
  function renderPassage() {
    const r = parsePassage(BOOKS, passageIn.value);
    const out = $('#passage-parsed');
    const before = S.draft.ref?.label;
    if (r.ref) {
      S.draft.ref = r.ref;
      out.innerHTML = '<a class="bref" href="' + esc(r.ref.url) + '" target="_blank" rel="noopener">' + esc(r.ref.label) + ' · 개역개정 읽기</a>';
      out.classList.remove('warn');
    } else {
      S.draft.ref = null;
      out.textContent = r.error || '';
      out.classList.toggle('warn', !!r.error);
    }
    if ((S.draft.ref?.label || null) !== (before || null) && before !== undefined) changed('passage');
    updateGates();
  }
  // an older draft gets its basis (what its later steps were built from) just before its first change
  passageIn.addEventListener('input', () => { ensureBasis(S.draft); S.draft.passage = passageIn.value; renderPassage(); saveDraft(); });

  // 본문 추천
  $('#btn-recommend').addEventListener('click', () => { const p = $('#recommend-panel'); p.hidden = !p.hidden; $('#btn-recommend').setAttribute('aria-expanded', String(!p.hidden)); if (!p.hidden) $('#f-message').focus(); });
  $('#btn-recommend-go').addEventListener('click', (e) => withRing(e.currentTarget, 'passages', async () => {
    const message = $('#f-message').value.trim(), audience = $('#f-audience').value.trim();
    if (!message || !audience) { aiStatus('전하고 싶은 메시지와 듣는 사람들의 상황을 모두 적어 주세요.'); return; }
    const v = await ask(promptPassages({ message, audience }));
    if (v === undefined) return;
    const r = checkPassages(BOOKS, v);
    S.draft.recommend = { message, audience, items: r.items, dropped: r.dropped };
    renderRecommend();
    saveDraft(true);
    return true;
  }));
  function renderRecommend() {
    const rec = S.draft.recommend;
    const box = $('#recommend-list');
    if (!rec) { box.innerHTML = ''; return; }
    $('#f-message').value = rec.message; $('#f-audience').value = rec.audience;
    box.innerHTML = (rec.items.length
      ? rec.items.map((p, i) => '<li class="pick-card"><div class="pick-head"><a class="bref" href="' + esc(p.url) + '" target="_blank" rel="noopener">' + esc(p.label) + ' · 개역개정 읽기</a></div><p>' + esc(p.reason) + '</p><button type="button" class="btn" data-use-passage="' + i + '">이 본문으로</button></li>').join('')
      : '<li class="empty">추천할 본문을 찾지 못했어요. 메시지를 조금 바꿔 다시 받아 보세요.</li>')
      + (rec.dropped ? '<li class="note">성경에 없는 주소이거나 이유가 없는 추천 ' + rec.dropped + '개는 뺐어요.</li>' : '');
  }
  $('#recommend-list').addEventListener('click', (e) => {
    const b = e.target.closest('[data-use-passage]');
    if (!b) return;
    const p = S.draft.recommend.items[Number(b.dataset.usePassage)];
    ensureBasis(S.draft);
    passageIn.value = S.draft.passage = p.label;
    renderPassage();
    $('#meditate-nudge').hidden = false;
    $('#f-meditation').focus();
    saveDraft(true);
  });

  // ---------------------------------------------------------------- meditation / central message
  const medIn = $('#f-meditation');
  // one box: 나의 묵상, or in central-message mode the one-sentence central message (kept in central.message as before)
  const SEED_MODE = {
    meditation: { label: '나의 묵상', rows: 5, placeholder: '본문을 읽으며 마음에 닿은 것, 붙들게 된 말씀, 성도들에게 나누고 싶은 것', link: '묵상이 아직 없나요? 중심 메시지로 시작하기' },
    central: { label: '나의 묵상 · 중심 메시지', rows: 3, placeholder: '한 문장으로: 이 설교에서 꼭 전하고 싶은 것', link: '묵상으로 쓰기' },
  };
  const setSeedText = (d, text) => { if (seedMode(d) === 'central') d.central = { ...(d.central || {}), message: text }; else d.meditation = text; };
  function renderSeed() {
    const d = S.draft, mode = seedMode(d), m = SEED_MODE[mode];
    $('#seed-label').textContent = m.label;
    medIn.rows = m.rows;
    medIn.placeholder = m.placeholder;
    medIn.value = mode === 'central' ? d.central?.message || '' : d.meditation;
    $('#btn-seed-mode').textContent = m.link;
    $('#central-panel').hidden = mode !== 'central';
  }
  medIn.addEventListener('input', () => { ensureBasis(S.draft); setSeedText(S.draft, medIn.value); changed('seed'); updateGates(); saveDraft(); });
  // switching the mode keeps whatever is in the box: it moves to the other field (a written flow stays with central)
  $('#btn-seed-mode').addEventListener('click', () => {
    const d = S.draft, text = medIn.value;
    ensureBasis(d);
    setSeedText(d, '');
    d.seedMode = seedMode(d) === 'central' ? 'meditation' : 'central';
    setSeedText(d, text);
    changed('seed');
    renderSeed();
    renderFlow();
    updateGates();
    saveDraft();
    medIn.focus();
  });
  // 메시지 흐름: one flow written and read first, then 이대로 다음 단계로 or one part chosen to edit
  const FLOW = [['intro', '도입'], ['body', '전개'], ['conclusion', '결론']];
  const flowEdit = { part: null, before: null };
  async function writeFlow() {
    const central = medIn.value.trim();
    if (!central) { aiStatus('이 설교의 중심 메시지를 한 문장으로 적어 주세요.'); return; }
    const v = await ask(promptFlow({ passage: S.draft.ref?.label, central }));
    if (v === undefined) return;
    ensureBasis(S.draft);
    const flow = checkFlow(v);
    if (!flow) { aiStatus('흐름을 읽지 못했어요. 메시지 흐름 작성하기를 다시 눌러 주세요.'); return; }
    S.draft.central = { message: medIn.value, flow, flowEdited: false };
    flowEdit.part = null;
    changed('seed');
    renderFlow();
    updateGates();
    saveDraft(true);
    $('#flow-h').focus();
    return true;
  }
  $('#btn-flow').addEventListener('click', (e) => withRing(e.currentTarget, 'flow', writeFlow));
  $('#btn-flow-rewrite').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    const msg = S.draft.central?.flowEdited ? '고치신 내용이 있어요. 다시 작성하면 지금 흐름이 새 흐름으로 바뀌어요. 다시 작성할까요?' : '지금 흐름을 새로 작성한 흐름으로 바꿀까요?';
    if (await askUser({ title: msg, ok: '다시 작성하기' })) withRing(btn, 'flow', writeFlow);
  });
  function renderFlow() {
    const c = S.draft.central;
    const box = $('#flow');
    if (!c?.flow) { box.hidden = true; return; }
    box.hidden = false;
    $('#flow-read').innerHTML = FLOW.map(([k, label]) => flowEdit.part === k
      ? '<section class="mv ol-part editing"><label for="flow-' + k + '">' + label + ' 고치기</label><textarea id="flow-' + k + '" rows="3" data-flow="' + k + '">' + esc(c.flow[k]) + '</textarea><div class="actions part-done"><button type="button" class="btn primary" data-flow-save>저장</button><button type="button" class="btn" data-flow-cancel>취소</button></div></section>'
      : '<section class="ol-part" id="flow-part-' + k + '"><h4 id="flow-part-' + k + '-h" tabindex="-1"><span class="mv-label">' + label + '</span></h4><p class="ol-flow">' + (c.flow[k].trim() ? esc(c.flow[k]) : '<span class="note">아직 비어 있어요.</span>') + '</p></section>').join('');
    $('#flow-ask').hidden = flowEdit.part !== null;
    $('#btn-flow-rewrite').hidden = S.aiOff;
  }
  $('#flow').addEventListener('click', (e) => {
    const pick = e.target.closest('[data-flow-part]');
    if (pick) {
      flowEdit.part = pick.dataset.flowPart;
      flowEdit.before = S.draft.central.flow[flowEdit.part];
      renderFlow();
      $('#flow-' + flowEdit.part).focus();
      return;
    }
    const done = e.target.closest('[data-flow-save], [data-flow-cancel]');
    if (done) {
      const k = flowEdit.part;
      if (done.dataset.flowCancel !== undefined) { S.draft.central.flow[k] = flowEdit.before; saveDraft(true); }
      flowEdit.part = null;
      renderFlow();
      $('#flow-part-' + k + '-h').focus();
    }
  });
  $('#flow').addEventListener('input', (e) => {
    const k = e.target.dataset.flow;
    if (!k) return;
    ensureBasis(S.draft);
    S.draft.central.flow[k] = e.target.value;
    S.draft.central.flowEdited = true;
    changed('seed');
    saveDraft();
  });
  // 이대로 다음 단계로 is the composer's only way on here: directions already there (and the message unchanged since),
  // go on to them; else ask for them (a changed message is settled by the redo dialog first)
  $('#btn-flow-next').addEventListener('click', () => { if (S.draft.directions && !changedFrom(S.draft)) goStep('direction'); else if (S.aiOff) $('#btn-direction-manual').click(); else withRing($('#btn-flow-next'), 'directions', askDirections); });

  // ---------------------------------------------------------------- 설교 방향
  const ready = () => !!S.draft.ref && (!!S.draft.meditation.trim() || !!S.draft.central?.message?.trim());
  /** The composer's one way on (never two competing ones): the flow's 이대로 다음 단계로 once a flow is shown;
   * central message without a flow yet: 메시지 흐름 작성하기; kept directions: 다음 단계로; else 설교 방향 추천받기
   * (without AI: 직접 쓰기, or 다음 단계로 when directions are kept). */
  function forward() {
    const d = S.draft, central = seedMode(d) === 'central';
    if (central && d.central?.flow) return 'flow-next';
    if (central && !S.aiOff) return 'flow';
    if (d.directions) return 'start-next';
    return S.aiOff ? 'manual' : 'directions';
  }
  function updateGates() {
    const fwd = forward();
    $('#btn-start-next').hidden = fwd !== 'start-next';
    $('#btn-start-next').disabled = !ready();
    $('#btn-directions').hidden = fwd !== 'directions';
    $('#btn-directions').disabled = !ready() || !!S.aiBusy;
    $('#btn-direction-manual').hidden = fwd !== 'manual';
    $('#btn-direction-manual').disabled = !S.draft.ref;
    $('#btn-flow').hidden = fwd !== 'flow';
    $('#gate-hint').textContent = !S.draft.ref ? '본문을 먼저 정해 주세요.' : ready() ? '' : seedMode(S.draft) === 'central' ? '중심 메시지를 한 문장으로 적어 주세요.' : '나의 묵상을 적거나, 중심 메시지로 시작해 주세요.';
    renderSteps(); // passage / meditation typing moves steps 1-2 and the step 2 label
  }
  // asking again (설교 방향 단계의 '다른 방향도 추천받기') only adds new cards: the direction chosen and edited stays
  async function askDirections() {
    if (changedFrom(S.draft) && !(await askRedo(changedFrom(S.draft)))) return;
    if (!ready()) { $(S.draft.ref ? '#f-meditation' : '#f-passage').focus(); return; }
    const d = S.draft;
    const v = await ask(promptDirections({ passage: d.ref.label, meditation: d.meditation.trim(), central: d.central?.message, flow: d.central?.flow }));
    if (v === undefined) return;
    const r = checkDirections(v);
    if (!r.items.length) { aiStatus('설교 방향을 받지 못했어요. 묵상을 조금 더 적고 다시 눌러 주세요.'); return; }
    const prev = d.directions;
    d.directions = prev?.edited ? { ...prev, items: r.items, chosen: null } : { items: r.items, chosen: null, edited: null, by: 'ai' };
    d.directions.basis = basisSeed(d); // what these directions were built from
    goStep('direction');
    return true;
  }
  $('#btn-directions').addEventListener('click', (e) => withRing(e.currentTarget, 'directions', askDirections));
  $('#btn-dir-again').addEventListener('click', (e) => withRing(e.currentTarget, 'directions', askDirections));
  $('#btn-direction-manual').addEventListener('click', () => {
    S.draft.directions = { items: [], chosen: null, edited: { title: '', body: '' }, by: 'user', userEdited: true, basis: basisSeed(S.draft) };
    goStep('direction', { focus: false });
    $('#dir-title').focus();
  });
  $('#btn-start-next').addEventListener('click', () => goStep('direction'));
  function renderDirection() {
    const D = S.draft.directions;
    const sec = $('#step-direction');
    sec.hidden = !D || screen() !== 'direction';
    if (sec.hidden) return;
    reviewNote('direction');
    $('#dir-cards').innerHTML = D.items.map((x, i) => '<li class="pick-card' + (D.chosen === i ? ' chosen' : '') + '"><div class="pick-head"><h3>' + esc(x.title) + '</h3></div><p>' + esc(x.body) + '</p><button type="button" class="btn" data-pick-dir="' + i + '" aria-pressed="' + (D.chosen === i) + '">이 방향으로</button></li>').join('');
    const ed = $('#dir-editor');
    ed.hidden = !D.edited;
    if (D.edited) {
      $('#dir-title').value = D.edited.title;
      $('#dir-body').value = D.edited.body;
    }
    $('#btn-dir-next').disabled = !(D.edited && D.edited.title.trim() && D.edited.body.trim());
  }
  $('#dir-cards').addEventListener('click', (e) => {
    const b = e.target.closest('[data-pick-dir]');
    if (!b) return;
    ensureBasis(S.draft);
    const D = S.draft.directions;
    D.chosen = Number(b.dataset.pickDir);
    D.edited = { ...D.items[D.chosen] };
    D.userEdited = false;
    changed('direction');
    renderDirection();
    saveDraft(true);
    $('#dir-title').focus();
  });
  for (const id of ['dir-title', 'dir-body']) $('#' + id).addEventListener('input', () => {
    ensureBasis(S.draft);
    const D = S.draft.directions;
    D.edited = { title: $('#dir-title').value, body: $('#dir-body').value };
    D.userEdited = true;
    changed('direction');
    $('#btn-dir-next').disabled = !(D.edited.title.trim() && D.edited.body.trim());
    saveDraft();
  });
  $('#btn-dir-next').addEventListener('click', () => {
    const O = S.draft.outlines;
    // no outline work yet: the outline step simply follows the direction as it is now
    if (!O) S.draft.outlines = { items: [], chosen: null, edited: null, basis: basisDir(S.draft) };
    else if (!(O.items || []).length && !O.edited) O.basis = basisDir(S.draft);
    clearReview(S.draft, 'direction');
    goStep('outline');
  });

  // ---------------------------------------------------------------- 개요: 하나를 써서 읽게 보여 주고, 고칠 부분만 골라 고친다
  const olEdit = { part: null, before: null }; // the part open for editing ('one' | 0-3) and its copy for 취소
  async function writeOutline() {
    const d = S.draft;
    const v = await ask(promptOutlines({ passage: d.ref.label, ref: d.ref, direction: d.directions.edited }));
    if (v === undefined) return;
    const r = checkOutlines(BOOKS, d.ref, v);
    if (!r.items.length) { aiStatus('개요가 정해진 모양(한 문장 메시지와 도입·전개·절정·결말)에 맞지 않아 쓰지 않았어요. 개요 작성하기를 다시 눌러 주세요.'); return; }
    const one = JSON.parse(JSON.stringify(r.items[0]));
    d.outlines = { ...(d.outlines || {}), items: [r.items[0]], dropped: r.dropped, chosen: 0, edited: { ...one, by: 'ai', userEdited: false } };
    olEdit.part = null;
    changed('outline');
    renderOutline();
    saveDraft(true);
    $('#ol-read-h').focus();
    return true;
  }
  $('#btn-outlines').addEventListener('click', (e) => withRing(e.currentTarget, 'outline', writeOutline));
  $('#btn-ol-rewrite').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    const E = S.draft.outlines?.edited;
    const msg = E && E.userEdited ? '고치신 내용이 있어요. 다시 작성하면 지금 개요가 새 개요로 바뀌어요. 다시 작성할까요?' : '지금 개요를 새로 작성한 개요로 바꿀까요?';
    if (await askUser({ title: msg, ok: '다시 작성하기' })) withRing(btn, 'outline', writeOutline);
  });
  /** The outline shown and edited: the edited one; an older draft with several suggestions shows the chosen or the first. */
  const shownOutline = (O) => O.edited || O.items[O.chosen ?? 0] || O.items[0] || null;
  const blankOutline = () => { const o = outlineOf({ movements: [] }); delete o.migrated; for (const m of o.movements) { m.subs = [{ text: '', range: '' }]; if (m.applications) m.applications = ['']; } return o; };
  const rangeRef = (text) => (text.trim() ? parseRange(BOOKS, S.draft.ref, text) : null);
  const subRefHtml = (text) => { const r = rangeRef(text); return text.trim() && !r ? '<span class="note warn">이 본문에 없는 절이에요</span>' : r ? '<a class="bref" href="' + esc(r.url) + '" target="_blank" rel="noopener">읽기</a>' : ''; };
  const crossHtml = (text) => { if (!text.trim()) return ''; const r = parsePassage(BOOKS, text).ref; return r ? '<a class="bref" href="' + esc(r.url) + '" target="_blank" rel="noopener">' + esc(r.label) + ' · 개역개정 읽기</a>' : '<span class="note warn">성경 주소를 확인해 주세요</span>'; };
  const EMPTY = '<p class="note">아직 비어 있어요. 이 부분을 골라 채워 주세요.</p>';
  /** One part as reading text: heading, how it serves the sentence, sub-points with verses, then the extras. */
  function partRead(m, i) {
    const subs = m.subs.filter((x) => x.text.trim());
    const filledAny = m.heading.trim() || m.serves.trim() || subs.length;
    return '<section class="ol-part" id="ol-part-' + i + '" aria-labelledby="ol-part-' + i + '-h"><h4 id="ol-part-' + i + '-h"><span class="mv-label">' + esc(m.label) + '</span>' + (m.heading.trim() ? ' ' + esc(m.heading) : '') + '</h4>'
      + (!filledAny ? EMPTY : '')
      + (m.serves.trim() ? '<p class="ol-serves">' + esc(m.serves) + '</p>' : '')
      + (subs.length ? '<ul class="ol-subs">' + subs.map((x) => '<li>' + esc(x.text) + (x.range ? ' <span class="ol-verse">' + esc(x.range) + '</span>' : '') + '</li>').join('') + '</ul>' : '')
      + (m.cross.trim() ? '<p class="ol-extra"><span class="ol-k">함께 볼 본문</span> ' + crossHtml(m.cross) + '</p>' : '')
      + (m.background.trim() ? '<p class="ol-extra"><span class="ol-k">배경 메모</span> ' + esc(m.background) + ' <span class="note">(확인한 뒤 쓰세요)</span></p>' : '')
      + (m.idea.trim() ? '<p class="ol-extra"><span class="ol-k">예화 아이디어</span> ' + esc(m.idea) + ' <span class="note">(목사님 예화로 바꿔 주세요)</span></p>' : '')
      + (m.applications && m.applications.some((a) => a.trim()) ? '<p class="ol-k ol-ap-k">적용</p><ol class="ol-aps">' + m.applications.filter((a) => a.trim()).map((a) => '<li>' + esc(a) + '</li>').join('') + '</ol>' : '')
      + '</section>';
  }
  const fieldId = (i, f) => 'mv-' + i + '-' + f;
  /** The edit form for one part only (every field of it). */
  function partForm(m, i) {
    const lab = (f, label, extra) => '<label for="' + fieldId(i, f) + '">' + label + (extra ? ' <span class="note">' + extra + '</span>' : '') + '</label>';
    const subs = m.subs.map((x, j) => '<li class="sub"><span class="pt-n">' + (j + 1) + '</span><div class="sub-fields">'
      + '<label class="sr" for="' + fieldId(i, 's' + j + '-text') + '">' + m.label + ' 세부 내용 ' + (j + 1) + '</label><textarea id="' + fieldId(i, 's' + j + '-text') + '" rows="3" data-m="' + i + '" data-s="' + j + '" data-f="text" placeholder="완전한 문장으로">' + esc(x.text) + '</textarea>'
      + '<div class="sub-range"><label class="sr" for="' + fieldId(i, 's' + j + '-range') + '">' + m.label + ' 세부 내용 ' + (j + 1) + ' 절 범위</label><input id="' + fieldId(i, 's' + j + '-range') + '" class="pt-range" data-m="' + i + '" data-s="' + j + '" data-f="range" value="' + esc(x.range) + '" placeholder="15:1-4"><span class="sub-ref" id="' + fieldId(i, 's' + j + '-ref') + '">' + subRefHtml(x.range) + '</span></div></div>'
      + '<div class="pt-tools"><button type="button" class="btn icon" data-sub-move="-1" data-m="' + i + '" data-s="' + j + '" aria-label="' + m.label + ' 세부 내용 ' + (j + 1) + ' 위로"' + (j === 0 ? ' disabled' : '') + '>↑</button><button type="button" class="btn icon" data-sub-move="1" data-m="' + i + '" data-s="' + j + '" aria-label="' + m.label + ' 세부 내용 ' + (j + 1) + ' 아래로"' + (j === m.subs.length - 1 ? ' disabled' : '') + '>↓</button><button type="button" class="btn icon" data-sub-del data-m="' + i + '" data-s="' + j + '" aria-label="' + m.label + ' 세부 내용 ' + (j + 1) + ' 지우기">×</button></div></li>').join('');
    const aps = m.applications ? '<p class="mv-k" id="' + fieldId(i, 'aps-h') + '">적용 <span class="note">' + APPS.min + '~' + APPS.max + '개, 이번 주에 해 볼 일</span></p><ol class="aps" aria-labelledby="' + fieldId(i, 'aps-h') + '">'
      + m.applications.map((a, k) => '<li class="ap"><label class="sr" for="' + fieldId(i, 'ap' + k) + '">적용 ' + (k + 1) + '</label><textarea id="' + fieldId(i, 'ap' + k) + '" rows="2" data-m="' + i + '" data-ap="' + k + '">' + esc(a) + '</textarea><button type="button" class="btn icon" data-ap-del="' + k + '" data-m="' + i + '" aria-label="적용 ' + (k + 1) + ' 지우기">×</button></li>').join('') + '</ol>'
      + '<button type="button" class="btn" data-ap-add="' + i + '"' + (m.applications.length >= APPS.max ? ' disabled' : '') + '>적용 더하기</button>' : '';
    return '<section class="mv ol-part editing" data-mv="' + m.key + '"><h4 class="mv-h" id="' + fieldId(i, 'h') + '" tabindex="-1">' + m.label + ' 고치기</h4>'
      + lab('heading', '제목 한 줄') + '<input id="' + fieldId(i, 'heading') + '" data-m="' + i + '" data-f="heading" value="' + esc(m.heading) + '">'
      + lab('serves', '한 문장 메시지와 이어지는 점') + '<textarea id="' + fieldId(i, 'serves') + '" rows="2" data-m="' + i + '" data-f="serves">' + esc(m.serves) + '</textarea>'
      + '<p class="mv-k" id="' + fieldId(i, 'subs-h') + '">세부 내용 <span class="note">' + SUBS.min + '~' + SUBS.max + '개, 절 주소와 함께</span></p><ol class="subs" aria-labelledby="' + fieldId(i, 'subs-h') + '">' + subs + '</ol>'
      + '<button type="button" class="btn" data-sub-add="' + i + '"' + (m.subs.length >= SUBS.max ? ' disabled' : '') + '>세부 내용 더하기</button>'
      + lab('cross', '함께 볼 본문', '있으면') + '<div class="sub-range"><input id="' + fieldId(i, 'cross') + '" data-m="' + i + '" data-f="cross" value="' + esc(m.cross) + '" placeholder="예: 갈라디아서 2:20"><span class="sub-ref" id="' + fieldId(i, 'cross-ref') + '">' + crossHtml(m.cross) + '</span></div>'
      + lab('background', '배경 메모', '확인한 뒤 쓰세요') + '<textarea id="' + fieldId(i, 'background') + '" rows="2" data-m="' + i + '" data-f="background">' + esc(m.background) + '</textarea>'
      + lab('idea', '예화 아이디어', '목사님 예화로 바꿔 주세요') + '<textarea id="' + fieldId(i, 'idea') + '" rows="2" data-m="' + i + '" data-f="idea">' + esc(m.idea) + '</textarea>'
      + aps + partButtons() + '</section>';
  }
  const partButtons = () => '<div class="actions part-done"><button type="button" class="btn primary" data-part-save>저장</button><button type="button" class="btn" data-part-cancel>취소</button></div>';
  function renderOutline() {
    const O = S.draft.outlines;
    const sec = $('#step-outline');
    sec.hidden = !O || screen() !== 'outline';
    if (sec.hidden) return;
    reviewNote('outline');
    // without AI the outline is written by hand: the four parts start empty, each filled by choosing it
    if (!shownOutline(O) && S.aiOff) O.edited = { ...blankOutline(), by: 'user' };
    const shown = shownOutline(O);
    $('#btn-outlines').hidden = !!shown || S.aiOff;
    $('#ol-view').hidden = !shown;
    if (!shown) return;
    const v = outlineOf(shown);
    const i = olEdit.part;
    $('#ol-migrated').hidden = !v.migrated;
    $('#ol-read').innerHTML = '<p class="ol-k">한 문장 메시지</p>'
      + (i === 'one' ? '<div class="mv ol-part editing"><label for="ol-one">한 문장 메시지 <span class="note">네 부분이 모두 이 한 문장을 향해요</span></label><textarea id="ol-one" rows="2" placeholder="이 설교가 전할 단 하나의 메시지">' + esc(v.message) + '</textarea>' + partButtons() + '</div>'
        : '<p class="ol-one">' + (v.message.trim() ? esc(v.message) : '<span class="note">아직 비어 있어요.</span>') + '</p>')
      + v.movements.map((m, k) => (i === k ? partForm(m, k) : partRead(m, k))).join('');
    $('#ol-ask').hidden = i !== null;
    $('#btn-ol-rewrite').hidden = S.aiOff;
    $$('[data-edit-part]').forEach((b) => b.setAttribute('aria-pressed', String(String(i) === b.dataset.editPart)));
    outlineGate();
  }
  function outlineGate() {
    const O = S.draft.outlines;
    const p = outlineProblems(BOOKS, S.draft.ref, shownOutline(O));
    $('#btn-ol-next').disabled = p.length > 0;
    $('#ol-problems').textContent = p[0] || '';
  }
  /** The outline being edited in the four-part shape: a shown suggestion or an older outline becomes the edited one. */
  function edited() {
    const O = S.draft.outlines;
    if (!O.edited) { const v = JSON.parse(JSON.stringify(outlineOf(shownOutline(O)))); delete v.migrated; O.edited = { ...v, by: 'ai', userEdited: false }; }
    const E = O.edited;
    if (!Array.isArray(E.movements)) { const v = outlineOf(E); E.message = v.message; E.movements = v.movements; }
    return E;
  }
  $('#ol-view').addEventListener('click', (e) => {
    const pick = e.target.closest('[data-edit-part]');
    if (pick) {
      const k = pick.dataset.editPart === 'one' ? 'one' : Number(pick.dataset.editPart);
      const E = edited();
      olEdit.part = k;
      olEdit.before = JSON.parse(JSON.stringify(k === 'one' ? E.message : E.movements[k]));
      renderOutline();
      const f = $(k === 'one' ? '#ol-one' : '#' + fieldId(k, 'heading'));
      if (f) { f.focus(); f.scrollIntoView({ block: 'center', behavior: reduceMotion() ? 'auto' : 'smooth' }); }
      return;
    }
    if (e.target.closest('[data-part-save], [data-part-cancel]')) {
      const k = olEdit.part;
      if (e.target.closest('[data-part-cancel]')) {
        const E = edited();
        if (k === 'one') E.message = olEdit.before; else E.movements[k] = olEdit.before;
        saveDraft(true);
      }
      olEdit.part = null;
      renderOutline();
      const h = $(k === 'one' ? '.ol-one' : '#ol-part-' + k + '-h');
      if (h) { h.setAttribute('tabindex', '-1'); h.focus(); }
      return;
    }
    const b = e.target.closest('[data-sub-add], [data-sub-move], [data-sub-del], [data-ap-add], [data-ap-del]');
    if (!b) return;
    const i = Number(b.dataset.m ?? b.dataset.subAdd ?? b.dataset.apAdd);
    const m = edited().movements[i];
    let focus = null;
    if (b.dataset.subAdd !== undefined) { m.subs.push({ text: '', range: '' }); focus = fieldId(i, 's' + (m.subs.length - 1) + '-text'); }
    else if (b.dataset.subMove !== undefined) {
      const j = Number(b.dataset.s), k = j + Number(b.dataset.subMove);
      [m.subs[j], m.subs[k]] = [m.subs[k], m.subs[j]];
      focus = fieldId(i, 's' + k + '-text');
    } else if (b.dataset.subDel !== undefined) { m.subs.splice(Number(b.dataset.s), 1); focus = m.subs.length ? fieldId(i, 's' + Math.min(Number(b.dataset.s), m.subs.length - 1) + '-text') : fieldId(i, 'heading'); }
    else if (b.dataset.apAdd !== undefined) { m.applications.push(''); focus = fieldId(i, 'ap' + (m.applications.length - 1)); }
    else { m.applications.splice(Number(b.dataset.apDel), 1); focus = fieldId(i, 'heading'); }
    touched(); renderOutline(); saveDraft(true);
    const f = document.getElementById(focus);
    if (f) f.focus();
  });
  const touched = () => { edited().userEdited = true; changed('outline'); };
  $('#ol-view').addEventListener('input', (e) => {
    const t = e.target;
    if (t.id === 'ol-one') edited().message = t.value;
    else if (t.dataset.ap !== undefined) edited().movements[Number(t.dataset.m)].applications[Number(t.dataset.ap)] = t.value;
    else if (t.dataset.s !== undefined) {
      edited().movements[Number(t.dataset.m)].subs[Number(t.dataset.s)][t.dataset.f] = t.value;
      if (t.dataset.f === 'range') $('#' + fieldId(t.dataset.m, 's' + t.dataset.s + '-ref')).innerHTML = subRefHtml(t.value);
    } else if (t.dataset.f) {
      edited().movements[Number(t.dataset.m)][t.dataset.f] = t.value;
      if (t.dataset.f === 'cross') $('#' + fieldId(t.dataset.m, 'cross-ref')).innerHTML = crossHtml(t.value);
    } else return;
    touched();
    outlineGate();
    saveDraft();
  });
  $('#btn-ol-next').addEventListener('click', () => {
    Object.assign(edited(), cleanOutline(S.draft.outlines.edited));
    clearReview(S.draft, 'outline');
    openNext('exegesis');
  });
  /** Go on to an in-page step: it is made the first time; with no work yet it simply follows what it is built from now. */
  function prepare(key) {
    const d = S.draft;
    if (key === 'setting') { if (!d.setting) d.setting = newSetting(d); return; }
    if (!d[key]) d[key] = { edited: null, basis: basisOf(d, key) };
    else if (!d[key].edited) d[key].basis = basisOf(d, key);
  }
  const openNext = (key) => { prepare(key); goStep(key); };

  // ---------------------------------------------------------------- 본문연구 · 예화 · 적용 · 원고 초안: the same pattern as 개요
  const wEdit = { key: null, part: null, before: null }; // the part open for editing and its copy for 취소
  // Korean particles after each step name (원고 초안 ends in a consonant): object, subject, '(으)로'
  const JOSA = { exegesis: ['를', '가', '로'], illustration: ['를', '가', '로'], application: ['을', '이', '으로'], manuscript: ['을', '이', '으로'] };
  async function writeWork(key) {
    const d = S.draft;
    // 본문연구 with the commentary tool (desktop app): the commentaries are read first and cited in the study
    if (key === 'exegesis') {
      if (S.host == null || S.host === 'checking') {
        // the tool's consent prompt may be waiting in the app: say so where the run will show
        exRun.steps = [{ key: 'probe', label: EX_DOING.probe, state: 'doing', note: '' }]; exRun.summary = ''; exRun.stageAt = Date.now();
        renderExRun();
        await (S.hostP || probeHost());
        if (!exRun.busy) { exRun.steps = null; renderExRun(); }
      }
      if (S.host === 'present' || S.host === 'warn') return writeStudy();
    }
    const ms = key === 'manuscript';
    if (ms) msRing('start', 'write');
    const v = await ask(promptWork(key, d, curStyle()), ms ? { onText: ({ text }) => msRing('text', text.length) } : {});
    if (v === undefined) { if (ms) msRing('fail'); return; }
    if (ms) msRing('tidy');
    const r = checkWork(key, BOOKS, d.ref, v, ms ? noteIdsOf(d) : undefined);
    const L = WORK[key].label;
    if (!r.value) { aiStatus(L + JOSA[key][1] + ' 정해진 모양에 맞지 않아 쓰지 않았어요. ' + WORK[key].write + '를 다시 눌러 주세요.'); if (ms) msRing('fail'); return; }
    ensureBasis(d);
    d[key] = { ...(d[key] || {}), edited: { ...r.value, by: 'ai', userEdited: false }, dropped: r.dropped };
    if (d[key].basis === undefined) d[key].basis = basisOf(d, key);
    wEdit.key = null;
    if (key === 'manuscript') { // written again for the 청중·분량 as it is now, with the requests waiting for it
      clearReview(d, 'manuscript'); renderSteps();
      if (pendingRequests(d).length) settleRequests(d, v && v.reply);
      delete d.manuscript.previous;
      delete d.manuscript.previousNotes;
      d.manuscript.notes = msNoteLinks(r.links); // the paragraphs built on the 본문연구's notes: its footnotes
      d.manuscript.inputs = msBasis(d, curStyle()); // what this 원고 초안 was written from
    }
    renderWork(key);
    if (ms) msRing('done');
    saveDraft(true);
    $('#w-' + key + '-h').focus();
    return true;
  }
  // 본문연구 with the commentaries (owner 2026-10-28): 서재 주석 고르기 -> 주석 쪽 읽기 -> 온라인 주석 읽기 -> one AI call
  // (the study and its 주석 메모, from the excerpts only) -> each memo's quote checked on its page by the tool. A stage
  // that finds nothing is passed with a note; the study is still written (from nothing read: as without the tool).
  const EX_STEPS = [['select', '서재 주석 고르기'], ['pages', '주석 쪽 읽기'], ['web', '온라인 주석 읽기'], ['write', '본문연구 쓰기'], ['verify', '인용 확인']];
  // the stage running shows a live line (owner 2026-10-28: running must look different from stuck): how long so far,
  // and for the AI call how much has come; a one-second tick moves it while the run or the tool's consent is pending
  const exRun = { busy: false, cancel: false, steps: null, summary: '', stageAt: 0, chars: 0, done: 0, total: 0, expected: 1, timer: 0 };
  function renderExRun() {
    $('#ex-run').hidden = !exRun.steps;
    $('#btn-ex-stop').hidden = !exRun.busy;
    $('#ex-summary').textContent = exRun.summary;
    const live = !!exRun.steps && exRun.steps.some((x) => x.state === 'doing');
    if (live && !exRun.timer) exRun.timer = setInterval(renderExRun, 1000);
    else if (!live && exRun.timer) { clearInterval(exRun.timer); exRun.timer = 0; }
    const ms = Date.now() - exRun.stageAt;
    if (exRun.steps) $('#ex-steps').innerHTML = exRun.steps.map((x) => '<li class="src-step st-' + x.state + '"><span class="src-mark" aria-hidden="true">' + ({ todo: '·', doing: '…', done: '✓', fail: '!' }[x.state]) + '</span> ' + esc(x.label) + '<span class="sr"> (' + ({ todo: '아직', doing: '하는 중', done: '마침', fail: '못 함' }[x.state]) + ')</span>'
      + (x.state === 'doing' ? ' <span class="note ex-live">' + esc(exLive(x.key, ms, exRun.chars)) + '</span>' : x.note ? ' <span class="note">' + esc(x.note) + '</span>' : '') + '</li>').join('');
  }
  function exStep(key, state, note) {
    const st = exRun.steps.find((x) => x.key === key); st.state = state; if (note !== undefined) st.note = note;
    if (state === 'doing') { exRun.stageAt = Date.now(); exRun.chars = 0; exRun.done = 0; exRun.total = 0; }
    renderExRun();
    if (S.aiRing) S.aiRing.tick();
  }
  /** The small ring's place: the stage running, by its count, time or streamed answer. */
  const exPct = () => { const st = exRun.steps?.find((x) => x.state === 'doing'); return st ? exRingPct({ stage: st.key, done: exRun.done, total: exRun.total, chars: exRun.chars, expected: exRun.expected, ms: Date.now() - exRun.stageAt }) : 1; };
  /** A tool call that does not answer in EX_HOST_MS is given up (its stage goes on with its note). */
  async function exHost(tool, input) {
    let t;
    try { return await Promise.race([hostCall(tool, input), new Promise((_, rej) => { t = setTimeout(() => rej(Object.assign(new Error('timeout'), { code: 'timeout' })), EX_HOST_MS); })]); }
    finally { clearTimeout(t); }
  }
  async function writeStudy() {
    const d = S.draft;
    if (exRun.busy) return;
    exRun.busy = true; exRun.cancel = false; exRun.summary = '';
    exRun.steps = EX_STEPS.map(([key, label]) => ({ key, label, state: 'todo', note: '' }));
    ringNow(exPct);
    const stop = (key, note) => { exStep(key, 'fail', note); exRun.busy = false; exRun.summary = note; renderExRun(); return undefined; };
    const STOPPED = '멈췄어요. 다시 누르면 처음부터 해요.';
    let at = 'select';
    try {
      exStep('select', 'doing');
      let books = [];
      try { books = pickBooks(await exHost('select', { passage: d.ref.label })); } catch (e) { /* passed with a note */ }
      if (exRun.cancel) return stop('select', STOPPED);
      exStep('select', 'done', books.length ? books.map((b) => (b.author ? b.author + ' ' : '') + b.title).join(' · ') : '이 본문을 다루는 서재 주석을 찾지 못했어요');
      at = 'pages'; exStep('pages', 'doing');
      exRun.total = books.length;
      const read = [];
      for (const b of books) {
        try { const r = await exHost('pages', { key: b.key, from: b.from, to: b.to }); if (r && Array.isArray(r.pages) && r.doctrine !== 'X') read.push({ ...b, doctrine: r.doctrine, author: r.author ?? b.author, title: r.title ?? b.title, pages: r.pages }); } catch (e) { /* this book is skipped */ }
        exRun.done++;
        if (exRun.cancel) return stop('pages', STOPPED);
      }
      const lib = budgetExcerpts(read);
      exStep('pages', 'done', lib.length ? lib.map((x) => x.title + ' ' + x.pages[0].page + (x.pages.length > 1 ? '-' + x.pages.at(-1).page : '') + '쪽').join(' · ') : '읽은 쪽이 없어요');
      at = 'web'; exStep('web', 'doing');
      let web = [], webNote;
      try { web = webExcerpts((await exHost('web-pages', { passage: d.ref.label }))?.pages); webNote = web.length ? web.map((x) => x.author).join(' · ') : '읽을 수 있는 온라인 주석이 없었어요'; }
      catch (e) { webNote = /unknown tool|not.?found|not.?allowed|not.?declared|not.?listed/i.test(String(e?.code ?? '') + ' ' + String(e?.message ?? '')) ? '온라인 주석은 주석 도구를 새로 시작하면 읽어요' : '온라인 주석을 읽지 못했어요'; }
      if (exRun.cancel) return stop('web', STOPPED);
      exStep('web', 'done', webNote);
      const excerpts = [...lib, ...web];
      at = 'write'; exRun.expected = aiExpected('exegesis', excerpts.length > 0); exStep('write', 'doing');
      const v = await ask(promptWork('exegesis', d, curStyle(), excerpts), { onText: ({ text }) => { exRun.chars = text.length; } });
      if (v === undefined) return stop('write', exRun.cancel ? STOPPED : '본문연구를 받지 못했어요. 다시 눌러 주세요.');
      const r = checkWork('exegesis', BOOKS, d.ref, v, excerpts.length ? excerpts : undefined);
      if (!r.value) return stop('write', '본문연구가 정해진 모양에 맞지 않아 쓰지 않았어요. ' + WORK.exegesis.write + '를 다시 눌러 주세요.');
      const proposed = workList('exegesis', r.value).flatMap((g) => g.notes || []);
      exStep('write', 'done', '묶음 ' + r.value.groups.length + '개' + (excerpts.length ? ' · 주석 메모 제안 ' + proposed.length + '개' : ''));
      at = 'verify'; exStep('verify', 'doing');
      exRun.total = workList('exegesis', r.value).flatMap((g) => g.notes || []).length;
      let unverified = 0;
      for (const g of r.value.groups) {
        if (!g.notes) continue;
        const kept = [];
        for (const n of g.notes) {
          try { const x = n.kind === 'web' ? await exHost('web-verify', { url: n.url, quote: n.quote }) : await exHost('verify', { key: n.key, page: n.page, quote: n.quote }); if (x && x.status === 'found' && x.doctrine === n.doctrine) kept.push({ ...n, status: 'found', ...(n.kind === 'web' && x.checkedAt ? { checkedAt: x.checkedAt } : {}) }); else unverified++; } catch (e) { unverified++; }
          exRun.done++;
          if (exRun.cancel) return stop('verify', STOPPED);
        }
        g.notes = kept;
      }
      const found = workList('exegesis', r.value).flatMap((g) => g.notes || []).length;
      exStep('verify', 'done', excerpts.length ? '확인된 인용 ' + found + '개' + (unverified ? ' · 그 쪽에서 찾지 못해 뺀 것 ' + unverified + '개' : '') : '읽은 주석이 없어 메모 없이 썼어요');
      ensureBasis(d);
      d.exegesis = { ...(d.exegesis || {}), edited: { ...r.value, by: 'ai', userEdited: false }, dropped: r.dropped,
        sources: { at: new Date().toISOString(), books: excerpts.map((x) => ({ key: x.key, author: x.author, title: x.title, doctrine: x.doctrine, ...(x.kind === 'web' ? { kind: 'web', url: x.url, checkedAt: x.checkedAt } : {}) })) } };
      if (d.exegesis.basis === undefined) d.exegesis.basis = basisOf(d, 'exegesis');
      exRun.busy = false;
      exRun.summary = found ? '본문연구를 썼어요. 주석 메모 ' + found + '개가 풀이 아래에 있어요.' : '본문연구를 썼어요.';
      wEdit.key = null;
      renderExRun();
      renderWork('exegesis');
      saveDraft(true);
      $('#w-exegesis-h').focus();
      return true;
    } catch (e) {
      return stop(at, '문제가 생겨 멈췄어요. 다시 눌러 주세요.');
    }
  }
  $('#btn-ex-stop').addEventListener('click', () => { exRun.cancel = true; if (S.aiBusy) S.aiBusy.abort(); });
  /** One 주석 메모 under its group's 풀이: the point, the source (as a footnote shows it), 인용 보기, 빼기. */
  function noteHtml(n) {
    return '<li class="ex-note"><span class="ex-note-point">' + esc(n.point) + '</span> ' + fnSource(n) + (DOC_LABEL[n.doctrine] ? ' <span class="fn-doc">' + DOC_LABEL[n.doctrine] + '</span>' : '')
      + ' <details class="fn-quote"><summary>인용 보기</summary><p>' + esc(n.quote) + '</p></details> <button type="button" class="linkbtn" data-note-remove="' + esc(n.id) + '" aria-label="주석 메모 빼기">빼기</button></li>';
  }
  // 원고 작성하기 ring (owner 2026-10-27): the streamed answer against the length asked for; a one-second tick moves
  // the elapsed line (text only). 생각하는 중 before the first text, 원고 받는 중 while it streams, 원고 정리 중 after.
  // 반영하기 and 바뀐 내용 반영하기 use it small, in their button row (kinds 'revise' and 'sync', expected = the 원고 as
  // it is now × MS_JSON_FACTOR).
  const msRun = { ring: null, t0: 0, timer: 0, why: '', kind: 'write', expected: 0 };
  const MS_STAGE = { think: '생각하는 중', stream: '원고 받는 중', tidy: '원고 정리 중' };
  function msRing(ev, received) {
    const r = msRun.ring;
    if (ev === 'start') {
      const inline = received !== 'write';
      msRun.kind = received; msRun.expected = inline ? Math.round(msLength(S.draft.manuscript.edited).chars * MS_JSON_FACTOR) : msExpected(S.draft);
      const box = $('#ms-progress');
      box.classList.toggle('ms-progress--inline', inline);
      if (inline) $({ sync: '#ms-sync .actions', revise: '#ms-req .actions' }[received]).appendChild(box);
      else $('#w-manuscript').parentNode.insertBefore(box, $('#w-manuscript'));
      msRun.ring = { pct: 0, stage: 'think', state: 'run' }; msRun.t0 = Date.now(); msRun.why = ''; clearInterval(msRun.timer); msRun.timer = setInterval(renderMsRing, 1000);
    }
    else if (!r || r.state !== 'run') return;
    else if (ev === 'text') msRun.ring = { ...r, pct: Math.max(r.pct, ringPctOf(received, msRun.expected)), stage: 'stream' };
    else if (ev === 'tidy') msRun.ring = { ...r, stage: 'tidy' };
    else { msRun.ring = { ...r, pct: ev === 'done' ? 100 : r.pct, state: ev }; clearInterval(msRun.timer); msRun.timer = 0; msRun.why = ev === 'fail' ? $('#ai-status').textContent : ''; }
    renderMsRing();
  }
  function renderMsRing() {
    const r = msRun.ring;
    $('#ms-progress').hidden = !r;
    $('#btn-ms-stop').hidden = !(r && r.state === 'run' && msRun.kind === 'write');
    $('#btn-req-stop').hidden = !(r && r.state === 'run' && msRun.kind === 'revise');
    $('#btn-sync-stop').hidden = !(r && r.state === 'run' && msRun.kind === 'sync');
    if (!r) return;
    const pct = Math.floor(r.pct);
    $('#ms-ring-bar').setAttribute('aria-valuenow', String(pct));
    $('#ms-ring-num').textContent = pct + '%';
    $('#ms-ring-fill').style.strokeDashoffset = String(100 - pct);
    $('#ms-ring').dataset.state = r.state;
    $('#ms-ring-stage').textContent = r.state === 'done' ? (msRun.kind === 'write' ? '원고를 다 썼어요' : '원고를 다 고쳤어요') : r.state === 'fail' ? '여기서 멈췄어요' : MS_STAGE[r.stage] + '…';
    $('#ms-ring-wait').textContent = r.state === 'run' ? elapsedKo(Date.now() - msRun.t0) : msRun.why;
  }
  $('#btn-ms-stop').addEventListener('click', () => { if (S.aiBusy) S.aiBusy.abort(); });
  $('#btn-req-stop').addEventListener('click', () => { if (S.aiBusy) S.aiBusy.abort(); });
  $('#btn-sync-stop').addEventListener('click', () => { if (S.aiBusy) S.aiBusy.abort(); });
  // ---------------------------------------------------------------- 이렇게 써 주세요 (REQ_LABEL, owner 2026-10-27)
  const reqSay = (t) => { $('#ms-req-status').textContent = t; };
  /** The box: above 원고 작성하기 without a 원고, under its parts with one; the log of requests and replies below it. */
  function renderReq(hasMs, editing) {
    const box = $('#ms-req');
    box.hidden = S.aiOff || editing;
    const home = hasMs ? $('#w-manuscript-ask') : $('#btn-w-manuscript').parentNode;
    if (box.nextSibling !== home) home.parentNode.insertBefore(box, home);
    $('#ms-req-hint').textContent = hasMs ? '바꾸고 싶은 내용이나 방향을 적고 ' + REQ_BUTTON + '를 누르시면 원고를 고쳐 드려요.' : '원고에 꼭 넣을 내용이나 방향을 적어 두시면 ' + WORK.manuscript.write + ' 때 반영해요.';
    $('#btn-ms-undo').hidden = !S.draft.manuscript?.previous;
    const list = requestsOf(S.draft);
    $('#ms-req-log').hidden = !list.length;
    $('#ms-req-log').innerHTML = list.map((x) => '<li class="req-me"><p class="bubble">' + para(x.text) + '</p></li>'
      + (x.reply == null ? '<li class="req-wait"><p class="note">' + WORK.manuscript.write + ' 때 반영해요.</p></li>' : '<li class="req-ai"><p class="bubble">이렇게 반영했어요: ' + esc(x.reply) + '</p></li>')).join('');
  }
  async function reviseMs() {
    const d = S.draft;
    const ta = $('#ms-req-text');
    const text = ta.value.trim();
    if (!text) { reqSay('반영할 내용을 적어 주세요.'); ta.focus(); return; }
    if (!d.manuscript?.edited) { // no 원고 yet: kept for 초안 작성하기
      pushRequest(d, text, null);
      ta.value = '';
      renderWork('manuscript');
      reqSay('적어 두었어요. ' + WORK.manuscript.write + '를 누르면 반영해서 써요.');
      saveDraft(true);
      return;
    }
    reqSay('');
    msRing('start', 'revise');
    const v = await ask(promptRevise(d, text, curStyle()), { onText: ({ text: t }) => msRing('text', t.length) });
    if (v === undefined) { msRing('fail'); return; }
    msRing('tidy');
    const r = reviseChecks(BOOKS, d.ref, v, noteIdsOf(d));
    if (!r.value) { aiStatus('고친 원고가 정해진 모양에 맞지 않아 쓰지 않았어요. ' + REQ_BUTTON + '를 다시 눌러 주세요.'); msRing('fail'); return; }
    ensureBasis(d);
    d.manuscript.previous = d.manuscript.edited; // one step back for 되돌리기
    d.manuscript.previousNotes = d.manuscript.notes || [];
    d.manuscript.edited = { ...r.value, by: 'ai', userEdited: false };
    d.manuscript.notes = msNoteLinks(r.links);
    d.manuscript.inputs = msBasis(d, curStyle());
    pushRequest(d, text, r.reply);
    ta.value = '';
    wEdit.key = null;
    renderSteps();
    renderWork('manuscript');
    msRing('done');
    saveDraft(true);
  }
  $('#btn-ms-req').addEventListener('click', reviseMs);
  $('#btn-ms-undo').addEventListener('click', () => {
    const W = S.draft.manuscript;
    if (!W?.previous) return;
    W.edited = W.previous;
    delete W.previous;
    if (W.previousNotes) { W.notes = W.previousNotes; delete W.previousNotes; }
    renderWork('manuscript');
    reqSay('고치기 전 원고로 되돌렸어요.');
    saveDraft(true);
  });
  // ---------------------------------------------------------------- 바뀐 내용 반영하기 (SYNC_BUTTON, owner 2026-10-27)
  /** The bar right above the parts: the earlier steps changed since the 원고 초안 was written (none, or an edit open: hidden). */
  function renderSync(editing) {
    const bar = $('#ms-sync');
    const notice = $('#w-manuscript-read .ms-notice');
    if (notice && bar.previousSibling !== notice) notice.after(bar);
    const changed = S.aiOff || editing ? [] : msChanged(S.draft, curStyle());
    if (msRun.kind === 'sync' && msRun.ring && msRun.ring.state === 'done') { msRun.ring = null; renderMsRing(); } // done: the bar goes, the result is said under 되돌리기
    const running = msRun.kind === 'sync' && !!msRun.ring;
    bar.hidden = !changed.length && !running;
    $('#ms-sync-text').textContent = changed.length ? '앞 단계가 바뀌었어요: ' + changed.map((x) => x.label).join(', ') : '';
  }
  /** The changed earlier steps (the bar), brought into the 원고 초안. */
  async function syncMs(changed, kind) {
    const d = S.draft;
    if (!d.manuscript?.edited || !changed.length) return;
    reqSay('');
    msRing('start', kind);
    const v = await ask(promptSync(d, changed, curStyle()), { onText: ({ text: t }) => msRing('text', t.length) });
    if (v === undefined) { msRing('fail'); return; }
    msRing('tidy');
    const r = reviseChecks(BOOKS, d.ref, v, noteIdsOf(d));
    if (!r.value) { aiStatus('고친 원고가 정해진 모양에 맞지 않아 쓰지 않았어요. ' + SYNC_BUTTON + '를 다시 눌러 주세요.'); msRing('fail'); return; }
    ensureBasis(d);
    d.manuscript.previous = d.manuscript.edited; // one step back for 되돌리기, as with 반영하기
    d.manuscript.previousNotes = d.manuscript.notes || [];
    d.manuscript.edited = { ...r.value, by: 'ai', userEdited: false };
    d.manuscript.notes = msNoteLinks(r.links);
    d.manuscript.inputs = msBasis(d, curStyle());
    clearReview(d, 'manuscript');
    wEdit.key = null;
    msRing('done');
    renderSteps();
    renderWork('manuscript');
    reqSay('앞 단계 변경을 반영했어요. ' + r.reply);
    saveDraft(true);
  }
  $('#btn-ms-sync').addEventListener('click', () => syncMs(msChanged(S.draft, curStyle()), 'sync'));
  const verseLink = (text) => { const r = rangeRef(text || ''); return r ? ' <a class="bref" href="' + esc(r.url) + '" target="_blank" rel="noopener">' + esc(r.label) + ' 읽기</a>' : (text || '').trim() ? ' <span class="note warn">이 본문에 없는 절이에요</span>' : ''; };
  const para = (t) => esc(t).replace(/\n/g, '<br>');
  /** A 근거 절 anywhere in the Bible (예화 · 적용): a 읽기 link, or a warning when it is not a real address. */
  const refLink = (text) => { const r = anyRef(BOOKS, S.draft.ref, text || ''); return r ? ' <a class="bref" href="' + esc(r.url) + '" target="_blank" rel="noopener">' + esc(r.label) + ' 읽기</a>' : (text || '').trim() ? ' <span class="note warn">성경 주소를 확인해 주세요</span>' : ''; };
  /** One part as reading text. */
  function workRead(key, x, i) {
    const id = 'w-' + key + '-part-' + i;
    const head = (label, title) => '<h4 id="' + id + '-h" tabindex="-1"><span class="mv-label">' + esc(label) + '</span>' + (title ? ' ' + esc(title) : '') + '</h4>';
    const empty = '<p class="note">아직 비어 있어요. 이 부분을 골라 채워 주세요.</p>';
    let body;
    if (key === 'exegesis') body = head(x.range || '묶음 ' + (i + 1), x.title) + (x.range ? '<p class="ol-extra">' + verseLink(x.range) + '</p>' : '') + (x.body.trim() ? '<p class="ol-flow">' + para(x.body) + '</p>' : empty)
      + (x.background.trim() ? '<p class="ol-extra"><span class="ol-k">배경 메모</span> ' + esc(x.background) + ' <span class="note">(확인한 뒤 쓰세요)</span></p>' : '')
      + (activeNotes(x).length ? '<div class="ex-notes"><p class="ol-k">주석 메모</p><ul>' + activeNotes(x).map(noteHtml).join('') + '</ul></div>' : '');
    else if (key === 'illustration') body = head(partLabel(x.part) || '예화', x.title) + '<p class="ol-extra"><span class="ill-kind">' + esc(ILL_KIND[illKind(x)]) + '</span>' + (String(x.range || '').trim() ? refLink(x.range) : '') + '</p>' + (illKind(x) === 'news' && x.source ? newsSource(x) : '')
      + (illBody(x).trim() ? '<p class="ol-flow">' + para(illBody(x)) + '</p>' : empty) + (String(x.bridge || '').trim() ? '<p class="ol-extra"><span class="ol-k">이어 주는 말</span> ' + esc(x.bridge) + '</p>' : '');
    else if (key === 'application') body = head(partLabel(x.part) || partLabel('conclusion'), '') + (String(x.text || '').trim() ? '<p class="ol-flow">' + para(x.text) + '</p>' : empty) + (String(x.range || '').trim() ? '<p class="ol-extra">' + refLink(x.range) + '</p>' : '');
    else {
      // the 원고's footnote numbers (from the 본문연구's notes and 출처 확인), as the 출처 확인 screen shows them
      const fns = footnotesOf(S.draft).filter((f) => f.section === i);
      const mark = (t, pi) => { const here = fns.filter((f) => f.paragraph === pi); return here.length ? placeNotes(t, here).map((piece) => esc(piece.text) + piece.notes.map((n) => '<sup class="fn"><a href="#wms-fn-' + n + '" id="wms-ref-' + n + '">' + n + '</a></sup>').join('')).join('') : para(t); };
      body = head(x.label, x.heading) + (x.paragraphs.some((t) => t.trim()) ? x.paragraphs.filter((t) => t.trim()).map((t, pi) => '<p class="ms-p">' + mark(t, pi) + '</p>').join('') : empty);
    }
    return '<section class="ol-part" id="' + id + '" aria-labelledby="' + id + '-h">' + body + '</section>';
  }
  const wf = (key, i, f) => 'w-' + key + '-' + i + '-' + f;
  /** The edit form for one part only (every field of it). */
  function workForm(key, x, i) {
    const name = WORK[key].name(x, i);
    const fields = WORK[key].fields.map((F) => {
      const id = wf(key, i, F.f);
      const lab = '<label for="' + id + '">' + F.label + (F.note ? ' <span class="note">' + F.note + '</span>' : '') + '</label>';
      const data = ' data-w="' + key + '" data-i="' + i + '" data-f="' + F.f + '"';
      if (F.type === 'part') return lab + '<select id="' + id + '"' + data + '>' + MOVES.map((m) => '<option value="' + m.key + '"' + (x.part === m.key ? ' selected' : '') + '>' + m.label + '</option>').join('') + '</select>';
      if (F.type === 'input') return lab + '<input id="' + id + '"' + data + ' value="' + esc(x[F.f]) + '">';
      if (F.type === 'range') return lab + '<div class="sub-range"><input id="' + id + '" class="pt-range"' + data + ' value="' + esc(x[F.f]) + '" placeholder="15:1-4"><span class="sub-ref" id="' + id + '-ref">' + verseLink(x[F.f]) + '</span></div>';
      if (F.type === 'ref') return lab + '<div class="sub-range"><input id="' + id + '" class="pt-ref"' + data + ' value="' + esc(x[F.f] || '') + '" placeholder="예: 사무엘상 17:45-47"><span class="sub-ref" id="' + id + '-ref">' + refLink(x[F.f]) + '</span></div>';
      if (F.type === 'kind') return lab + '<select id="' + id + '"' + data + '>' + Object.keys(ILL_KIND).map((k) => '<option value="' + k + '"' + (illKind(x) === k ? ' selected' : '') + '>' + ILL_KIND[k] + '</option>').join('') + '</select>';
      const val = F.type === 'paras' ? x[F.f].join('\n\n') : key === 'illustration' && F.f === 'body' ? illBody(x) : (x[F.f] ?? '');
      return lab + '<textarea id="' + id + '"' + data + ' rows="' + (F.type === 'paras' ? 14 : 4) + '">' + esc(val) + '</textarea>';
    }).join('');
    const src = key === 'illustration' && illKind(x) === 'news' && x.source ? newsSource(x) : ''; // the article stays as found (not edited here)
    return '<section class="mv ol-part editing"><h4 class="mv-h" id="' + wf(key, i, 'h') + '" tabindex="-1">' + esc(name) + ' 고치기</h4>' + src + fields
      + '<div class="actions part-done"><button type="button" class="btn primary" data-w-save>저장</button><button type="button" class="btn" data-w-cancel>취소</button>' + (WORK[key].add ? '<button type="button" class="linkbtn" data-w-remove>이 ' + esc(WORK[key].label) + ' 빼기</button>' : '') + '</div></section>';
  }
  const workShown = (key) => S.draft[key]?.edited || null;
  function renderWork(key) {
    const W = S.draft[key];
    const sec = $('#step-' + key);
    sec.hidden = !W || screen() !== key;
    if (sec.hidden) return;
    reviewNote(key);
    if (key === 'exegesis') { if (S.host == null) probeHost(); renderExRun(); }
    if (key === 'illustration') { if (S.host == null) probeHost(); $('#ill-news').hidden = !(S.host === 'present' || S.host === 'warn') || S.aiOff; }
    // an older draft did this step on the computer: its content is in the sermon page (작성하기 still redoes it here)
    const onComputer = doneOnComputer(S.draft, key) && !(W.edited && (W.edited.by === 'ai' || W.edited.userEdited));
    $('#w-' + key + '-mac').hidden = !onComputer;
    const pageUrl = artifactUrl(S.draft.mac?.pageUrl);
    $('#w-' + key + '-mac-page').innerHTML = onComputer && pageUrl ? '<a class="bref" href="' + esc(pageUrl) + '" target="_blank" rel="noopener">설교 페이지 열기</a>' : '';
    if (key === 'manuscript') {
      const st = S.draft.setting;
      $('#ms-setting-text').textContent = (st ? '청중·분량: ' + settingLine(st) : '청중·분량을 정하지 않아 ' + MS_MINUTES + '분 기준으로 써요.') + (curStyle() ? ' · ' + STYLE_NAME + ' 따름' : '');
      $('#btn-ms-setting').textContent = st ? '바꾸기' : '정하기';
      $('#btn-ms-setting').setAttribute('aria-label', '청중·분량 ' + (st ? '바꾸기' : '정하기'));
      renderMsRing();
    }
    // without AI the step is written by hand: its parts start empty, each filled by choosing it
    if (!W.edited && S.aiOff) W.edited = { ...blankWork(key), by: 'user', userEdited: false };
    const v = workShown(key);
    $('#btn-w-' + key).hidden = !!v || S.aiOff;
    if (WORK[key].add) { $('#btn-w-' + key + '-manual').hidden = !!v; $('#btn-w-' + key + '-skip').hidden = !!v; }
    $('#w-' + key).hidden = !v;
    const open = v && wEdit.key === key ? wEdit.part : null;
    if (key === 'manuscript') { renderReq(!!v, open !== null); $('#ms-ill-note').hidden = !!v || illustrationsOf(S.draft).length > 0 || applicationsOf(S.draft).length > 0; }
    if (!v) return;
    const list = workList(key, v);
    let top = '';
    if (key === 'manuscript') {
      const msg = outlineOf(S.draft.outlines?.edited).message.trim();
      const len = msLength(v);
      top = (msg ? '<p class="ol-k">한 문장 메시지</p><p class="ol-one">' + esc(msg) + '</p>' : '') + (len.chars ? '<p class="note ms-len">원고 약 ' + len.chars.toLocaleString('en-US') + '자 · ' + len.minutes + '분 안팎</p>' : '')
        + '<p class="note ms-notice">' + esc(MS_NOTICE) + '</p>'; // the owner's notice again, right above the parts
    }
    if (key === 'manuscript') $('#w-manuscript').before($('#ms-sync')); // out of the parts before they are drawn again (it holds the ring while it runs)
    $('#w-' + key + '-read').innerHTML = top + list.map((x, i) => (open === i ? workForm(key, x, i) : workRead(key, x, i))).join('');
    if (key === 'manuscript') {
      renderSync(open !== null);
      const fns = footnotesOf(S.draft);
      $('#w-ms-fns-box').hidden = !fns.length;
      $('#w-ms-fns').innerHTML = fns.map((f) => fnItem(f, 'wms', false)).join('');
    }
    $('#w-' + key + '-parts').innerHTML = list.map((x, i) => '<button type="button" class="btn" data-w-part="' + i + '" aria-pressed="' + (open === i) + '">' + esc(WORK[key].name(x, i)) + '</button>').join('');
    $('#w-' + key + '-ask').hidden = open !== null;
    $('#btn-w-' + key + '-rewrite').hidden = S.aiOff;
    workGate(key);
  }
  function workGate(key) {
    const p = workProblems(key, BOOKS, S.draft.ref, workShown(key));
    $('#btn-w-' + key + '-next').disabled = p.length > 0;
    $('#w-' + key + '-problems').textContent = p[0] || '';
  }
  for (const key of WORK_KEYS) {
    // the small ring beside the button (the 원고 초안 has its own large ring)
    const run = (btn) => (key === 'manuscript' ? writeWork(key) : withRing(btn, key, () => writeWork(key)));
    $('#btn-w-' + key).addEventListener('click', (e) => run(e.currentTarget));
    $('#btn-w-' + key + '-rewrite').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      const E = S.draft[key]?.edited;
      const L = WORK[key].label;
      const [o, j, ro] = JOSA[key];
      const msg = E && E.userEdited ? '고치신 내용이 있어요. 다시 작성하면 지금 ' + L + j + ' 새 ' + L + ro + ' 바뀌어요. 다시 작성할까요?' : '지금 ' + L + o + ' 새로 작성한 ' + L + ro + ' 바꿀까요?';
      if (await askUser({ title: msg, ok: WORK[key].rewrite })) run(btn);
    });
    $('#btn-w-' + key + '-next').addEventListener('click', () => {
      const W = S.draft[key];
      W.edited = { ...cleanWork(key, W.edited), by: W.edited.by, userEdited: W.edited.userEdited };
      clearReview(S.draft, key);
      if (key === 'manuscript') { S.draft.status = 'Mac 준비 대기'; goStep('sources'); return; } // on to 10 출처 확인 (optional)
      openNext({ exegesis: 'setting', illustration: 'application', application: 'manuscript' }[key]);
    });
    if (WORK[key].add) {
      // 예화 · 적용 by hand: start with one empty item, add more, or go on without any (they are encouraged, not required)
      $('#btn-w-' + key + '-manual').addEventListener('click', () => {
        S.draft[key].edited = { ...blankWork(key), by: 'user', userEdited: true };
        wEdit.key = key; wEdit.part = 0; wEdit.before = JSON.parse(JSON.stringify(workList(key, S.draft[key].edited)[0]));
        renderWork(key); saveDraft(true);
        const f = $('#w-' + key + '-read select, #w-' + key + '-read input, #w-' + key + '-read textarea');
        if (f) f.focus();
      });
      $('#btn-w-' + key + '-skip').addEventListener('click', () => { clearReview(S.draft, key); openNext({ illustration: 'application', application: 'manuscript' }[key]); });
      $('#btn-w-' + key + '-add').addEventListener('click', () => {
        const W = S.draft[key];
        const list = workList(key, W.edited);
        list.push(blankItem(key));
        W.edited.userEdited = true;
        wEdit.key = key; wEdit.part = list.length - 1; wEdit.before = null;
        renderWork(key); saveDraft(true);
        const f = $('#w-' + key + '-read select, #w-' + key + '-read input, #w-' + key + '-read textarea');
        if (f) f.focus();
      });
    }
    $('#w-' + key).addEventListener('click', (e) => {
      const pick = e.target.closest('[data-w-part]');
      if (pick) {
        const i = Number(pick.dataset.wPart);
        wEdit.key = key; wEdit.part = i; wEdit.before = JSON.parse(JSON.stringify(workList(key, S.draft[key].edited)[i]));
        renderWork(key);
        const f = $('#w-' + key + '-read input, #w-' + key + '-read textarea, #w-' + key + '-read select');
        if (f) { f.focus(); f.scrollIntoView({ block: 'center', behavior: reduceMotion() ? 'auto' : 'smooth' }); }
        return;
      }
      const nr = e.target.closest('[data-note-remove]');
      if (nr) {
        // a 주석 메모 taken out by hand: kept in the data (removed), its 원고 footnotes go with it
        for (const g of workList(key, S.draft[key].edited)) for (const n of g.notes || []) if (n.id === nr.dataset.noteRemove) n.removed = true;
        S.draft[key].edited.userEdited = true;
        renderWork(key); saveDraft(true);
        $('#w-' + key + '-h').focus();
        return;
      }
      const rm = e.target.closest('[data-w-remove]');
      if (rm) {
        const list = workList(key, S.draft[key].edited);
        list.splice(wEdit.part, 1);
        S.draft[key].edited.userEdited = true;
        wEdit.key = null; wEdit.part = null;
        renderWork(key); saveDraft(true);
        $('#w-' + key + '-h').focus();
        return;
      }
      const done = e.target.closest('[data-w-save], [data-w-cancel]');
      if (done) {
        const i = wEdit.part;
        if (done.dataset.wCancel !== undefined) { const list = workList(key, S.draft[key].edited); if (wEdit.before) list[i] = wEdit.before; else list.splice(i, 1); saveDraft(true); } // 취소 on a new item takes it out again
        wEdit.key = null; wEdit.part = null;
        renderWork(key);
        const h = $('#w-' + key + '-part-' + i + '-h');
        if (h) h.focus();
      }
    });
    const onEdit = (e) => {
      const t = e.target;
      if (t.dataset.w !== key) return;
      ensureBasis(S.draft);
      const x = workList(key, S.draft[key].edited)[Number(t.dataset.i)];
      x[t.dataset.f] = t.dataset.f === 'paragraphs' ? t.value.split(/\n\s*\n/).map((p) => p.trim()) : t.value;
      if (t.classList.contains('pt-range')) $('#' + t.id + '-ref').innerHTML = verseLink(t.value);
      if (t.classList.contains('pt-ref')) $('#' + t.id + '-ref').innerHTML = refLink(t.value);
      S.draft[key].edited.userEdited = true;
      if (S.draft[key].previous) { delete S.draft[key].previous; $('#btn-ms-undo').hidden = true; } // 되돌리기 is for the last change only
      workGate(key);
      saveDraft();
    };
    $('#w-' + key).addEventListener('input', onEdit);
    $('#w-' + key).addEventListener('change', onEdit);
  }

  // ---------------------------------------------------------------- 6 청중·분량: who hears it and how long (no AI here)
  // 예배 · 장소·대상 · 분류 offer the 지난 설교 values (renamed there, renamed here), so the choice lands in that list as is
  const SET_PICKS = ['service', 'place', 'category'];
  /** A picker of one criterion: its values, '직접 입력' when the criterion has it, 미분류 for 분류; a value no longer
   * among them (renamed or typed) stays selectable. */
  function pickHtml(key, value) {
    const c = C(key);
    const vals = [...c.options, ...(key === 'category' ? [NONE] : [])];
    const typed = filled(value) && !vals.includes(value);
    const other = c.options.includes(OTHER);
    const opt = (v, label, on) => '<option value="' + esc(v) + '"' + (on ? ' selected' : '') + '>' + esc(label) + '</option>';
    return opt('', c.name + ' 고르기', !filled(value)) + vals.map((v) => opt(v, v, v === value || (typed && other && v === OTHER))).join('') + (typed && !other ? opt(value, value, true) : '');
  }
  function renderSetting() {
    const sec = $('#step-setting');
    const st = S.draft.setting;
    sec.hidden = !st || screen() !== 'setting';
    if (sec.hidden) return;
    if (sec.contains(document.activeElement) && document.activeElement.matches('input, textarea')) return; // not under the cursor
    for (const k of SET_PICKS) {
      $('#set-' + k + '-name').textContent = C(k).name;
      $('#set-' + k).innerHTML = pickHtml(k, st[k]);
      const typed = filled(st[k]) && C(k).options.includes(OTHER) && !C(k).options.includes(st[k]);
      $('#set-' + k + '-other-row').hidden = !(typed || $('#set-' + k).value === OTHER);
      $('#set-' + k + '-other').value = typed ? st[k] : '';
    }
    $('#set-audience').value = st.audience || '';
    $('#set-minutes').value = st.minutes || '';
    $('#set-chars').value = st.chars || '';
    setLenNote();
  }
  const setLenNote = () => { const st = S.draft.setting; $('#set-len-note').textContent = st.chars > 0 ? '약 ' + st.chars.toLocaleString('en-US') + '자, 공백 빼고 · ' + st.minutes + '분 안팎' : '설교 시간을 적어 주세요.'; $('#btn-set-next').disabled = !(st.minutes > 0); };
  function settingChanged() {
    const d = S.draft;
    d.setting.by = 'user';
    markLater(d, 'setting'); // the 원고 초안 was written for the length and hearers before
    renderSteps();
    saveDraft();
  }
  $('#step-setting').addEventListener('change', (e) => {
    const k = e.target.dataset.set;
    if (!k || !SET_PICKS.includes(k)) return;
    const row = $('#set-' + k + '-other-row');
    row.hidden = e.target.value !== OTHER;
    S.draft.setting[k] = e.target.value === OTHER ? $('#set-' + k + '-other').value.trim() : e.target.value;
    settingChanged();
    if (!row.hidden) $('#set-' + k + '-other').focus();
  });
  $('#step-setting').addEventListener('input', (e) => {
    const t = e.target, st = S.draft.setting;
    if (t.dataset.setOther) st[t.dataset.setOther] = t.value.trim();
    else if (t.id === 'set-audience') st.audience = t.value;
    else if (t.id === 'set-minutes' || t.id === 'set-chars') {
      const len = lengthOf(t.id === 'set-minutes' ? { minutes: t.value } : { chars: t.value });
      st.minutes = len.minutes; st.chars = len.chars;
      $(t.id === 'set-minutes' ? '#set-chars' : '#set-minutes').value = t.id === 'set-minutes' ? len.chars : len.minutes;
      setLenNote();
    } else return;
    settingChanged();
  });
  $('#btn-set-next').addEventListener('click', () => openNext('illustration'));
  $('#btn-ms-setting').addEventListener('click', () => openNext('setting'));

  // ---------------------------------------------------------------- 10 출처 확인 (optional)
  // In the Claude desktop app with the commentary tool connected (host:sermon-sources) the check runs here, on a press;
  // anywhere else the sentence for Claude Code on the computer is the fallback. mac.sources is written only by the skills.
  const WORK_WORD = { todo: '아직 하지 않았어요', working: '확인하는 중이에요', done: '확인을 마쳤어요' };
  const SRC_STEPS = [['select', '이 본문을 다루는 주석 고르기'], ['pages', '고른 주석의 쪽 읽기'], ['web', '온라인 주석 읽기'], ['propose', '각주 제안 받기'], ['verify', '인용이 그 쪽에 그대로 있는지 확인하기'], ['search', '웹에서 찾기']];
  const srcRun = { busy: false, cancel: false, steps: null, summary: '', ring: null, timer: 0, ev: null, stageAt: 0, chars: 0 };
  const SRC_STOPPED = '멈췄어요. 다시 누르면 처음부터 확인해요.';
  function probeHost() { return (S.hostP = probeOnce()); }
  async function probeOnce() {
    S.host = 'checking';
    const mcp = await use('mcp');
    if (!mcp) { S.host = 'absent'; renderHostState(); renderSources(); return; }
    S.mcp = mcp;
    try { noteHostInfo((await mcp.callTool(HOST, 'status', {}, { cache: false }))?.payload); S.host = 'present'; }
    catch (e) { S.host = e && e.code === 'tool_error' ? 'warn' : 'absent'; if (S.host === 'warn') noteHostInfo(toolErrorPayload(e)); } // tool_error: the tool answered, its own check found something
    renderHostState();
    renderSources();
    renderWork('illustration'); // 시사 예화 찾기 shows once the tool answers
  }
  const hostCall = async (tool, input) => (await S.mcp.callTool(HOST, tool, input, { cache: false })).payload;
  /** The tool says where it reads the search keys (내 자료 연결하기 and the 검색 키 notes) and, in status, which commentary
   * folders are connected (내 자료 연결하기). */
  function noteHostInfo(payload) {
    const libs = librariesOf(payload);
    if (libs) renderLibraries(libs);
    const f = keysFileOf(payload);
    if (!f) return;
    S.keysFile = f;
    const el = $('#guide-keys-file');
    el.textContent = keysFileLine(f);
    el.hidden = false;
  }
  /** 내 자료 연결하기: whether this view reached the tool (shown once the probe is over). */
  function renderHostState() {
    const el = $('#guide-host-state');
    if (S.host === 'checking' || S.host == null) { el.hidden = true; return; }
    el.textContent = S.host === 'absent' ? HOST_MISSING : HOST_FOUND;
    el.hidden = false;
  }
  /** A folder path that breaks only after a / or \\ (long names may still wrap inside). */
  function pathNode(p) {
    const span = document.createElement('span');
    span.className = 'path';
    for (const part of p.match(/[^\\/]*[\\/]?/g).filter(Boolean)) {
      if (span.childNodes.length) span.appendChild(document.createElement('wbr'));
      const c = document.createElement('span');
      if (part.length > 24) c.className = 'long';
      c.textContent = part;
      span.appendChild(c);
    }
    return span;
  }
  function renderLibraries(libs) {
    const box = $('#guide-libraries');
    box.replaceChildren(...(libs.length ? libs.map((l) => {
      const p = document.createElement('p');
      p.append(l.exists ? LIBRARY_LEAD : '', pathNode(l.path), libraryTail(l));
      return p;
    }) : [Object.assign(document.createElement('p'), { textContent: LIBRARIES_NONE })]));
    box.hidden = false;
  }
  function setSrcStep(key, state, note) {
    const st = srcRun.steps.find((x) => x.key === key);
    st.state = state; if (note !== undefined) st.note = note;
    if (state === 'doing') srcRun.at = key;
    renderSources();
  }
  // the ring: weighted, never back; select and the AI call ease by time (the AI call also follows a streamed answer);
  // a one-second tick moves them and the elapsed line under the ring (text only, so reduced motion still gets it)
  function moveRing(ev) {
    if (ev.stage && ev.stage !== srcRun.ring.stage) srcRun.stageAt = Date.now();
    srcRun.ring = ringNext(srcRun.ring, ev);
    if (ev.stage) srcRun.ev = ev;
    if (srcRun.ring.state !== 'run') { clearInterval(srcRun.timer); srcRun.timer = 0; }
    renderRing();
  }
  function tickRing() {
    const r = srcRun.ring;
    if (!r || r.state !== 'run') return;
    if (RING_TAU_MS[r.stage]) moveRing({ stage: r.stage, chars: srcRun.chars, ms: Date.now() - srcRun.stageAt });
    else renderRing();
  }
  function renderRing() {
    const r = srcRun.ring;
    $('#src-ring').hidden = !r;
    $('#src-ring-wait').hidden = !r;
    if (!r) return;
    const pct = Math.floor(r.pct);
    $('#src-ring-bar').setAttribute('aria-valuenow', String(pct));
    $('#src-ring-num').textContent = pct + '%';
    $('#src-ring-fill').style.strokeDashoffset = String(100 - pct);
    $('#src-ring').dataset.state = r.state;
    const label = (SRC_STEPS.find(([k]) => k === r.stage) || [, ''])[1];
    const ev = srcRun.ev;
    const count = ev && ev.stage === r.stage && ev.total ? ' (' + ev.done + '/' + ev.total + ')' : '';
    $('#src-ring-stage').textContent = r.state === 'done' ? '다 마쳤어요' : r.state === 'fail' ? '여기서 멈췄어요: ' + label : label.replace(/기$/, '는 중…') + count;
    $('#src-ring-wait').textContent = r.state === 'run' ? ringWait(r.stage, Date.now() - srcRun.stageAt) : '';
  }
  async function runSourceCheck() {
    const d = S.draft;
    if (srcRun.busy) return;
    if (!hasManuscript(d)) { renderSources(); return; } // footnotes only for a manuscript written in the page
    if (d.sourceCheck?.footnotes?.length && !(await askUser({ title: '각주를 다시 확인할까요?', text: '다시 확인하면 지금 각주가 새로 확인한 각주로 바뀌어요.', ok: '다시 확인하기' }))) return;
    srcRun.busy = true;
    // diag: times and outcome of this run, no text (kept with the draft, for tuning)
    const diag = { at: new Date().toISOString(), selectMs: null, aiMs: null, onTextCalls: 0, firstTextMs: null, outcome: null, consentPress: null, consent: null };
    srcRun.steps = SRC_STEPS.map(([key, label]) => ({ key, label, state: 'todo', note: '' }));
    srcRun.summary = '';
    srcRun.ring = ringStart();
    srcRun.cancel = false;
    srcRun.perm = false;
    srcRun.chars = 0;
    srcRun.at = null;
    srcRun.stageAt = Date.now();
    clearInterval(srcRun.timer);
    srcRun.timer = setInterval(tickRing, 1000);
    const stop = (key, note, outcome) => {
      clearInterval(srcRun.timer); srcRun.timer = 0;
      moveRing({ end: 'fail' }); setSrcStep(key, 'fail', note); srcRun.busy = false;
      diag.outcome = srcRun.cancel ? 'stopped' : outcome;
      d.sourceCheck = { ...(d.sourceCheck || {}), diag };
      saveDraft(true);
      renderSources();
    };
    // any exception in the run stops it where it is (an old draft once threw here and left the ring spinning)
    try {
      // 0 the AI grant first, on this press, so its dialog shows now and not unseen minutes later
      renderSources();
      // (bounded and never blocking: no answer from the permissions capability goes straight on; the call asks itself)
      srcRun.ctl = new AbortController();
      try { diag.consentPress = (await aiPath({ use, signal: srcRun.ctl.signal })).consent; } catch (e) {
        diag.consentPress = e.consent ?? null;
        if (e.code === 'cancelled') return stop('select', SRC_STOPPED, 'stopped');
        if (e.code === 'unavailable') { setAiOff(); return stop('select', '이 화면에서는 AI를 쓸 수 없어서 출처 확인을 할 수 없어요.', 'ai-unavailable'); }
        return stop('select', 'AI를 불러오지 못했어요. 잠시 뒤 다시 눌러 주세요.', 'ai-' + e.code);
      }
      srcRun.stageAt = Date.now(); // the dialog's time is not the tool's
      // 1 books for the passage (the tool picks them from the catalog: located, never X)
      setSrcStep('select', 'doing');
      moveRing({ stage: 'select' });
      let books;
      // the first select of a passage can outrun the app's reply time while the files are fetched: once more (now cached)
      const select = () => (srcRun.cancel ? Promise.reject(new Error('stopped')) : hostCall('select', { passage: d.ref.label }));
      const t0 = Date.now();
      try { books = pickBooks(await retryOnce(select, SELECT_RETRY, () => setSrcStep('select', 'doing', '주석 파일을 받는 중이라 한 번 더 시도해요'))); } catch (e) { diag.selectMs = Date.now() - t0; return stop('select', srcRun.cancel ? SRC_STOPPED : '주석 도구가 답하지 않았어요. 잠시 뒤 다시 눌러 주세요.', 'select-' + (e?.code || 'failed')); }
      diag.selectMs = Date.now() - t0;
      if (srcRun.cancel) return stop('select', SRC_STOPPED);
      // no book in the library for this passage: the online stages still run (a web-only check)
      setSrcStep('select', 'done', books.length ? books.map((b) => (b.author ? b.author + ' ' : '') + b.title).join(' · ') : '서재에서 이 본문을 다루는 주석을 찾지 못했어요');
      // 2 a few located pages of each (a book that fails is skipped)
      setSrcStep('pages', 'doing');
      moveRing({ stage: 'pages', done: 0, total: books.length });
      const read = [];
      for (const [i, b] of books.entries()) {
        try { const r = await hostCall('pages', { key: b.key, from: b.from, to: b.to }); if (r && Array.isArray(r.pages) && r.doctrine !== 'X') read.push({ ...b, doctrine: r.doctrine, author: r.author ?? b.author, title: r.title ?? b.title, pages: r.pages }); } catch (e) { /* this book is skipped */ }
        moveRing({ stage: 'pages', done: i + 1, total: books.length });
        if (srcRun.cancel) return stop('pages', SRC_STOPPED);
      }
      const excerpts = budgetExcerpts(read);
      setSrcStep('pages', 'done', excerpts.length ? excerpts.map((x) => x.title + ' ' + x.pages[0].page + (x.pages.length > 1 ? '-' + x.pages.at(-1).page : '') + '쪽').join(' · ') : '읽은 서재 주석 쪽이 없어요');
      // 2-1 the listed online commentaries, read on the owner's computer (an older tool without web-pages: skipped)
      setSrcStep('web', 'doing');
      moveRing({ stage: 'web', done: 0, total: 1 });
      let web = [], webNote;
      try { web = webExcerpts((await hostCall('web-pages', { passage: d.ref.label }))?.pages); webNote = web.length ? web.map((x) => x.author).join(' · ') : '읽을 수 있는 온라인 주석이 없었어요'; }
      catch (e) { webNote = /unknown tool|not.?found|not.?allowed|not.?declared|not.?listed/i.test(String(e?.code ?? '') + ' ' + String(e?.message ?? '')) ? '온라인 주석은 주석 도구를 새로 시작하면 읽어요' : '온라인 주석을 읽지 못했어요'; }
      diag.web = web.length;
      moveRing({ stage: 'web', done: 1, total: 1 });
      if (srcRun.cancel) return stop('web', SRC_STOPPED);
      setSrcStep('web', 'done', webNote);
      const news = newsExcerpts(d); // the 시사 예화 whose quote was found in the article
      const sources = [...excerpts, ...web, ...news];
      // 3 one AI call: footnote proposals from these excerpts only
      setSrcStep('propose', 'doing');
      moveRing({ stage: 'propose' });
      // whether onText streams in this app or fires once at the end goes into diag
      const onText = ({ text }) => {
        const ms = Date.now() - srcRun.stageAt;
        if (!diag.onTextCalls++) diag.firstTextMs = ms;
        srcRun.chars = text.length;
        moveRing({ stage: 'propose', chars: srcRun.chars, ms });
      };
      const v = await ask(promptFootnotes({ passage: d.ref.label, manuscript: d.manuscript.edited, excerpts: sources }), { onText, limitMs: AI_LIMIT_MS.propose });
      diag.aiMs = Date.now() - srcRun.stageAt;
      diag.consent = S.aiConsent ?? null; // the call's path: use, state, request outcomes and ms, and where it stopped
      if (S.aiFail === 'not_granted') srcRun.perm = true;
      if (v === undefined) return stop('propose', srcRun.cancel ? SRC_STOPPED : S.aiFail === 'timeout' ? 'AI 답이 5분 넘게 오지 않아 멈췄어요. 잠시 뒤 다시 눌러 주세요.' : S.aiFail === 'not_granted' ? GRANT_NOTE : S.aiFail === 'use_timeout' ? 'AI를 불러오지 못했어요. 잠시 뒤 다시 눌러 주세요.' : '각주 제안을 받지 못했어요. 다시 눌러 주세요.', 'ai-' + (S.aiFail || 'failed'));
      const c = checkFootnotes(v, { manuscript: d.manuscript.edited, excerpts: sources });
      setSrcStep('propose', 'done', '제안 ' + c.items.length + '개' + (c.dropped.doctrine ? ' · 교리 기준에 맞지 않아 뺀 것 ' + c.dropped.doctrine + '개' : ''));
      // 4 every quote checked on its page by the tool; only found ones stay
      setSrcStep('verify', 'doing');
      moveRing({ stage: 'verify', done: 0, total: c.items.length });
      const kept = [];
      let unverified = 0;
      for (const [i, f] of c.items.entries()) {
        // a 시사 예화's own quote was already found in its article (when it was made)
        const known = news.find((x) => x.key === f.key && x.quote === f.quote);
        if (known) { kept.push({ ...f, status: 'found', checkedAt: known.checkedAt }); moveRing({ stage: 'verify', done: i + 1, total: c.items.length }); continue; }
        try { const r = isWeb(f) ? await hostCall('web-verify', { url: f.url, quote: f.quote }) : await hostCall('verify', { key: f.key, page: f.page, quote: f.quote }); if (r && r.status === 'found' && r.doctrine === f.doctrine) kept.push({ ...f, status: 'found', ...(isWeb(f) && r.checkedAt ? { checkedAt: r.checkedAt } : {}) }); else unverified++; } catch (e) { unverified++; }
        moveRing({ stage: 'verify', done: i + 1, total: c.items.length });
        if (srcRun.cancel) return stop('verify', SRC_STOPPED);
      }
      // sentences written as fact: supported only through a footnote the tool found; the rest are listed, never rewritten
      const claims = checkClaims(v, { manuscript: d.manuscript.edited, excerpts: sources, footnotes: [...kept, ...noteFootnotes(d)] }).items.map((x, i) => ({ id: 'c' + (i + 1), ...x }));
      const firstOpen = claims.filter((x) => x.status === 'unsupported').length;
      setSrcStep('verify', 'done', '확인된 인용 ' + kept.length + '개' + (unverified ? ' · 그 쪽에서 찾지 못해 뺀 것 ' + unverified + '개' : '') + (firstOpen ? ' · 확인이 필요한 문장 ' + firstOpen + '개' : ''));
      // 5 웹에서 찾기: the claims still without support are searched on the web and checked on the pages read
      setSrcStep('search', 'doing');
      moveRing({ stage: 'search', done: 0, total: 1 });
      let searchNote = '확인이 필요한 문장이 없어요';
      if (firstOpen) {
        const r = await writeSearch(d, claims.filter((x) => x.status === 'unsupported').slice(0, SEARCH_CLAIMS));
        if (srcRun.cancel) return stop('search', SRC_STOPPED);
        searchNote = r.note;
        kept.push(...r.kept);
        sources.push(...r.sources);
        const all = [...kept, ...noteFootnotes(d)];
        for (const x of claims) if (x.status === 'unsupported' && all.some((f) => f.section === x.section && f.paragraph === x.paragraph && (!f.anchor || f.anchor === x.anchor))) x.status = 'supported';
      }
      moveRing({ stage: 'search', done: 1, total: 1 });
      setSrcStep('search', 'done', searchNote);
      const open = claims.filter((x) => x.status === 'unsupported').length;
      const needs = open ? ' · 확인이 필요한 문장 ' + open + '개' : '';
      d.sourceCheck = { at: new Date().toISOString(), passage: d.ref.label, books: sources.map((x) => ({ key: x.key, author: x.author, title: x.title, doctrine: x.doctrine, ...(x.kind === 'web' ? { kind: 'web', url: x.url, checkedAt: x.checkedAt } : {}) })), footnotes: kept.map((f, i) => ({ id: 'f' + (i + 1), ...f })), claims, dropped: { shape: c.dropped.shape, doctrine: c.dropped.doctrine, unverified }, diag: { ...diag, outcome: 'ok' } };
      srcRun.busy = false;
      clearInterval(srcRun.timer); srcRun.timer = 0;
      moveRing({ end: 'done' });
      srcRun.summary = (kept.length ? '각주 ' + kept.length + '개를 달았어요. 빼고 싶은 각주는 각주 목록에서 뺄 수 있어요.' : '확인된 인용이 없어서 각주를 달지 않았어요. 원고는 그대로예요.') + needs;
      saveDraft(true);
      renderSources();
      $('#src-read-h').focus();
    } catch (e) {
      diag.error = String(e?.message ?? e).slice(0, 200);
      return stop(srcRun.at || 'select', '문제가 생겨 멈췄어요. 다시 눌러 주세요.', 'error');
    }
  }
  /** Can the tool search here? An empty query asks without a search (no AI call is spent first): true, or the note. */
  async function searchReady() {
    try { const r = await hostCall('web-search', { query: '', kind: 'web' }); noteHostInfo(r); return r?.error && r.error !== 'invalid' ? searchErrorNote(r.error, S.keysFile) : true; }
    catch (e) { return /unknown tool|not.?found|not.?allowed|not.?declared|not.?listed/i.test(String(e?.code ?? '') + ' ' + String(e?.message ?? '')) ? '웹 검색은 주석 도구를 새로 시작하면 해요' : SEARCH_NOTE.unreachable; }
  }
  /** 웹에서 찾기: one AI call for the queries, the host searches and reads (A sites first), one AI call for footnotes from
   * those pages only, each quote checked on its page. -> {kept, sources, note}; nothing found is a note, never an error. */
  async function writeSearch(d, open) {
    const none = (note) => ({ kept: [], sources: [], note });
    const ready = await searchReady();
    if (ready !== true) return none(ready);
    const v1 = await ask(promptClaimQueries({ passage: d.ref.label, claims: open }));
    if (v1 === undefined) return none('검색어를 받지 못했어요');
    const qs = checkClaimQueries(v1, open.length);
    if (!qs.length) return none('검색어를 받지 못했어요');
    const per = [];
    for (const q of qs) {
      let r;
      try { r = await hostCall('web-search', { query: q.query, kind: q.kind, count: 5 }); } catch (e) { return none(SEARCH_NOTE.unreachable); }
      if (r?.error) return none(searchErrorNote(r.error, S.keysFile));
      per.push([q.claim, r.results || []]);
      if (srcRun.cancel) return none('');
    }
    const reads = [];
    for (const p of pickReads(per)) {
      try { const r = await hostCall('web-read', { url: p.url }); if (r && r.text) reads.push(r); } catch (e) { /* this page is skipped */ }
      if (srcRun.cancel) return none('');
    }
    const ex = readExcerpts(reads);
    if (!ex.length) return none('검색 ' + qs.length + '번 · 읽을 수 있는 페이지를 찾지 못했어요');
    const v2 = await ask(promptFootnotes({ passage: d.ref.label, manuscript: d.manuscript.edited, excerpts: ex }), { limitMs: AI_LIMIT_MS.propose });
    if (v2 === undefined) return none('각주 제안을 받지 못했어요');
    const kept = [];
    for (const f of checkFootnotes(v2, { manuscript: d.manuscript.edited, excerpts: ex }).items) {
      try { const r = await hostCall('web-verify', { url: f.url, quote: f.quote }); if (r && r.status === 'found' && r.doctrine === f.doctrine) kept.push({ ...f, status: 'found', checkedAt: r.checkedAt ?? f.checkedAt }); } catch (e) { /* not kept */ }
      if (srcRun.cancel) return none('');
    }
    return { kept, sources: ex, note: '검색 ' + qs.length + '번 · 읽은 페이지 ' + reads.length + '개 · 확인된 인용 ' + kept.length + '개' };
  }
  /** 시사 예화 찾기 (7 예화, with the tool): news queries -> news search (2 years) -> the top articles read (A sites first)
   * -> 1-2 예화 written from those articles only -> each quote checked in its article. Added to the 예화 (never replacing). */
  const newsRun = { busy: false };
  const newsSay = (t) => { $('#ill-news-note').textContent = t || ''; };
  async function writeNews() {
    const d = S.draft;
    if (newsRun.busy || !d.illustration) return;
    newsRun.busy = true;
    const nr = { stage: 'queries', at: Date.now(), chars: 0, done: 0, total: 0, expected: 1 };
    const go = (stage, o = {}) => { Object.assign(nr, { stage, at: Date.now(), chars: 0, done: 0, total: 0, expected: 1 }, o); S.aiRing?.tick(); };
    const onText = ({ text }) => { nr.chars = text.length; };
    try {
      newsSay('시사 예화를 찾는 중…');
      const ready = await searchReady();
      if (ready !== true) { newsSay(ready); return; }
      go('queries', { expected: aiExpected('queries') });
      ringNow(() => newsRingPct({ ...nr, ms: Date.now() - nr.at }));
      const v1 = await ask(promptNewsQueries(d), { onText });
      if (v1 === undefined) { newsSay(''); return; }
      const qs = checkNewsQueries(v1);
      if (!qs.length) { newsSay('검색어를 받지 못했어요. 다시 눌러 주세요.'); return; }
      go('search', { total: qs.length });
      const results = [];
      for (const q of qs) {
        let r;
        try { r = await hostCall('web-search', { query: q, kind: 'news', count: 5, recentDays: NEWS_RECENT_DAYS }); } catch (e) { newsSay(SEARCH_NOTE.unreachable); return; }
        if (r?.error) { newsSay(searchErrorNote(r.error, S.keysFile)); return; }
        results.push(...(r.results || []));
        nr.done++;
      }
      const picked = pickArticles(results);
      go('read', { total: picked.length });
      const articles = [];
      for (const p of picked) {
        try { const r = await hostCall('web-read', { url: p.url }); if (r && r.text) articles.push({ ...r, url: p.url, site: p.site, publishedAt: p.publishedAt ?? null, tier: p.tier, doctrine: p.doctrine, title: p.title || r.title }); } catch (e) { /* skipped */ }
        nr.done++;
      }
      if (!articles.length) { newsSay('읽을 수 있는 기사를 찾지 못했어요.'); return; }
      go('write', { expected: aiExpected('news') });
      const v2 = await ask(promptNewsIllustrations(d, articles), { onText });
      if (v2 === undefined) { newsSay(''); return; }
      const items = checkNewsIllustrations(v2, articles);
      if (!items.length) { newsSay('설교에 맞는 시사 예화를 찾지 못했어요.'); return; }
      go('verify', { total: items.length });
      for (const it of items) {
        try { const x = await hostCall('web-verify', { url: it.source.url, quote: it.quote }); it.verified = !!x && x.status === 'found'; if (it.verified) it.checkedAt = x.checkedAt ?? null; } catch (e) { it.verified = false; }
        nr.done++;
      }
      const W = d.illustration;
      if (!W.edited) W.edited = { items: [], by: 'ai', userEdited: false };
      W.edited.items.push(...items);
      const unv = items.filter((x) => !x.verified).length;
      newsSay('시사 예화 ' + items.length + '개를 더했어요.' + (unv ? ' 인용을 기사에서 찾지 못한 예화는 \'확인 필요\'로 표시했어요.' : ''));
      renderWork('illustration');
      saveDraft(true);
      return true;
    } finally { newsRun.busy = false; }
  }
  $('#btn-ill-news').addEventListener('click', (e) => withRing(e.currentTarget, 'news', writeNews));
  /** A 시사 예화's source: outlet · date · 주소, the badge for E/N, 참고 (a site not on the list), 확인 필요 (quote not found). */
  function newsSource(x) {
    const s = x.source || {};
    const url = /^https?:\/\//.test(String(s.url || '')) ? s.url : null;
    return '<p class="ol-extra ill-source">' + esc(s.site || '') + (s.publishedAt ? ' · ' + esc(String(s.publishedAt).slice(0, 10)) : '') + (url ? ' · <a class="bref" href="' + esc(url) + '" target="_blank" rel="noopener">주소</a>' : '')
      + (DOC_LABEL[s.doctrine] ? ' <span class="fn-doc">' + DOC_LABEL[s.doctrine] + '</span>' : '') + (s.tier === 'B' ? ' <span class="fn-doc">참고</span>' : '') + (x.verified ? '' : ' <span class="note warn">확인 필요</span>') + '</p>';
  }
  /** The 확인이 필요한 문장 of the stored check (none in older checks). */
  const openClaims = (d) => (d?.sourceCheck?.claims || []).filter((c) => c.status === 'unsupported');
  /** A piece of a paragraph (at `from` in the squashed text) with the claim sentences in it lightly marked. */
  function markPiece(text, from, ranges) {
    let out = '', at = 0;
    for (const r of ranges) {
      const a = Math.max(r.a - from, at), b = Math.min(r.b - from, text.length);
      if (b <= a) continue;
      out += esc(text.slice(at, a)) + '<mark class="claim-mark" title="확인 필요">' + esc(text.slice(a, b)) + '</mark>';
      at = b;
    }
    return out + esc(text.slice(at));
  }
  /** The manuscript paragraphs with footnote numbers (출처 확인; the final view passes plain) and, on 출처 확인, the marked claims. */
  function notedHtml(d, pClass, plain, claims) {
    const notes = plain ? [] : footnotesOf(d);
    return workList('manuscript', d.manuscript?.edited).map((x, si) => '<section class="ol-part final-part" aria-labelledby="' + pClass + '-sec-' + si + '"><p class="final-part-k">' + esc(x.label) + '</p><h4 id="' + pClass + '-sec-' + si + '">' + esc(x.heading) + '</h4>'
      + x.paragraphs.filter((t) => t.trim()).map((t, pi) => {
        const sq = t.normalize('NFC').replace(/\s+/g, ' ').trim();
        const ranges = (claims || []).filter((c) => c.section === si && c.paragraph === pi).map((c) => { const a = sq.indexOf(c.anchor); return { a, b: a + c.anchor.length }; }).filter((r) => r.a >= 0).sort((p, q) => p.a - q.a);
        let from = 0;
        return '<p class="' + pClass + '">' + placeNotes(t, notes.filter((f) => f.section === si && f.paragraph === pi)).map((piece) => { const h = markPiece(piece.text, from, ranges); from += piece.text.length; return h + piece.notes.map((n) => '<sup class="fn"><a href="#' + pClass + '-fn-' + n + '" id="' + pClass + '-ref-' + n + '">' + n + '</a></sup>').join(''); }).join('') + '</p>';
      }).join('') + '</section>').join('');
  }
  // an online commentary: author, title — 주소 — 확인 <date> (the date the tool read the page)
  // (functions, not consts: the 본문연구 and 원고 초안 views use them too)
  function fnSource(f) {
    return isWeb(f) && webHref(f.url) ? '<span class="src-title">' + esc(webLabel(f)) + '</span> — <a class="bref" href="' + esc(webHref(f.url)) + '" target="_blank" rel="noopener">주소</a>' + (f.checkedAt ? ' — <span class="fn-checked">확인 ' + esc(String(f.checkedAt).slice(0, 10)) + '</span>' : '')
      : '<span class="src-title">' + esc(commentaryLabel(f)) + '</span>';
  }
  function fnItem(f, pClass, removable) {
    return '<li id="' + pClass + '-fn-' + f.n + '" value="' + f.n + '">' + fnSource(f) + (DOC_LABEL[f.doctrine] ? ' <span class="fn-doc">' + DOC_LABEL[f.doctrine] + '</span>' : '')
      + ' <details class="fn-quote"><summary>인용 보기</summary><p>' + esc(f.quote) + '</p></details>'
      + (removable ? ' <button type="button" class="linkbtn" data-fn-remove="' + esc(f.id) + '" aria-label="각주 ' + f.n + ' 빼기">빼기</button>' : '') + '</li>';
  }
  function renderSources() {
    const sec = $('#step-sources');
    sec.hidden = screen() !== 'sources' || !!S.final;
    if (sec.hidden) return;
    const d0 = S.draft;
    // an old draft handed off before the in-page steps has no manuscript here: nothing to footnote, say so
    const gate = !hasManuscript(d0) && !srcRun.busy;
    $('#src-gate').hidden = !gate;
    $('.src-done', sec).hidden = gate;
    $('#btn-final').hidden = gate;
    if (gate) {
      for (const id of ['#src-probe', '#src-host', '#src-fallback']) $(id).hidden = true;
      const url = macOf(d0).pageUrl;
      $('#src-gate-page').innerHTML = url ? '<a class="bref" href="' + esc(url) + '" target="_blank" rel="noopener">설교 페이지 열기</a>' : '';
      return;
    }
    if (S.host == null) { probeHost(); }
    const host = S.host === 'present' || S.host === 'warn';
    $('#src-probe').hidden = host || S.host === 'absent';
    $('#src-host').hidden = !host;
    $('#src-fallback').hidden = S.host !== 'absent';
    $('#src-host-warn').hidden = S.host !== 'warn';
    $('#src-ai-off').hidden = !S.aiOff;
    const d = S.draft;
    const done = !!d.sourceCheck?.footnotes && !srcRun.busy; // a run that stopped keeps only its diag
    $('#btn-source-check').hidden = !host || S.aiOff || done;
    $('#btn-source-check').disabled = srcRun.busy;
    $('#btn-source-stop').hidden = !srcRun.busy;
    $('#btn-src-perm').hidden = !srcRun.perm || srcRun.busy;
    // one way on: before a check the final view is a small link beside 출처 확인하기; after it (or without the tool) the button
    const fin = $('#btn-final');
    const small = host && !done && !S.aiOff;
    fin.className = small ? 'linkbtn' : 'btn primary';
    fin.textContent = small ? '출처 확인 없이 설교 원고 보기' : '설교 원고 보기';
    const steps = srcRun.steps;
    $('#src-steps').hidden = !steps;
    $('#src-progress').hidden = !steps;
    renderRing();
    if (steps) $('#src-steps').innerHTML = steps.map((x) => '<li class="src-step st-' + x.state + '"><span class="src-mark" aria-hidden="true">' + ({ todo: '·', doing: '…', done: '✓', fail: '!' }[x.state]) + '</span> ' + esc(x.label) + '<span class="sr"> (' + ({ todo: '아직', doing: '하는 중', done: '마침', fail: '못 함' }[x.state]) + ')</span>' + (x.note ? ' <span class="note">' + esc(x.note) + '</span>' : '') + '</li>').join('');
    $('#src-summary').textContent = srcRun.summary;
    $('#src-result').hidden = !done;
    if (done) {
      const notes = footnotesOf(d);
      const claims = openClaims(d);
      $('#src-read').innerHTML = notedHtml(d, 'ms-p', false, claims);
      $('#src-fns').innerHTML = notes.length ? notes.map((f) => fnItem(f, 'ms-p', !f.noteId)).join('') : '<li class="note">달린 각주가 없어요.</li>'; // the 본문연구's own: taken out there
      const parts = workList('manuscript', d.manuscript?.edited);
      $('#src-claims').hidden = !claims.length;
      $('#src-claim-items').innerHTML = claims.map((c) => '<li><span class="claim-part">' + esc(parts[c.section]?.label ?? '') + '</span> <span class="claim-kind">' + esc(CLAIM_KIND_LABEL[c.kind] || '') + '</span><p class="claim-text">' + esc(c.anchor) + '</p><button type="button" class="linkbtn" data-claim-fix="' + c.section + '">원고에서 고치기</button></li>').join('');
      $('#btn-source-again').hidden = S.aiOff;
    }
    $('#handoff-title').textContent = draftTitle(d);
    $('#handoff-sentence').textContent = handoffSentence(d);
    $('#handoff-status').textContent = statusLabel(d.status);
    const m = macOf(d);
    $('#src-work').innerHTML = esc(WORK_WORD[m.sources]) + (m.pageUrl ? ' <a class="bref" href="' + esc(m.pageUrl) + '" target="_blank" rel="noopener">설교 페이지 열기</a>' : '');
  }
  $('#btn-source-check').addEventListener('click', runSourceCheck);
  $('#btn-gate-ms').addEventListener('click', () => openNext('manuscript')); // an old draft may not have reached it yet
  $('#btn-source-stop').addEventListener('click', () => { srcRun.cancel = true; if (srcRun.ctl) srcRun.ctl.abort(); if (S.aiBusy) S.aiBusy.abort(); });
  $('#btn-src-perm').addEventListener('click', () => openPermissions((t) => { $('#src-summary').textContent = t; }));
  $('#btn-source-again').addEventListener('click', runSourceCheck);
  // 원고에서 고치기: the 원고 step with that part open for editing (the check never changes the 원고 itself)
  $('#src-claim-items').addEventListener('click', (e) => {
    const b = e.target.closest('[data-claim-fix]');
    if (!b) return;
    goStep('manuscript');
    const part = $('#w-manuscript [data-w-part="' + b.dataset.claimFix + '"]');
    if (part && part.offsetParent) part.click();
  });
  $('#src-fns').addEventListener('click', (e) => {
    const b = e.target.closest('[data-fn-remove]');
    if (!b) return;
    const f = (S.draft.sourceCheck?.footnotes || []).find((x) => x.id === b.dataset.fnRemove);
    if (!f) return;
    f.removed = true; // kept in the data, no longer shown
    saveDraft(true);
    renderSources();
    $('#src-fn-h').focus();
  });

  // ---------------------------------------------------------------- 설교 원고 (final view): the manuscript for the pulpit
  function renderFinal() {
    const sec = $('#final-view');
    const on = screen() === 'sources' && !!S.final;
    sec.hidden = !on;
    document.body.classList.toggle('print-final', on);
    if (!on) return;
    const d = S.draft;
    $('#final-h').textContent = draftTitle(d);
    $('#final-ref').textContent = d.ref ? d.ref.label + ' · 개역개정 읽기' : '';
    if (d.ref) $('#final-ref').href = d.ref.url;
    const msg = outlineOf(d.outlines?.edited).message.trim();
    $('#final-msg').hidden = !msg;
    $('#final-one').textContent = msg;
    // the clean manuscript only: footnotes stay on the 출처 확인 screen (owner 2026-10-28)
    $('#final-body').innerHTML = notedHtml(d, 'final-p', true);
    $('#final-fns').hidden = true;
    $('#final-fn-list').innerHTML = '';
    // finished: opened from 지난 설교 목록, with the published page and the way back into the steps
    $('#final-act').hidden = !!d.finished;
    $('#final-done').hidden = !d.finished;
    const url = safeUrl(rows().find((r) => draftOfRow(r)?.id === d.id)?.url) || safeUrl(d.mac?.pageUrl);
    $('#final-page').hidden = !url;
    if (url) $('#final-page').href = url;
  }
  // 마무리하기: the draft leaves 준비중인 설교 (never deleted) and gets its 지난 설교 row (merged into one already there)
  $('#btn-finish').addEventListener('click', async () => {
    if (!(await askUser({ title: '이 설교를 마무리하고 지난 설교 목록으로 옮길까요?', text: '준비 단계는 그대로 남아 있어 언제든 다시 열 수 있어요.', ok: FINISH_BUTTON }))) return;
    const f = finishDraft(S.draft, new Date(), BOOKS);
    S.draft.finished = f.draft.finished;
    const saving = [saveDraft(true)];
    if (f.id) {
      const { id: _i, ...was } = rows().find((x) => x.id === f.id) || {};
      saving.push(saveRow({ id: f.id, ...mergeRow(Object.keys(was).length ? was : null, f.row) }));
    }
    renderDrafts();
    history.pushState(null, '', '#past');
    show('past');
    renderPast();
    const link = f.id && $('#past-list [data-row="' + f.id + '"] .row-link');
    if (link) link.focus();
    await Promise.all(saving);
    status('지난 설교 목록으로 옮겼어요.'); // after 저장했어요
  });
  $('#btn-reopen').addEventListener('click', async () => {
    if (!(await askUser({ title: '준비 단계를 다시 열까요?', text: '이 설교가 준비중인 설교로 돌아가요.', ok: '다시 열기' }))) return;
    delete S.draft.finished;
    saveDraft(true);
    renderDrafts();
    show('start');
    openStep(currentStep(S.draft));
  });
  /** #past/<row id>: the row's finished draft in the 설교 원고 view of this page (a row without one: the list). */
  function openPast(id) {
    const r = rows().find((x) => x.id === id);
    const d = r && draftOfRow(r);
    if (!d) { show('past'); return; }
    if (S.draft.id !== d.id) { leaveDraft(); S.draft = JSON.parse(JSON.stringify(d)); delete S.draft.title; msInputs(S.draft); S.base = d.updatedAt; S.remoteWaiting = false; }
    show('start');
    $('.menu a[href="#start"]').removeAttribute('aria-current'); // opened from 지난 설교 목록: that menu item stays current
    $('.menu a[href="#past"]').setAttribute('aria-current', 'page');
    S.final = true;
    renderAll();
    window.scrollTo(0, 0);
    $('#final-h').focus();
  }
  $('#btn-final').addEventListener('click', () => { S.final = true; renderAll(); $('#final-h').focus(); window.scrollTo(0, 0); });
  $('#btn-final-back').addEventListener('click', () => { S.final = false; renderAll(); $('#src-h').focus(); });
  $('#btn-copy-sentence').addEventListener('click', async () => {
    const text = handoffSentence(S.draft);
    let ok = false;
    // a framed page may never answer the clipboard: give it a moment, then select the sentence instead
    try { if (navigator.clipboard && navigator.clipboard.writeText) ok = await Promise.race([navigator.clipboard.writeText(text).then(() => true), new Promise((r) => setTimeout(() => r(false), 1500))]); } catch (e) { ok = false; }
    if (!ok) { const r = document.createRange(); r.selectNodeContents($('#handoff-sentence')); const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(r); }
    $('#copy-status').textContent = ok ? '복사했어요. Claude Code에 붙여 넣어 말씀해 주세요.' : '문장을 골라 두었어요. 복사해서 Claude Code에 붙여 넣어 주세요.';
  });

  // ---------------------------------------------------------------- 준비 단계: one step at a time (wizard)
  const screen = () => screenOf(currentStep(S.draft));
  const reduceMotion = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  /** Something on step `key` changed: later steps that hold content are marked for review (never deleted). */
  function changed(_key) {
    // every change of an earlier step (outline and the in-page steps after it included) is settled by the redo
    // dialog when going on; nothing is marked for review any more
  }
  function reviewNote(key) { const n = $('#' + key + '-review'); if (n) n.hidden = !(S.draft.review || []).includes(key); }
  function renderSteps() {
    const html = stepsHtml(stepProgress(S.draft));
    $$('.steps').forEach((ol) => { ol.innerHTML = html; });
    // the phone stepper scrolls inside itself; keep the current step in view without moving the page
    const bar = $('.stepper'), cur = $('.stepper a[aria-current="step"]');
    if (bar && cur && bar.offsetParent) {
      const br = bar.getBoundingClientRect(), cr = cur.getBoundingClientRect();
      if (cr.left < br.left) bar.scrollLeft -= br.left - cr.left + 16;
      else if (cr.right > br.right) bar.scrollLeft += cr.right - br.right + 16;
    }
  }
  function renderSummary() {
    const items = summaryOf(S.draft);
    $('#summary').hidden = !items.length;
    $('#summary-list').innerHTML = items.map((x) => '<div class="sum-row"><dt>' + esc(x.label) + ' <button type="button" class="linkbtn" data-goto="' + x.key + '" aria-label="' + esc(x.label) + ' 고치기">고치기</button></dt><dd>'
      + (x.ref ? '<a class="bref" href="' + esc(x.ref.url) + '" target="_blank" rel="noopener">' + esc(x.ref.label) + ' · 개역개정 읽기</a>'
        : x.moves ? (x.message ? '<p class="sum-one">' + esc(x.message) + '</p>' : '') + '<ol class="list">' + x.moves.filter((m) => m.heading).map((m) => '<li><span class="mv-label">' + esc(m.label) + '</span> ' + esc(m.heading) + '</li>').join('') + '</ol>'
        : (x.title ? '<strong>' + esc(x.title) + '</strong> ' : '') + '<span class="sum-text">' + esc(x.text) + '</span>') + '</dd></div>').join('');
  }
  const HEAD = { passage: '#step-passage-h', seed: '#step-seed-h', direction: '#dir-h', outline: '#ol-h', exegesis: '#exegesis-h', setting: '#setting-h', illustration: '#illustration-h', application: '#application-h', manuscript: '#manuscript-h', sources: '#src-h' };
  /** Open a step: unreachable steps open the current one. Re-renders from the draft only (no AI call). */
  function openStep(key, opts) {
    const o = opts || {};
    const d = S.draft;
    const from = redoBefore(d, key);
    if (from) { askRedo(from).then((ok) => openStep(ok ? key : currentStep(S.draft), { ...o, push: ok ? o.push : false })); return; }
    if (!stepReachable(d, key)) key = currentStep(d);
    if (key === 'setting' || (WORK_KEYS.includes(key) && !d[key])) prepare(key); // reached (예화 · 적용 from a later step, or done on the computer) and opened here
    S.final = false; // opening a step leaves the final view
    const sc = screenOf(key);
    if (!(d.step === 'handoff' && sc === 'sources')) d.step = sc; // an older handed-off draft is not rewritten just by opening it
    renderAll();
    if (o.save !== false) saveDraft(true);
    const hash = '#' + STEP_LIST.find((x) => x.key === key).hash;
    if (o.push !== false && location.hash !== hash) history.pushState(null, '', hash);
    else if (o.push === false && location.hash !== hash) history.replaceState(null, '', hash);
    const h = $(HEAD[key]);
    if (h && o.focus !== false) {
      h.scrollIntoView({ block: 'start', behavior: reduceMotion() ? 'auto' : 'smooth' });
      h.focus({ preventScroll: true });
    }
  }
  const goStep = (key, opts) => openStep(key, opts);
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[data-step]');
    const g = e.target.closest('[data-goto], [data-back]');
    if (a) {
      e.preventDefault();
      show('start');
      openStep(a.dataset.step);
    } else if (g) openStep(g.dataset.goto || g.dataset.back);
  });
  window.addEventListener('hashchange', fromHash);

  // ---------------------------------------------------------------- 앞 단계가 바뀌었을 때: 남겨 두기 / 지우기 / 취소
  const REDO_HEAD = { passage: '설교 본문이 바뀌었어요', seed: { meditation: '나의 묵상이 바뀌었어요', central: '중심 메시지가 바뀌었어요' }, direction: '설교 방향이 바뀌었어요', outline: '개요가 바뀌었어요', exegesis: '본문연구가 바뀌었어요' };
  const REDO_TEXT = { passage: (d) => '새 본문(' + (d.ref?.label || d.passage) + ')으로 나의 묵상부터 다시 준비해요.', seed: () => '바뀐 내용으로 설교 방향부터 다시 준비해요.', direction: () => '바뀐 설교 방향으로 개요부터 다시 준비해요.', outline: () => '바뀐 개요로 본문연구부터 다시 준비해요.', exegesis: () => '바뀐 본문연구로 원고 초안부터 다시 준비해요.' };
  /** Ask before anything is lost. Resolves true when the draft goes on from the changed step, false on 취소 (reverted). */
  /** Yes / no inside the page (the app's frame blocks the browser's own confirm box): resolves true for `ok`, false for 취소 or Esc;
   * the primary button takes the focus, and the focus goes back to what opened it. */
  function askUser({ title, text = '', ok, cancel = '취소' }) {
    const dlg = $('#confirm');
    const opener = document.activeElement;
    $('#confirm-h').textContent = title;
    $('#confirm-desc').textContent = text;
    $('#confirm-desc').hidden = !text;
    $('[data-confirm="ok"]', dlg).textContent = ok;
    $('[data-confirm="cancel"]', dlg).textContent = cancel;
    return new Promise((resolve) => {
      const done = (yes) => {
        dlg.removeEventListener('click', onClick);
        dlg.removeEventListener('cancel', onCancel);
        if (dlg.open) { if (dlg.close) dlg.close(); else dlg.removeAttribute('open'); }
        if (opener && opener.isConnected && opener.focus) opener.focus();
        resolve(yes);
      };
      const onClick = (e) => { const b = e.target.closest('[data-confirm]'); if (b) done(b.dataset.confirm === 'ok'); };
      const onCancel = (e) => { e.preventDefault(); done(false); };
      dlg.addEventListener('click', onClick);
      dlg.addEventListener('cancel', onCancel);
      if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
      $('[data-confirm="ok"]', dlg).focus();
    });
  }
  function askRedo(from) {
    const d = S.draft;
    const dlg = $('#redo');
    const head = REDO_HEAD[from];
    $('#redo-h').textContent = typeof head === 'string' ? head : head[seedPath(d)] || head.meditation;
    $('#redo-desc').textContent = REDO_TEXT[from](d);
    $('#redo-list').innerHTML = laterWork(d, from).map((x) => '<li>' + esc(x.label) + '</li>').join('');
    return new Promise((resolve) => {
      const done = (choice) => {
        dlg.removeEventListener('click', onClick);
        dlg.removeEventListener('cancel', onCancel);
        if (dlg.open) { if (dlg.close) dlg.close(); else dlg.removeAttribute('open'); }
        resolve(applyRedo(from, choice));
      };
      const onClick = (e) => { const b = e.target.closest('[data-redo]'); if (b) done(b.dataset.redo); };
      const onCancel = (e) => { e.preventDefault(); done('cancel'); };
      dlg.addEventListener('click', onClick);
      dlg.addEventListener('cancel', onCancel);
      if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
      $('[data-redo="keep"]', dlg).focus();
    });
  }
  function applyRedo(from, choice) {
    const d = S.draft;
    if (choice === 'cancel') { revertChange(d, from); renderAll(); saveDraft(true); status('바꾸기 전으로 되돌렸어요.'); return false; }
    const at = new Date().toISOString();
    const savedMac = macField(d).mac;
    if (choice === 'keep') {
      const c = keptCopy(d, from, newId(), at, savedMac);
      S.docs.set(DOC.draft(c.id), { ...c, title: draftTitle(c) }); // listed right away; the db snapshot follows
      save(DOC.draft(c.id), { ...c, title: draftTitle(c) });
      renderDrafts();
    }
    redoFrom(d, from, at);
    // the Claude Code steps of this draft start over too: the page writes mac this once (cleared), never moves it
    const saved = S.docs.get(DOC.draft(d.id));
    if (saved && saved.mac !== undefined) S.docs.set(DOC.draft(d.id), { ...saved, mac: {} });
    renderAll();
    saveDraft(true);
    status(choice === 'keep' ? '이전 작업은 준비중인 설교에 따로 남겼어요.' : '이전 작업을 지웠어요.');
    if (from === 'passage') $('#f-meditation').focus();
    return true;
  }

  // ---------------------------------------------------------------- AI calls: only on a button press
  const AI_OFF = ['not_granted', 'sampling_disabled', 'not_declared', 'capability_disabled', 'capability_removed'];
  function setAiOff() {
    S.aiOff = true;
    $$('[data-ai]').forEach((b) => { b.hidden = true; });
    $('#ai-off').hidden = false;
    aiStatus('');
    renderOutline(); // the outline is then written by hand, part by part
    for (const k of WORK_KEYS) renderWork(k); // and so are the steps after it
    renderSources();
    updateGates(); // the composer's one way on becomes 설교 방향 직접 쓰기
  }
  const GRANT_NOTE = 'AI 사용 허락 창이 보이지 않으면, 화면 위 메뉴의 권한에서 AI 사용을 허락한 뒤 다시 눌러 주세요.';
  /** The platform's Permissions panel, only on a click (after the grant did not come back in time). */
  async function openPermissions(say) {
    const perm = await use('permissions');
    try { if (!perm) throw new Error('unavailable'); await perm.manage(); say('권한을 바꾸셨으면 다시 눌러 주세요.'); }
    catch (e) { say('화면 위 메뉴의 권한에서 AI 사용을 허락한 뒤 다시 눌러 주세요.'); }
  }
  // ---------------------------------------------------------------- the small ring beside an AI button (owner 2026-10-28)
  // withRing(button, kind, fn): the ring shows when fn's first AI call starts (or at once when a staged run calls
  // ringNow), right after the pressed button; 1-99 % by the streamed length and the time (aiRingPct, or the run's own
  // staged place), then 100 % and 다 됐어요 for a second when fn returns true; gone at once on a failure or a stop.
  const RING_DONE_MS = 1000;
  function aiRing(btn, o) {
    $$('.ai-ring').forEach((x) => x.remove()); // never two
    const label = (btn.textContent || '').trim();
    btn.insertAdjacentHTML('afterend', '<div class="src-progress ms-progress ms-progress--inline ai-ring"><div class="src-ring" data-state="run"><div class="ring" role="progressbar" aria-label="' + esc(label) + ' 진행률" aria-valuemin="0" aria-valuemax="100" aria-valuenow="1"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="ring-track" cx="50" cy="50" r="44"/><circle class="ring-fill" cx="50" cy="50" r="44" pathLength="100"/></svg><span class="ring-num" aria-hidden="true">1%</span></div><p class="ring-stage" aria-live="polite"></p></div></div>');
    const box = btn.nextElementSibling;
    const t0 = Date.now();
    const r = { pct: 1, chars: 0, state: 'run', pctOf: o.pct || null, timer: 0 };
    const paint = () => {
      const pct = Math.floor(r.pct);
      box.querySelector('.ring').setAttribute('aria-valuenow', String(pct));
      box.querySelector('.ring-num').textContent = pct + '%';
      box.querySelector('.ring-fill').style.strokeDashoffset = String(100 - pct);
      box.querySelector('.src-ring').dataset.state = r.state;
      box.querySelector('.ring-stage').textContent = r.state === 'done' ? '다 됐어요' : '';
    };
    const ring = {
      tick() { if (r.state !== 'run') return; r.pct = Math.max(r.pct, r.pctOf ? r.pctOf() : aiRingPct({ chars: r.chars, expected: o.expected, ms: Date.now() - t0 })); paint(); },
      text(n) { r.chars = n; ring.tick(); },
      use(fn) { r.pctOf = fn; ring.tick(); },
      done() { clearInterval(r.timer); r.state = 'done'; r.pct = 100; paint(); setTimeout(() => box.remove(), RING_DONE_MS); },
      fail() { clearInterval(r.timer); r.state = 'fail'; box.remove(); },
    };
    r.timer = setInterval(ring.tick, 1000);
    paint();
    return ring;
  }
  async function withRing(btn, kind, fn) {
    if (S.aiBusy || S.aiOff) return fn(); // nothing starts (ask says why)
    S.ringAt = { btn, expected: aiExpected(kind) };
    let ok = false;
    try { ok = (await fn()) === true; }
    finally {
      const ring = S.aiRing;
      S.ringAt = null; S.aiRing = null;
      if (ring) { if (ok) ring.done(); else ring.fail(); }
    }
  }
  /** A staged run (본문연구 with the tool, 시사 예화 찾기) shows the ring from its first stage, placed by `pct`. */
  function ringNow(pct) {
    if (!S.ringAt) return;
    if (!S.aiRing) S.aiRing = aiRing(S.ringAt.btn, { ...S.ringAt, pct });
    else S.aiRing.use(pct);
  }
  async function ask(text, opts = {}) {
    const { limitMs = AI_LIMIT_MS.other, ...sampleOpts } = opts;
    S.aiFail = null;
    S.aiConsent = null;
    if (S.aiOff || S.aiBusy) return undefined;
    if (S.ringAt) {
      if (!S.aiRing) S.aiRing = aiRing(S.ringAt.btn, S.ringAt);
      const ring = S.aiRing, own = sampleOpts.onText;
      sampleOpts.onText = (x) => { own?.(x); ring.text(String(x?.text ?? '').length); };
    }
    const ctl = new AbortController();
    S.aiBusy = ctl;
    $$('[data-ai]').forEach((b) => { b.disabled = true; });
    $('#ai-stop').hidden = false;
    $('#btn-ai-perm').hidden = true;
    aiStatus('생각하는 중…');
    try {
      // bounded from the press (use, grant, call): in the app any of them can wait without ever settling
      const r = await aiPath({ use, signal: ctl.signal, callMs: limitMs, call: (sample) => sample.json(text, { ...sampleOpts, signal: ctl.signal, cache: false }) });
      S.aiConsent = r.consent;
      aiStatus('');
      return r.value;
    } catch (e) {
      const code = e && e.code;
      S.aiFail = code || 'failed';
      S.aiConsent = e && e.consent;
      if (code === 'timeout') ctl.abort(); // tell the platform to stop too
      if (code === 'not_granted') { aiStatus(GRANT_NOTE); $('#btn-ai-perm').hidden = false; } // the call itself was refused: say where to allow it
      else if (AI_OFF.includes(code) || code === 'unavailable') setAiOff();
      else if (code === 'use_timeout') aiStatus('AI를 불러오지 못했어요. 잠시 뒤 다시 눌러 주세요.');
      else if (code === 'timeout') aiStatus('AI 답이 너무 오래 오지 않아 멈췄어요. 잠시 뒤 다시 눌러 주세요.');
      else if (code === 'cancelled') aiStatus('멈췄어요.');
      else if (code === 'rate_limited') { aiStatus('요청이 많아요. 30초쯤 뒤에 다시 눌러 주세요.'); S.cooldown = Date.now() + 30000; setTimeout(() => { S.cooldown = 0; enableAi(); }, 30000); }
      else if (code === 'session_expired') aiStatus('Claude에 다시 로그인해 주세요.');
      else if (code === 'invalid_json') aiStatus('답을 읽지 못했어요. 다시 눌러 주세요.');
      else if (code === 'refused' || code === 'empty_completion') aiStatus('추천을 받지 못했어요. 적은 내용을 조금 바꿔 다시 눌러 주세요.');
      else aiStatus('연결이 잠시 끊겼어요. 다시 눌러 주세요.');
      return undefined;
    } finally {
      S.aiBusy = null;
      $('#ai-stop').hidden = true;
      enableAi();
    }
  }
  function enableAi() {
    if (S.cooldown && Date.now() < S.cooldown) return;
    $$('[data-ai]').forEach((b) => { b.disabled = false; });
    updateGates();
    styleGate();
  }
  $('#ai-stop').addEventListener('click', () => { if (S.aiBusy) S.aiBusy.abort(); });
  $('#btn-ai-perm').addEventListener('click', () => openPermissions(aiStatus));

  // ---------------------------------------------------------------- the same draft open in two windows (owner 2026-10-27)
  // A change saved by another window is taken here (this page's older copy is never written over it). While a part
  // is being edited, typed text waits to be saved or an AI answer is coming, it waits until that is over.
  const otherThanMac = (before, v) => { const { updatedAt: _u, mac: _m, ...now } = v; const was = JSON.parse(before); delete was.mac; return canon(now) !== canon(was); };
  const editingNow = () => wEdit.key !== null || olEdit.part !== null || flowEdit.part !== null || timer !== null || !!S.aiBusy || !!$('#redo').open || !!$('#confirm').open;
  function adoptRemote(v) {
    const was = S.draft.step;
    S.draft = JSON.parse(JSON.stringify(v));
    delete S.draft.title;
    msInputs(S.draft);
    S.base = v.updatedAt;
    S.remoteWaiting = false;
    wEdit.key = null; wEdit.part = null; olEdit.part = null; flowEdit.part = null; // an edit of the older copy is not kept
    if (was && was !== S.draft.step && stepReachable(S.draft, was)) S.draft.step = was; // stay on this screen when it can still be opened
    renderAll();
    status('다른 창에서 바뀐 내용을 가져왔어요.');
  }
  /** A 원고 초안 written before its inputs were kept: what the draft holds now is what it was written from (kept in
   * memory, saved with the next ordinary save), so a later change shows the 바뀐 내용 반영하기 bar. */
  function msInputs(d) { fillInputs(d, curStyle()); }
  function tryAdopt() {
    if (!S.remoteWaiting || editingNow()) return;
    const v = S.docs.get(DOC.draft(S.draft.id));
    if (v) adoptRemote(v); else S.remoteWaiting = false;
  }
  // an edit closes with a click (저장 · 취소) or by leaving the box: try again then
  document.addEventListener('click', () => setTimeout(tryAdopt, 0));
  document.addEventListener('focusout', () => setTimeout(tryAdopt, 0));

  // ---------------------------------------------------------------- whole start view from the current draft
  function renderAll() {
    const d = S.draft;
    passageIn.value = d.passage;
    renderSeed();
    renderPassage();
    renderRecommend();
    $('#recommend-panel').hidden = !d.recommend;
    renderFlow();
    renderDirection();
    renderOutline();
    renderSetting();
    for (const k of WORK_KEYS) renderWork(k);
    renderSources();
    renderFinal();
    renderSummary();
    renderSteps();
    // the first screen (step 1) opens with the question and the confession notice; later steps put the passage
    // on top as the title instead, with the summary card under it
    const first = screen() === 'passage';
    $('#composer').hidden = !first;
    $('#guide-card').hidden = !first;
    renderStyleCard();
    $('.hero').hidden = !first;
    $('.creed').hidden = !first;
    $('#ref-head').hidden = first || !d.ref || !!S.final;
    $('#summary').hidden = $('#summary').hidden || !!S.final;
    if (d.ref) { $('#ref-h').textContent = d.ref.label; $('#ref-link').href = d.ref.url; }
    $('#start-view').setAttribute('aria-labelledby', first || !d.ref ? 'start-h' : 'ref-h');
    $('#draft-title').textContent = d.passage || d.meditation || d.central?.message ? draftTitle(d) : '새 설교';
    updateGates();
  }
  /** Leave the open draft (its pending autosave is written now; an empty one is never written). */
  const leaveDraft = () => saveDraft(true);
  /** 새 설교 시작: the open draft stays as it is under 준비중인 설교; a new empty one starts at step 1. */
  function startNew() {
    leaveDraft();
    S.draft = newDraft(newId());
    S.base = null; S.remoteWaiting = false;
    renderAll();
    history.pushState(null, '', '#start');
    show('start');
    passageIn.focus();
  }
  $('#btn-new').addEventListener('click', startNew);
  $('.menu a[href="#start"]').addEventListener('click', (e) => { e.preventDefault(); startNew(); });

  // ---------------------------------------------------------------- 준비중인 설교
  // a finished draft is kept (지난 설교 목록 opens it) but no longer listed here
  const drafts = () => allDrafts().filter((d) => !(d.id === S.draft.id ? S.draft.finished : d.finished)); // the open one: as it is in memory
  const allDrafts = () => [...S.docs.entries()].filter(([k]) => kindOf(k) === 'draft').map(([, v]) => v).sort((a, b) => String(b.updatedAt ?? '').localeCompare(String(a.updatedAt ?? '')));
  function renderDrafts() {
    const list = drafts();
    $('#drafts-count').textContent = list.length ? String(list.length) : '';
    const box = $('#drafts-list');
    if (!S.col) { box.innerHTML = '<li class="empty">로그인하면 쓰던 설교가 여기에 저장돼요.</li>'; return; }
    box.innerHTML = list.length ? list.map((d) => '<li class="row-item"><button type="button" class="row-open" data-open="' + esc(d.id) + '"><span class="t">' + esc(draftTitle(d)) + '</span><span class="sub"><span>' + esc(d.ref?.label || d.passage || '본문 미정') + '</span><span>' + esc(currentLabel(d)) + '</span>' + (timeLabel(d.updatedAt) ? '<span>' + esc(timeLabel(d.updatedAt)) + ' 고침</span>' : '') + '</span></button><button type="button" class="btn icon" data-del-draft="' + esc(d.id) + '" aria-label="' + esc(draftTitle(d)) + ' 지우기">×</button></li>').join('') : '<li class="empty">준비중인 설교가 없어요. \'새 설교 시작\'에서 본문을 적으면 여기에 저장돼요.</li>';
  }
  $('#drafts-list').addEventListener('click', async (e) => {
    const o = e.target.closest('[data-open]');
    const del = e.target.closest('[data-del-draft]');
    if (o) {
      const d = S.docs.get(DOC.draft(o.dataset.open));
      // the open draft itself is newer in memory than its saved copy: keep it; another one is loaded as saved
      if (d) { if (S.draft.id !== d.id) { leaveDraft(); S.draft = JSON.parse(JSON.stringify(d)); delete S.draft.title; msInputs(S.draft); S.base = d.updatedAt; S.remoteWaiting = false; } show('start'); openStep(currentStep(S.draft), { save: false }); }
    } else if (del) {
      const id = del.dataset.delDraft;
      if (!(await askUser({ title: '이 설교 초안을 지울까요?', text: '지우면 되돌릴 수 없어요.', ok: '지우기' }))) return;
      remove(DOC.draft(id));
      S.docs.delete(DOC.draft(id)); // gone from the list now; the db snapshot follows
      if (S.draft.id === id) { S.draft = newDraft(newId()); renderAll(); }
      renderDrafts();
      status('초안을 지웠어요.');
    }
  });

  // ---------------------------------------------------------------- 지난 설교 목록 + 분류 기준
  const rows = () => [...S.docs.entries()].filter(([k]) => kindOf(k) === 'sermon').map(([k, v]) => ({ ...v, id: k.slice(7) }));
  const crit = () => criteriaOf(S.docs.get(DOC.settings));
  const C = (key) => crit().criteria.find((c) => c.key === key);
  function renderPast() {
    const cs = crit();
    const all = rows();
    // filters
    const opt = (v, label, cur) => '<option value="' + esc(v) + '"' + (v === cur ? ' selected' : '') + '>' + esc(label) + '</option>';
    const f = S.filter;
    $('#past-filters').innerHTML = [
      ['category', C('category').name, [...C('category').options, NONE]],
      ['service', C('service').name, C('service').options.filter((o) => o !== OTHER)],
      ['place', C('place').name, [...new Set([...C('place').options.filter((o) => o !== OTHER), ...all.flatMap((r) => (r.preached || []).map((p) => p.place)).filter(Boolean)])]],
      ['year', C('date').name, yearsOf(all)],
    ].map(([k, name, vals]) => '<label class="flt"><span>' + esc(name) + '</span><select data-filter="' + k + '">' + opt('', '전체', f[k]) + vals.map((v) => opt(v, k === 'year' ? v + '년' : v === NONE && k === 'category' ? NO_CATEGORY : v, f[k])).join('') + '</select></label>').join('');
    // a row without a 분류 (never chosen on this page) takes the one chosen in its draft's 청중·분량, once
    for (const r of all) {
      const c = r.category == null && !r.categoryBy ? settingOfRow(r)?.category : null;
      if (c && c !== NONE && C('category').options.includes(c) && !copied.has(r.id)) { copied.add(r.id); r.category = c; saveRow({ ...r, category: c }); return; }
    }
    const shown = sortRows(filterRows(all, f));
    const n = shown.reduce((k, r) => k + (r.preached || []).length, 0);
    $('#past-count').textContent = all.length ? '설교 ' + shown.length + '편' + (shown.length !== all.length ? ' (전체 ' + all.length + '편)' : '') + ' · 설교한 기록 ' + n + '번' : '';
    const box = $('#past-list');
    if (!S.col) box.innerHTML = '<li class="empty">지난 설교 목록은 Claude에 로그인해야 볼 수 있어요.</li>';
    else if (!all.length) box.innerHTML = '<li class="empty">아직 지난 설교가 없어요. 설교준비 스킬로 설교 페이지를 게시하면 여기에 한 줄씩 늘어나요.</li>';
    else if (!shown.length) box.innerHTML = '<li class="empty">고른 조건에 맞는 설교가 없어요.</li>';
    else {
      const kept = document.activeElement && document.activeElement.matches('#past-list .row-link') ? document.activeElement.closest('[data-row]').dataset.row : null;
      box.innerHTML = shown.map(rowHtml).join('');
      if (kept) { const l = $('#past-list [data-row="' + kept + '"] .row-link'); if (l) l.focus(); } // drawn again under the focus (a save came back)
    }
    renderCriteria(cs);
  }
  /** The draft a row was finished from: row.draftId, else a finished draft on the same passage. */
  const draftOfRow = (r) => (r.draftId && S.docs.get(DOC.draft(r.draftId))) || allDrafts().find((d) => d.finished && d.ref && rowIdOf(d.ref) === r.id) || null;
  function rowHtml(r) {
    const c = r.counts && typeof r.counts === 'object' ? r.counts : {};
    const k = num(c.unverified);
    const d = draftOfRow(r);
    const url = d ? '#past/' + encodeURIComponent(r.id) : safeUrl(r.url);
    const head = '<span class="t">' + esc(r.title || r.passageLabel || r.id) + '</span><span class="sub"><span>' + esc(r.passageLabel) + '</span><span class="chip">' + esc(r.category || NO_CATEGORY) + '</span><span>준비한 날 ' + esc(String(r.preparedAt || '').slice(0, 10)) + '</span>' + (d && d.finished ? '<span>마무리한 날 ' + esc(localDay(d.finished)) + '</span>' : '') + '<span class="cnt">확인된 출처 ' + num(c.sourced) + ' · 성경 구절 ' + num(c.bible) + ' · ' + (k ? '<span class="k">확인 필요 ' + k + '</span>' : '확인 필요 0') + '</span></span>';
    const recsHtml = (r.preached || []).map((p, i) => '<li>' + esc([p.date, p.service, p.place].filter(Boolean).join(' · ')) + ' <button type="button" class="linkbtn" data-rec-del="' + esc(r.id) + '" data-i="' + i + '" aria-label="이 기록 지우기">지우기</button></li>').join('');
    return '<li class="row-item past" data-row="' + esc(r.id) + '"><div class="row-main">' + (d ? '<a class="row-link" href="' + esc(url) + '">' + head + '</a>' : url ? '<a class="row-link" href="' + esc(url) + '" target="_blank" rel="noopener">' + head + '</a>' : '<div class="row-link" tabindex="-1">' + head + '</div>') + '</div>'
      + '<div class="row-recs"><p class="note">' + esc(C('date').name) + ' · ' + esc(C('service').name) + ' · ' + esc(C('place').name) + '</p><ul class="recs">' + (recsHtml || '<li class="note">아직 기록이 없어요.</li>') + '</ul>'
      + '<details class="rec-add"><summary>설교한 기록 더하기 · ' + esc(C('category').name) + ' 바꾸기</summary>' + recForm(r) + '</details></div></li>';
  }
  /** The 청중·분량 of the newest draft on this row's passage (the row id is the passage's reader code, chapter, verses). */
  const settingOfRow = (r) => allDrafts().find((d) => d.setting && d.ref && rowIdOf(d.ref) === r.id)?.setting || null;
  // the first 설교한 날 record starts from the draft's 예배 and 장소·대상 (a typed 장소 goes to 직접 입력)
  function recForm(r) {
    const st = (r.preached || []).length ? null : settingOfRow(r);
    const pre = (key) => { const v = st && filled(st[key]) ? st[key] : ''; return !v || C(key).options.includes(v) ? { v, other: '' } : C(key).options.includes(OTHER) ? { v: OTHER, other: v } : { v: '', other: '' }; };
    const sel = (key) => '<select data-rec="' + key + '">' + '<option value="">' + esc(C(key).name) + ' 고르기</option>' + C(key).options.map((o) => '<option' + (o === pre(key).v ? ' selected' : '') + '>' + esc(o) + '</option>').join('') + '</select>';
    const pl = pre('place');
    return '<div class="rec-form" data-row="' + esc(r.id) + '"><label><span>' + esc(C('date').name) + '</span><input type="date" data-rec="date"></label><label><span>' + esc(C('service').name) + '</span>' + sel('service') + '</label><label><span>' + esc(C('place').name) + '</span>' + sel('place') + '</label><label class="other"' + (pl.v === OTHER ? '' : ' hidden') + '><span>직접 입력</span><input data-rec="other" maxlength="40" value="' + esc(pl.other) + '"></label><button type="button" class="btn" data-rec-save>기록 저장</button>'
      + '<label><span>' + esc(C('category').name) + '</span><select data-cat="' + esc(r.id) + '">' + [...C('category').options, NONE].map((o) => '<option value="' + esc(o) + '"' + ((r.category || NONE) === o ? ' selected' : '') + '>' + esc(o === NONE ? NO_CATEGORY : o) + '</option>').join('') + '</select></label></div>';
  }
  $('#past-filters').addEventListener('change', (e) => { const s = e.target.closest('[data-filter]'); if (s) { S.filter[s.dataset.filter] = s.value; renderPast(); } });
  $('#past-list').addEventListener('change', (e) => {
    const cat = e.target.closest('[data-cat]');
    if (cat) { const r = rows().find((x) => x.id === cat.dataset.cat); saveRow({ ...r, category: cat.value === NONE ? null : cat.value, categoryBy: 'user' }); return; }
    const pl = e.target.closest('[data-rec="place"]');
    if (pl) $('.other', pl.closest('.rec-form')).hidden = pl.value !== OTHER;
  });
  $('#past-list').addEventListener('click', (e) => {
    const sv = e.target.closest('[data-rec-save]');
    const del = e.target.closest('[data-rec-del]');
    if (sv) {
      const f = sv.closest('.rec-form');
      const get = (k) => $('[data-rec="' + k + '"]', f).value.trim();
      const place = get('place') === OTHER ? get('other') : get('place');
      if (!get('date')) { status(C('date').name + '을 골라 주세요.'); return; }
      const r = rows().find((x) => x.id === f.dataset.row);
      saveRow({ ...r, preached: [...(r.preached || []), { date: get('date'), service: get('service') || null, place: place || null }] });
    } else if (del) {
      const r = rows().find((x) => x.id === del.dataset.recDel);
      saveRow({ ...r, preached: (r.preached || []).filter((_, i) => i !== Number(del.dataset.i)) });
    }
  });
  const copied = new Set();
  function saveRow(r) {
    const { id, ...data } = r;
    S.docs.set(DOC.sermon(id), data);
    renderPast();
    return save(DOC.sermon(id), data);
  }

  // criteria editor: rename a criterion, add / rename / remove values (renaming a value updates the rows using it)
  function renderCriteria(cs) {
    const box = $('#crit-list');
    if (box.contains(document.activeElement)) return; // do not redraw under the cursor
    box.innerHTML = cs.criteria.map((c) => '<li class="crit"><label><span class="note">기준 이름</span><input data-crit-name="' + c.key + '" value="' + esc(c.name) + '" maxlength="40"></label>'
      + (c.options ? '<ul class="opts">' + c.options.map((o, i) => '<li><label class="sr" for="o-' + c.key + '-' + i + '">' + esc(c.name) + ' 값 ' + (i + 1) + '</label><input id="o-' + c.key + '-' + i + '" data-opt="' + c.key + '" data-i="' + i + '" value="' + esc(o) + '" maxlength="40"><button type="button" class="btn icon" data-opt-del="' + c.key + '" data-i="' + i + '" aria-label="' + esc(o) + ' 지우기">×</button></li>').join('') + '</ul><div class="opt-add"><label class="sr" for="add-' + c.key + '">' + esc(c.name) + '에 값 더하기</label><input id="add-' + c.key + '" data-opt-new="' + c.key + '" placeholder="새 값" maxlength="40"><button type="button" class="btn" data-opt-add="' + c.key + '">더하기</button></div>' : '<p class="note">날짜로 기록해요.</p>') + '</li>').join('');
  }
  function saveCriteria(next) {
    S.docs.set(DOC.settings, next);
    save(DOC.settings, next);
  }
  const critDraft = () => JSON.parse(JSON.stringify(crit()));
  $('#crit-list').addEventListener('change', (e) => {
    const nm = e.target.closest('[data-crit-name]');
    const op = e.target.closest('[data-opt]');
    if (!nm && !op) return; // the 'new value' field waits for its button
    const cs = critDraft();
    if (nm) {
      const c = cs.criteria.find((x) => x.key === nm.dataset.critName);
      if (!nm.value.trim()) { nm.value = c.name; return; }
      c.name = nm.value.trim();
      saveCriteria(cs);
    } else if (op) {
      const c = cs.criteria.find((x) => x.key === op.dataset.opt);
      const i = Number(op.dataset.i), from = c.options[i], to = op.value.trim();
      if (!to || c.options.includes(to)) { op.value = from; status(!to ? '빈 값은 쓸 수 없어요.' : '같은 값이 이미 있어요.'); return; }
      c.options[i] = to;
      saveCriteria(cs);
      for (const ch of renameValue(rows(), c.key, from, to)) saveRow(ch.row); // rows that used the old value
      if (S.filter[c.key] === from) S.filter[c.key] = to;
    }
    document.activeElement.blur && document.activeElement.blur();
    renderPast();
  });
  $('#crit-list').addEventListener('click', async (e) => {
    const add = e.target.closest('[data-opt-add]');
    const del = e.target.closest('[data-opt-del]');
    const cs = critDraft();
    if (add) {
      const c = cs.criteria.find((x) => x.key === add.dataset.optAdd);
      const inp = $('[data-opt-new="' + c.key + '"]');
      const v = inp.value.trim();
      if (!v || c.options.includes(v)) { status(!v ? '새 값을 적어 주세요.' : '같은 값이 이미 있어요.'); return; }
      c.options.push(v);
      saveCriteria(cs);
      inp.value = '';
      inp.blur();
      renderPast();
    } else if (del) {
      const c = cs.criteria.find((x) => x.key === del.dataset.optDel);
      const v = c.options[Number(del.dataset.i)];
      const n = usesOf(rows(), c.key, v);
      if (n && !(await askUser({ title: "'" + v + "' 값을 지울까요?", text: "'" + v + "'을 쓰는 설교 " + n + '편은 이 값이 비워져요.', ok: '지우기' }))) return;
      c.options.splice(Number(del.dataset.i), 1);
      saveCriteria(cs);
      for (const ch of renameValue(rows(), c.key, v, null)) saveRow(ch.row);
      if (S.filter[c.key] === v) S.filter[c.key] = '';
      renderPast();
    }
  });

  // ---------------------------------------------------------------- 내 문체 (owner 2026-10-27)
  // The sermons live only in memory here (S.styleItems) until the analysis is done; only the derived style is saved.
  const curStyle = () => styleOn(S.docs.get(DOC.style));
  const styleSay = (t) => { $('#style-status').textContent = t || ''; };
  S.styleItems = [];
  S.styleLater = false; // 나중에: hidden for this load only
  S.styleRedo = false; // 다시 분석하기: the upload box again over the profile
  let pasted = 0;
  function saveStyle(next) {
    S.docs.set(DOC.style, next);
    save(DOC.style, next);
  }
  function renderStyleCard() {
    const doc = S.docs.get(DOC.style);
    $('#style-card').hidden = !(S.loaded && S.col && screen() === 'passage' && !S.final && !doc?.style && !doc?.dismissed && !S.styleLater);
  }
  $('#btn-style-later').addEventListener('click', () => { S.styleLater = true; renderStyleCard(); });
  $('#btn-style-never').addEventListener('click', () => { saveStyle({ ...(S.docs.get(DOC.style) || {}), kind: 'settings', dismissed: true }); renderStyleCard(); });
  function styleGate() {
    const plan = analysisPlan(S.styleItems.map((x) => x.text));
    $('#btn-style-run').disabled = !!plan.error || !S.col || !!S.aiBusy || S.aiOff;
  }
  const styleFrom = (doc) => '설교문 ' + (doc.from?.count ?? 0) + '편(' + (doc.from?.chars ?? 0).toLocaleString('en-US') + '자)에서 읽었어요' + (doc.userEdited ? ' · 고치신 내용이 있어요' : '') + '. 고치고 싶은 칸은 바로 고쳐 주세요.';
  function renderStyle() {
    const doc = S.docs.get(DOC.style);
    const has = !!doc?.style;
    $('#style-login').hidden = !S.noDb;
    $('#style-input').hidden = has && !S.styleRedo;
    $('#btn-style-cancel').hidden = !(has && S.styleRedo) || !!styleRun.ring && styleRun.ring.state === 'run';
    $('#style-files').innerHTML = S.styleItems.map((x, i) => '<li><span class="sf-name">' + esc(x.name) + '</span> <span class="note">' + x.text.length.toLocaleString('en-US') + '자' + (x.cut ? ' (앞 ' + STYLE_CHARS.toLocaleString('en-US') + '자만 읽어요)' : '') + '</span> <button type="button" class="linkbtn" data-style-del="' + i + '" aria-label="' + esc(x.name) + ' 빼기">빼기</button></li>').join('');
    if (S.aiOff) styleSay('이 화면에서는 AI를 쓸 수 없어서 스타일을 익힐 수 없어요.');
    styleGate();
    renderStyleRing();
    $('#style-profile').hidden = !has;
    if (!has) return;
    $('#style-from').textContent = styleFrom(doc);
    $('#style-on').checked = doc.enabled !== false;
    const box = $('#style-fields');
    if (box.contains(document.activeElement)) return; // do not redraw under the cursor
    box.innerHTML = STYLE_FIELDS.map((F) => {
      const v = doc.style[F.f];
      const val = F.list ? (Array.isArray(v) ? v.join('\n') : '') : (v || '');
      return '<div class="style-field"><label for="sf-' + F.f + '">' + esc(F.label) + (F.list ? ' <span class="note">한 줄에 하나씩</span>' : '') + '</label><textarea id="sf-' + F.f + '" data-style-f="' + F.f + '" rows="' + (F.list ? Math.min(Math.max((Array.isArray(v) ? v.length : 0) + 1, 3), 8) : F.f === 'summary' ? 4 : 2) + '">' + esc(val) + '</textarea></div>';
    }).join('');
  }
  function addStyleItem(name, text) {
    if (S.styleItems.length >= STYLE_MAX) { styleSay('설교문은 ' + STYLE_MAX + '편까지 올릴 수 있어요.'); return false; }
    const it = styleItem(name, text);
    if (!it.text) { styleSay(it.name + ': 읽을 글이 없어요.'); return false; }
    S.styleItems.push(it);
    styleSay(it.cut ? it.name + ': 앞 ' + STYLE_CHARS.toLocaleString('en-US') + '자만 읽어요.' : '');
    return true;
  }
  $('#btn-style-add').addEventListener('click', () => {
    const ta = $('#style-paste');
    if (!ta.value.trim()) { styleSay('설교문을 붙여 넣어 주세요.'); ta.focus(); return; }
    if (addStyleItem('붙여 넣은 설교문 ' + (++pasted), ta.value)) ta.value = '';
    renderStyle();
  });
  // .docx is read with mammoth from cdnjs, loaded only when a .docx is chosen (pinned version, integrity checked)
  const MAMMOTH = { src: 'https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.8.0/mammoth.browser.min.js', sri: 'sha512-wuWo/cLB9W5BsZeyTYLuiTwr+FDlvjQC7C6atr+To7Jk92XHWI7WsImJZiruw7C9bnc8Zg7N0ncQI2Q/B4PQYw==' };
  let mammothP = null;
  function loadMammoth() {
    if (window.mammoth) return Promise.resolve(window.mammoth);
    return mammothP || (mammothP = new Promise((res, rej) => {
      const el = document.createElement('script');
      el.src = MAMMOTH.src; el.integrity = MAMMOTH.sri; el.crossOrigin = 'anonymous'; el.referrerPolicy = 'no-referrer';
      el.onload = () => (window.mammoth ? res(window.mammoth) : rej(new Error('mammoth')));
      el.onerror = () => { mammothP = null; rej(new Error('load')); };
      document.head.appendChild(el);
    }));
  }
  // .pdf is read with pdf.js from cdnjs, loaded only when a PDF is chosen (pinned version); .hwp / .hwpx are read here (docs.mjs)
  const PDFJS = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/4.10.38/';
  let pdfP = null;
  function loadPdf() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    return pdfP || (pdfP = import(PDFJS + 'pdf.min.mjs').then((m) => { m.GlobalWorkerOptions.workerSrc = PDFJS + 'pdf.worker.min.mjs'; return m; }, () => { pdfP = null; throw new Error('load'); }));
  }
  const COPY = ' 글을 복사해 붙여 주세요.';
  $('#style-file').addEventListener('change', async (e) => {
    for (const f of [...e.target.files]) {
      const ext = (f.name.split('.').pop() || '').toLowerCase();
      let text, pagesCut = false;
      try {
        if (ext === 'txt' || ext === 'md') text = await f.text();
        else if (ext === 'docx') text = (await (await loadMammoth()).extractRawText({ arrayBuffer: await f.arrayBuffer() })).value;
        else if (ext === 'pdf' || ext === 'hwp' || ext === 'hwpx') {
          styleSay(f.name + ': 읽는 중…');
          const bytes = new Uint8Array(await f.arrayBuffer());
          if (ext === 'pdf') {
            const r = await pdfText(await loadPdf(), bytes);
            if (nonSpace(r.text) < 50) { styleSay(f.name + ': 글자가 없는 PDF(스캔한 이미지)라 읽지 못해요.' + COPY); continue; }
            text = r.text; pagesCut = r.cut;
          } else {
            const r = ext === 'hwp' ? await hwpText(bytes) : { text: await hwpxText(bytes) };
            if (r.locked) { styleSay(f.name + ': 암호나 배포용 보안이 걸린 한글 파일은 읽지 못해요. 한글에서 보안을 풀거나 HWPX로 저장해 다시 올려 주세요.'); continue; }
            if (!r.text.trim()) { styleSay(f.name + ': 글을 찾지 못했어요.' + COPY); continue; }
            text = r.text;
          }
        }
        else { styleSay(f.name + ': .txt, .md, .docx, .pdf, .hwp, .hwpx 파일만 읽어요.'); continue; }
      } catch (err) { styleSay(err && err.message === 'load' ? '파일 읽는 도구를 불러오지 못했어요. 인터넷 연결을 확인해 주세요.' : f.name + '을 읽지 못했어요.' + COPY); continue; }
      if (!addStyleItem(f.name, text)) break;
      if (pagesCut) styleSay(f.name + ': 앞 ' + PDF_PAGES + '쪽만 읽어요.' + (S.styleItems[S.styleItems.length - 1].cut ? ' 그중 앞 ' + STYLE_CHARS.toLocaleString('en-US') + '자만 읽어요.' : ''));
    }
    e.target.value = '';
    renderStyle();
  });
  $('#style-files').addEventListener('click', (e) => {
    const b = e.target.closest('[data-style-del]');
    if (!b) return;
    S.styleItems.splice(Number(b.dataset.styleDel), 1);
    styleSay('');
    renderStyle();
  });
  // the ring over all calls: each call one share, its streamed length against STYLE_EXPECTED
  const styleRun = { ring: null, t0: 0, timer: 0, why: '', n: 1, at: 0 };
  function styleRing(ev, x) {
    const r = styleRun.ring;
    if (ev === 'start') { styleRun.n = x; styleRun.at = 0; styleRun.ring = { pct: 0, stage: 'think', state: 'run' }; styleRun.t0 = Date.now(); styleRun.why = ''; clearInterval(styleRun.timer); styleRun.timer = setInterval(renderStyleRing, 1000); }
    else if (!r || r.state !== 'run') return;
    else if (ev === 'text') styleRun.ring = { ...r, pct: Math.max(r.pct, Math.min(99, Math.floor(((styleRun.at + ringPctOf(x, STYLE_EXPECTED) / 100) / styleRun.n) * 100))), stage: 'read' };
    else if (ev === 'next') { styleRun.at += 1; styleRun.ring = { ...r, pct: Math.max(r.pct, Math.min(99, Math.floor((styleRun.at / styleRun.n) * 100))), stage: 'think' }; }
    else { styleRun.ring = { ...r, pct: ev === 'done' ? 100 : r.pct, state: ev }; clearInterval(styleRun.timer); styleRun.timer = 0; styleRun.why = ev === 'fail' ? $('#ai-status').textContent : ''; }
    renderStyleRing();
  }
  function renderStyleRing() {
    const r = styleRun.ring;
    $('#style-progress').hidden = !r;
    $('#btn-style-stop').hidden = !(r && r.state === 'run');
    if (!r) return;
    const pct = Math.floor(r.pct);
    $('#style-ring-bar').setAttribute('aria-valuenow', String(pct));
    $('#style-ring-num').textContent = pct + '%';
    $('#style-ring-fill').style.strokeDashoffset = String(100 - pct);
    $('#style-ring').dataset.state = r.state;
    const merge = styleRun.n > 1 && styleRun.at === styleRun.n - 1;
    const doing = styleRun.n === 1 ? '스타일을 익히는 중' : merge ? '하나로 합치는 중' : '설교문 ' + (styleRun.at + 1) + '/' + (styleRun.n - 1) + ' 읽는 중';
    $('#style-ring-stage').textContent = r.state === 'done' ? '스타일을 다 익혔어요' : r.state === 'fail' ? '여기서 멈췄어요' : doing + '…';
    $('#style-ring-wait').textContent = r.state === 'run' ? elapsedKo(Date.now() - styleRun.t0) : styleRun.why;
  }
  $('#btn-style-stop').addEventListener('click', () => { if (S.aiBusy) S.aiBusy.abort(); });
  async function runStyle() {
    const items = S.styleItems.slice();
    const plan = analysisPlan(items.map((x) => x.text));
    if (plan.error) { styleSay(plan.error); return; }
    styleSay('');
    styleRing('start', plan.calls.length);
    renderStyle();
    const texts = items.map((x) => x.text);
    const parts = [];
    for (const call of plan.calls) {
      const v = await ask(call.kind === 'merge' ? promptStyleMerge(parts) : promptStyle(call.items.map((i) => items[i])), { onText: ({ text }) => styleRing('text', text.length) });
      if (v === undefined) { styleRing('fail'); renderStyle(); return; }
      const st = checkStyle(v, texts);
      if (!st) { aiStatus('스타일을 정해진 모양으로 익히지 못했어요. 내 스타일 익히기를 다시 눌러 주세요.'); styleRing('fail'); renderStyle(); return; }
      parts.push(st);
      styleRing('next');
    }
    saveStyle(styleDoc(parts[parts.length - 1], items));
    S.styleItems = []; // the sermons are not kept
    S.styleRedo = false;
    styleRing('done');
    renderStyle();
    renderStyleCard();
    $('#style-saved').textContent = STYLE_NAME + '을 저장했어요. 원고를 쓸 때 따라요.';
  }
  $('#btn-style-run').addEventListener('click', () => runStyle());
  $('#btn-style-again').addEventListener('click', () => { S.styleRedo = true; styleRun.ring = null; renderStyle(); $('#style-paste').focus(); });
  $('#btn-style-cancel').addEventListener('click', () => { S.styleRedo = false; S.styleItems = []; styleRun.ring = null; styleSay(''); renderStyle(); });
  $('#style-on').addEventListener('change', (e) => {
    const doc = S.docs.get(DOC.style);
    if (!doc?.style) return;
    saveStyle({ ...doc, enabled: e.target.checked });
    $('#style-saved').textContent = e.target.checked ? '원고를 쓸 때 ' + STYLE_NAME + '을 따라요.' : '원고를 쓸 때 ' + STYLE_NAME + '을 따르지 않아요.';
  });
  $('#style-fields').addEventListener('change', (e) => {
    const t = e.target.closest('[data-style-f]');
    const doc = S.docs.get(DOC.style);
    if (!t || !doc?.style) return;
    const F = STYLE_FIELDS.find((x) => x.f === t.dataset.styleF);
    const next = checkStyle({ style: { ...doc.style, [F.f]: F.list ? t.value.split('\n') : t.value } });
    if (!next) { $('#style-saved').textContent = '저장하지 못했어요. 한마디로 칸은 비울 수 없고, 인터넷 주소는 넣을 수 없어요.'; return; }
    saveStyle({ ...doc, style: next, userEdited: true });
    $('#style-saved').textContent = F.label + ' 칸을 저장했어요.';
    $('#style-from').textContent = styleFrom(S.docs.get(DOC.style));
  });

  // ---------------------------------------------------------------- capabilities (design for absence)
  renderAll();
  renderDrafts();
  renderPast();
  if (stepOfHash((location.hash || '').slice(1)) || location.hash.startsWith('#past/')) fromHash(); else show(VIEWS.includes((location.hash || '').slice(1)) ? location.hash.slice(1) : 'start');
  (async () => {
    const [db, user] = await Promise.all([use('db'), use('user')]);
    const uid = user ? await Promise.resolve(user.id()).catch(() => null) : null;
    if (!db || !uid) { status('로그인하면 쓰는 내용이 저장돼요. 지금은 이 화면에서만 보여요.'); S.noDb = true; renderStyle(); return; }
    S.uid = uid;
    S.db = db;
    // the viewer's own private collection: nobody else (the page owner included) can read it
    S.col = db.collection('data/users/' + uid);
    try {
      S.col.onSnapshot(
        (snap) => {
          let macMoved = false, remote = false;
          S.docs.clear();
          snap.docs.forEach((d) => {
            if (!d.exists || !kindOf(d.id)) return;
            const v = d.data();
            S.docs.set(d.id, v);
            // the skills on the computer move 출처 확인: follow them on the open draft
            if (d.id === DOC.draft(S.draft.id) && JSON.stringify(v.mac) !== JSON.stringify(S.draft.mac)) { if (v.mac === undefined) delete S.draft.mac; else S.draft.mac = v.mac; macMoved = true; }
            // another window changed the open draft (not just mac, not this page's own write): take it
            if (d.id === DOC.draft(S.draft.id) && written.has(d.id) && !inflight.has(d.id) && newerRemote(S.base, v.updatedAt) && otherThanMac(written.get(d.id), v)) remote = true;
            if (!inflight.has(d.id)) { const { updatedAt: _u, ...same } = v; written.set(d.id, canon(same)); }
          });
          if (remote) { S.remoteWaiting = true; tryAdopt(); }
          renderDrafts();
          renderPast();
          S.loaded = true;
          renderStyleCard();
          renderStyle();
          if (macMoved) { renderSteps(); renderSources(); }
        },
        () => status('저장된 내용을 불러오지 못했어요. 잠시 뒤 다시 열어 주세요.'),
      );
    } catch (e) {
      status('저장된 내용을 불러오지 못했어요.');
    }
    renderDrafts();
    renderPast();
  })();
  (async () => { const s = await use('sample'); if (!s) setAiOff(); else S.sample = s; })();
})();
