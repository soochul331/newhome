#!/usr/bin/env node
// '설교준비 도우미' 페이지 렌더러 (예전 '지난 설교' 허브 자리) — Node 18 이상, 다른 패키지 없음.
//   node render-hub.mjs [out.html]          → 기본 sermons/hub.html
// 페이지에는 누구의 설교도 들어가지 않는다. 보는 사람마다 자기 db 칸(data/users/<id>)을 읽고 쓴다(claude.use).
// 성경 책 이름·장별 절 수는 sermon-sources/scripts/bible.json을 그대로 넣는다(본문 주소 확인용, 성경 본문은 없음).
// 같은 입력이면 바이트까지 같은 HTML(시각·난수 없음).

import { readFileSync, writeFileSync, realpathSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const read = (...p) => readFileSync(join(HERE, ...p), 'utf8');
import { stepsHtml, stepProgress, newDraft, REVIEW_NOTE, WORK, WORK_KEYS, MS_NOTICE, SYNC_BUTTON, FINISH_BUTTON, REQ_LABEL, REQ_BUTTON, REQ_TEXT_MAX, STYLE_NAME, STYLE_MIN, STYLE_MAX, STYLE_CHARS } from '../template/core.mjs';

const jsonForScript = (v) => JSON.stringify(v).replace(/</g, '\\u003c').replace(/>/g, '\\u003e').replace(/&/g, '\\u0026');

export const TITLE = '설교준비 도우미(©Church AI Lab)';
// Always rendered after </main>, in every view; there is no option to leave it out (owner 2026-10-30).
export const COPYRIGHT = '© 2026 Church AI Lab';
const WORK_NOTE = {
  exegesis: '본문연구 작성하기를 누르면 본문을 절 묶음으로 나눠 풀이한 본문연구 하나를 써서 먼저 읽기 좋게 보여 드려요. 주석 도구가 연결된 Claude 앱에서는 목사님 서재의 주석과 온라인 주석을 먼저 읽고, 확인된 인용을 주석 메모로 함께 적어요.',
  illustration: '예화 만들기를 누르면 개요·본문연구·청중을 바탕으로 예화 3~4개(성경 인물 예화와 생활 이야기)를 써서 보여 드려요. 직접 적거나 고치고, 필요 없는 예화는 뺄 수 있어요. 여기서 만든 예화가 원고 초안의 정한 자리에 들어가요.',
  application: '적용 만들기를 누르면 이번 주에 해 볼 구체적인 적용 2~3개를 써서 보여 드려요. 직접 적거나 고치고, 뺄 수도 있어요. 여기서 만든 적용이 원고 초안에 들어가요.',
  manuscript: '초안 작성하기를 누르면 개요의 한 문장 메시지와 네 부분(도입·전개·절정·결말)을 따라 청중·분량에서 정한 길이의 원고 초안을 써서 먼저 읽기 좋게 보여 드려요.',
};
const PREV = { exegesis: 'outline', illustration: 'setting', application: 'illustration', manuscript: 'application' };
const LIST_STEP = (k) => k === 'illustration' || k === 'application';
// 원고 초안: the 청중·분량 line above 초안 작성하기, and the ring while it is written (same ring as 출처 확인)
const MS_TOP = `<p class="ms-setting"><span id="ms-setting-text"></span> <button type="button" class="linkbtn" id="btn-ms-setting">바꾸기</button></p>
<p class="note" id="ms-ill-note" hidden>예화·적용을 먼저 만들어 두면 원고에 함께 들어가요.</p>
`;
// 이렇게 써 주세요 (REQ_LABEL): above 초안 작성하기 until there is a 원고, then under its parts (start.js moves it); the log below
const MS_REQ = `<div class="ms-req" id="ms-req" hidden>
<label for="ms-req-text">${REQ_LABEL}</label>
<p class="note" id="ms-req-hint"></p>
<textarea id="ms-req-text" rows="3" maxlength="${REQ_TEXT_MAX}" data-ai placeholder="예: 도입을 조금 짧게 하고, 결말에 청년들에게 하는 말을 한 문단 넣어 주세요."></textarea>
<div class="actions"><button type="button" class="btn" id="btn-ms-req" data-ai>${REQ_BUTTON}</button><button type="button" class="btn" id="btn-req-stop" hidden>멈추기</button><button type="button" class="linkbtn" id="btn-ms-undo" hidden>되돌리기</button></div>
<p class="note" id="ms-req-status" aria-live="polite"></p>
<ol class="req-log" id="ms-req-log" aria-label="요청과 반영 기록" hidden></ol>
</div>
`;
const MS_RING = `<div class="src-progress ms-progress" id="ms-progress" hidden>
<div class="src-ring" id="ms-ring"><div class="ring" id="ms-ring-bar" role="progressbar" aria-label="원고 작성 진행률" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="ring-track" cx="50" cy="50" r="44"/><circle class="ring-fill" id="ms-ring-fill" cx="50" cy="50" r="44" pathLength="100"/></svg><span class="ring-num" id="ms-ring-num" aria-hidden="true">0%</span></div><p class="ring-stage" id="ms-ring-stage" aria-live="polite"></p><p class="ring-wait" id="ms-ring-wait"></p></div>
</div>
`;
// 바뀐 내용 반영하기: start.js puts it right above the parts (under the notice) when an earlier step changed after the 원고 초안
const MS_SYNC = `<div class="ms-sync" id="ms-sync" hidden>
<p class="ms-sync-text" id="ms-sync-text"></p>
<div class="actions"><button type="button" class="btn" id="btn-ms-sync" data-ai>${SYNC_BUTTON}</button><button type="button" class="btn" id="btn-sync-stop" hidden>멈추기</button></div>
</div>
`;
// 만들어 둔 예화 (older drafts): start.js puts it under the parts, above 이렇게 써 주세요
/** 6 청중·분량: who hears the sermon and how long it is (no AI); the pickers are the 지난 설교 criteria. */
const SET_PICK = (k) => `<div class="set-pick"><label for="set-${k}" id="set-${k}-name"></label><select id="set-${k}" data-set="${k}"></select>
<div class="set-other" id="set-${k}-other-row" hidden><label for="set-${k}-other">직접 입력</label><input id="set-${k}-other" data-set-other="${k}" maxlength="40"></div></div>`;
const SETTING = `<section class="step" id="step-setting" hidden aria-labelledby="setting-h">
<h2 id="setting-h" tabindex="-1">청중·분량</h2>
<p class="note">누구에게, 얼마나 길게 전할 설교인지 정해 주세요. 원고 초안을 이에 맞춰 써 드려요. 고른 예배·장소·분류는 지난 설교 목록에서도 그대로 쓸 수 있어요.</p>
<div class="set-picks">${['service', 'place', 'category'].map(SET_PICK).join('')}</div>
<label for="set-audience">듣는 사람들 <span class="note">연령·상황·신앙 정도</span></label>
<textarea id="set-audience" rows="3" placeholder="예: 40~60대 직장인이 많고, 오래 신앙생활을 한 분이 대부분이에요."></textarea>
<fieldset class="set-len"><legend>분량</legend>
<div class="set-len-row"><label for="set-minutes">설교 시간(분)</label><input id="set-minutes" type="number" inputmode="numeric" min="1" max="120" step="1"></div>
<div class="set-len-row"><label for="set-chars">글자 수(공백 빼고)</label><input id="set-chars" type="number" inputmode="numeric" min="1" step="10"></div>
<p class="note" id="set-len-note" aria-live="polite"></p>
</fieldset>
<div class="actions"><button type="button" class="btn primary" id="btn-set-next">다음 단계로</button></div>
<div class="actions back-row"><button type="button" class="btn" data-back="exegesis">이전 단계</button></div>
</section>`;
// 7 예화: 시사 예화 찾기 (news, with the tool on the computer); the note says when the search keys are missing
const ILL_NEWS = `<div class="ill-news" id="ill-news" hidden>
<p class="note">최근 2년 안의 기사에서 설교에 맞는 장면을 찾아 시사 예화로 더해요. 기사에 있는 사실만 쓰고, 인용은 기사에서 확인해요.</p>
<div class="actions"><button type="button" class="btn" id="btn-ill-news" data-ai>시사 예화 찾기</button></div>
<p class="note" id="ill-news-note" aria-live="polite"></p>
</div>
`;
// 본문연구 with the commentary tool: the stages of reading the commentaries first, under 본문연구 작성하기
const EX_RUN = `<div class="ex-run" id="ex-run" hidden>
<ol class="src-steps" id="ex-steps" aria-label="본문연구 진행"></ol>
<div class="actions"><button type="button" class="btn" id="btn-ex-stop" hidden>멈추기</button></div>
<p class="note" id="ex-summary" aria-live="polite"></p>
</div>
`;
/** One in-page step after 개요: write one result, read it, choose a part to edit, go on (same as 개요). */
const workStep = (k) => {
  const L = WORK[k].label;
  return `<section class="step work-step" id="step-${k}" hidden aria-labelledby="${k}-h">
<h2 id="${k}-h" tabindex="-1">${L}</h2>
${k === 'manuscript' ? `<p class="note ms-notice">${MS_NOTICE}</p>
` : ''}<p class="review-note" id="${k}-review" hidden>${REVIEW_NOTE}</p>
<p class="note">${WORK_NOTE[k]}</p>
<p class="mac-note" id="w-${k}-mac" hidden>이 단계는 컴퓨터에서 마쳤어요. 내용은 설교 페이지에 있어요. <span id="w-${k}-mac-page"></span></p>
${k === 'manuscript' ? MS_TOP + MS_REQ : ''}<div class="actions"><button type="button" class="btn primary" id="btn-w-${k}" data-ai data-write="${k}">${WORK[k].write}</button>${k === 'manuscript' ? '<button type="button" class="btn" id="btn-ms-stop" hidden>멈추기</button>' : ''}${LIST_STEP(k) ? `<button type="button" class="btn" id="btn-w-${k}-manual">직접 적기</button><button type="button" class="linkbtn" id="btn-w-${k}-skip">건너뛰고 다음 단계로</button>` : ''}</div>
${k === 'manuscript' ? MS_RING + MS_SYNC : ''}${k === 'exegesis' ? EX_RUN : ''}<div class="ol-view" id="w-${k}" hidden>
<article class="ol-read" aria-labelledby="w-${k}-h"><h3 class="ol-read-h" id="w-${k}-h" tabindex="-1">${L}</h3><div id="w-${k}-read"></div></article>
${k === 'manuscript' ? `<div class="fn-list" id="w-ms-fns-box" role="region" aria-labelledby="w-ms-fns-h" hidden><h3 id="w-ms-fns-h">각주</h3><ol id="w-ms-fns"></ol></div>
` : ''}
<div class="ol-ask" id="w-${k}-ask">
<p class="ol-ask-q">이대로 좋으세요? 고치고 싶은 부분이 있으면 골라 주세요.</p>
<div class="part-choices" role="group" aria-label="고칠 부분" id="w-${k}-parts"></div>
${LIST_STEP(k) ? `<p class="list-add"><button type="button" class="linkbtn" id="btn-w-${k}-add">+ ${WORK[k].add}</button></p>
` : ''}<p class="note warn" id="w-${k}-problems" aria-live="polite"></p>
<div class="actions"><button type="button" class="btn primary" id="btn-w-${k}-next">이대로 다음 단계로</button><button type="button" class="linkbtn" id="btn-w-${k}-rewrite" data-ai>${WORK[k].rewrite}</button></div>
</div>
</div>
${k === 'illustration' ? ILL_NEWS : ''}<div class="actions back-row"><button type="button" class="btn" data-back="${PREV[k]}">이전 단계</button></div>
</section>`;
};
export function renderStart() {
  const bible = JSON.parse(read('..', '..', '..', 'sermon-sources', 'scripts', 'bible.json'));
  const books = bible.books.map((b) => ({ id: b.id, name: b.name, abbrevs: b.abbrevs, code: b.code, chapters: b.chapters }));
  const core = read('..', 'template', 'core.mjs').replace(/^export /gm, '');
  const docs = read('..', 'template', 'docs.mjs').replace(/^export /gm, '');
  const steps = stepsHtml(stepProgress(newDraft('')));
  return `<title>${TITLE}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;600;700&amp;family=Noto+Serif+KR:wght@400;700&amp;display=swap">
<style>
${read('..', '..', 'template', 'style.css')}${read('..', 'template', 'start.css')}</style>
<div class="page ko" lang="ko">
<div class="start-shell">
<aside class="side">
<p class="brand">설교 준비</p>
<nav class="menu" aria-label="메뉴">
<a href="#start" aria-current="page">새 설교 시작</a>
<a href="#drafts">준비중인 설교 <span class="n" id="drafts-count"></span></a>
<ol class="steps side-steps" aria-label="준비 단계">${steps}</ol>
<hr>
<a href="#past">지난 설교 목록</a>
<hr>
<a href="#guide" class="menu-guide" data-view-link="guide">도움말 · 내 자료 연결하기</a>
<a href="#style" data-view-link="style">${STYLE_NAME}</a>
</nav>
</aside>
<main class="main">
<nav class="stepper" aria-label="준비 단계"><ol class="steps">${steps}</ol></nav>
<p class="note save" id="save-status" role="status" aria-live="polite"></p>

<section id="start-view" aria-labelledby="start-h">
<div class="hero">
<p class="eyebrow" id="draft-title">새 설교</p>
<h1 id="start-h">어떤 말씀을 전하실까요?</h1>
<p class="note">본문을 정하고, 그 본문을 먼저 묵상해 적어 주세요. 묵상에서 설교 방향과 개요, 원고 초안까지 이 페이지에서 이어져요.</p>
</div>

<aside class="creed" aria-labelledby="creed-h">
<p class="creed-h" id="creed-h">개혁주의 신앙고백을 기준으로 돕습니다</p>
<p>성경을 최종 권위로 삼고, 예장합동 헌법의 교리표준인 웨스트민스터 신앙고백과 대·소요리문답, 공교회 신경을 기준으로 합니다. 교리의 근거는 개혁주의 자료로만 달고, 이단·사이비 자료는 쓰지 않습니다.</p>
<details>
<summary>자세히</summary>
<ul>
<li><strong>기준</strong>: 성경(신앙과 생활의 최종 권위), 공교회 신경(사도신경·니케아 신경·칼케돈 신경), 예장합동 헌법의 교리표준(웨스트민스터 신앙고백·대요리문답·소요리문답).</li>
<li><strong>교리 근거</strong>: 교리와 본문 해석의 근거는 개혁주의 자료로만 답니다.</li>
<li><strong>다른 자료</strong>: 개혁주의가 아닌 정통 자료는 '비개혁주의 자료', 일반 자료는 '비기독교 자료'로 표시하고 사실·역사·원어·예화에만 씁니다.</li>
<li><strong>금지</strong>: 예장합동 총회가 이단·사이비로 결의한 단체·사람·매체의 자료는 어디에도 쓰지 않습니다.</li>
<li><strong>출처 확인(선택)</strong>: 원고에 쓴 사실과 성경 구절은 컴퓨터에 설치한 설교준비 스킬(Claude Code)이 같은 기준으로 하나하나 확인해 각주를 달아요.</li>
</ul>
</details>
</aside>

<header class="ref-head" id="ref-head" hidden>
<h1 id="ref-h" tabindex="-1"></h1>
<p class="ref-tools"><a class="bref" id="ref-link" href="#" target="_blank" rel="noopener">개역개정 읽기</a><button type="button" class="linkbtn" data-goto="passage" aria-label="설교 본문 고치기">본문 고치기</button></p>
</header>

<section class="summary" id="summary" hidden aria-labelledby="summary-h">
<p class="summary-h" id="summary-h">지금까지 고른 것</p>
<dl class="sum-list" id="summary-list"></dl>
</section>

<div class="composer" id="composer">
<div class="field">
<h2 class="field-h" id="step-passage-h" tabindex="-1"><label for="f-passage">설교 본문</label></h2>
<div class="input-row"><input id="f-passage" autocomplete="off" placeholder="예: 요한복음 15:1-11"><button type="button" class="btn" id="btn-recommend" data-ai aria-expanded="false" aria-controls="recommend-panel">본문 추천</button></div>
<p class="note parsed" id="passage-parsed" aria-live="polite"></p>
</div>
<div class="panel-in" id="recommend-panel" hidden>
<p class="note">전하고 싶은 메시지와 듣는 사람들의 상황을 적으면 본문 세 곳을 추천해 드려요.</p>
<label for="f-message">전하고 싶은 메시지</label>
<textarea id="f-message" rows="2" placeholder="예: 지친 성도에게 주님 안에 머무는 쉼"></textarea>
<label for="f-audience">듣는 사람들의 상황</label>
<textarea id="f-audience" rows="2" placeholder="예: 바쁜 직장인이 많은 장년 예배"></textarea>
<div class="actions"><button type="button" class="btn primary" id="btn-recommend-go" data-ai>추천받기</button></div>
<ul class="picks" id="recommend-list"></ul>
</div>
<p class="nudge" id="meditate-nudge" hidden>본문을 정하셨네요. 추천을 더 받기 전에, 먼저 본문을 천천히 읽고 마음에 닿은 것을 아래 '나의 묵상'에 적어 보세요.</p>
<div class="field">
<h2 class="field-h" id="step-seed-h" tabindex="-1"><label for="f-meditation" id="seed-label">나의 묵상</label></h2>
<textarea id="f-meditation" rows="5" placeholder="본문을 읽으며 마음에 닿은 것, 붙들게 된 말씀, 성도들에게 나누고 싶은 것"></textarea>
<button type="button" class="linkbtn" id="btn-seed-mode">묵상이 아직 없나요? 중심 메시지로 시작하기</button>
</div>
<div class="panel-in" id="central-panel" hidden>
<div class="actions"><button type="button" class="btn" id="btn-flow" data-ai>메시지 흐름 작성하기</button></div>
<div class="flow" id="flow" hidden>
<article class="ol-read flow-read" aria-labelledby="flow-h"><h3 class="ol-read-h" id="flow-h" tabindex="-1">메시지 흐름</h3><div id="flow-read"></div></article>
<div class="ol-ask" id="flow-ask">
<p class="ol-ask-q">이대로 좋으세요? 고치고 싶은 부분이 있으면 골라 주세요.</p>
<div class="part-choices" role="group" aria-label="고칠 부분"><button type="button" class="btn" data-flow-part="intro">도입</button><button type="button" class="btn" data-flow-part="body">전개</button><button type="button" class="btn" data-flow-part="conclusion">결론</button></div>
<div class="actions"><button type="button" class="btn primary" id="btn-flow-next">이대로 다음 단계로</button><button type="button" class="linkbtn" id="btn-flow-rewrite" data-ai>다시 작성하기</button></div>
</div>
</div>
</div>
<div class="actions main-actions">
<button type="button" class="btn primary" id="btn-start-next" hidden>다음 단계로</button>
<button type="button" class="btn primary" id="btn-directions" data-ai disabled>설교 방향 추천받기</button>
<button type="button" class="btn primary" id="btn-direction-manual" hidden>설교 방향 직접 쓰기</button>
<button type="button" class="btn" id="ai-stop" hidden>멈추기</button>
<button type="button" class="btn" id="btn-ai-perm" hidden>권한 열기</button>
</div>
<p class="note" id="gate-hint">본문을 먼저 정해 주세요.</p>
<p class="note" id="ai-status" role="status" aria-live="polite"></p>
<p class="note ai-off" id="ai-off" hidden>이 화면에서는 AI 추천을 쓸 수 없어요. 설교 방향부터 원고 초안까지 직접 쓰셔도 다음 단계로 넘어갈 수 있어요.</p>
</div>

<section class="style-card" id="style-card" hidden aria-labelledby="style-card-h">
<p class="style-card-h" id="style-card-h">${STYLE_NAME} 담기</p>
<p>지난 설교문 ${STYLE_MIN}~${STYLE_MAX}편을 올리시면 ${STYLE_NAME}을 익혀 두었다가 원고 초안을 쓸 때 따라요.</p>
<div class="actions"><a class="btn primary" href="#style" id="btn-style-now">지금 하기</a><button type="button" class="btn" id="btn-style-later">나중에</button><button type="button" class="linkbtn" id="btn-style-never">다시 보지 않기</button></div>
</section>
<a class="guide-card" id="guide-card" href="#guide"><strong>내 자료 연결하기</strong><span>가지고 계신 주석 PDF를 본문연구에 쓰려면 이렇게 준비해 주세요.</span></a>

<section class="step" id="step-direction" hidden aria-labelledby="dir-h">
<h2 id="dir-h" tabindex="-1">설교 방향</h2>
<p class="review-note" id="direction-review" hidden>${REVIEW_NOTE}</p>
<p class="note">하나를 고른 뒤 목사님 말로 고쳐 주세요. 고친 방향이 다음 단계로 넘어가요.</p>
<ul class="picks" id="dir-cards"></ul>
<div class="editor" id="dir-editor" hidden>
<p class="editor-head">고른 방향</p>
<label for="dir-title">제목 <span class="note-inline">원하는 제목으로 고쳐 주세요</span></label><input id="dir-title" maxlength="80">
<label for="dir-body">설명</label><textarea id="dir-body" rows="5" aria-describedby="dir-body-hint"></textarea>
<p class="note" id="dir-body-hint">더 담고 싶은 방향이나 요청이 있으면 설명 끝에 한두 문장으로 적어 주세요. 개요를 쓸 때 그대로 반영해요.</p>
<div class="actions"><button type="button" class="btn primary" id="btn-dir-next" disabled>다음 단계로</button></div>
</div>
<p class="dir-again"><button type="button" class="linkbtn" id="btn-dir-again" data-ai>다른 방향도 추천받기</button></p>
<div class="actions back-row"><button type="button" class="btn" data-back="passage">이전 단계</button>
</div>
</section>

<section class="step" id="step-outline" hidden aria-labelledby="ol-h">
<h2 id="ol-h" tabindex="-1">개요</h2>
<p class="review-note" id="outline-review" hidden>${REVIEW_NOTE}</p>
<p class="note">개요 작성하기를 누르면 한 문장 메시지와 네 부분(도입·전개·절정·결말)으로 된 개요 하나를 써서 먼저 읽기 좋게 보여 드려요.</p>
<div class="actions"><button type="button" class="btn primary" id="btn-outlines" data-ai>개요 작성하기</button></div>
<div class="ol-view" id="ol-view" hidden>
<p class="note" id="ol-migrated" hidden>예전 모양의 개요라서 대지를 '전개'의 세부 내용으로 옮겨 보여 드려요. 고쳐 쓰시면 새 모양으로 저장돼요.</p>
<article class="ol-read" aria-labelledby="ol-read-h"><h3 class="ol-read-h" id="ol-read-h" tabindex="-1">개요</h3><div id="ol-read"></div></article>
<div class="ol-ask" id="ol-ask">
<p class="ol-ask-q">이대로 좋으세요? 고치고 싶은 부분이 있으면 골라 주세요.</p>
<div class="part-choices" role="group" aria-label="고칠 부분"><button type="button" class="btn" data-edit-part="one">한 문장 메시지</button><button type="button" class="btn" data-edit-part="0">도입</button><button type="button" class="btn" data-edit-part="1">전개</button><button type="button" class="btn" data-edit-part="2">절정</button><button type="button" class="btn" data-edit-part="3">결말</button></div>
<p class="note warn" id="ol-problems" aria-live="polite"></p>
<div class="actions"><button type="button" class="btn primary" id="btn-ol-next">이대로 다음 단계로</button><button type="button" class="linkbtn" id="btn-ol-rewrite" data-ai>다시 작성하기</button></div>
</div>
</div>
<div class="actions back-row"><button type="button" class="btn" data-back="direction">이전 단계</button></div>
</section>

${WORK_KEYS.map((k) => (k === 'illustration' ? SETTING + '\n' : '') + workStep(k)).join('\n')}
<section class="step handoff" id="step-sources" hidden aria-labelledby="src-h">
<h2 id="src-h" tabindex="-1">출처 확인 <span class="chip">선택</span></h2>
<p class="src-done"><strong>원고 초안은 이미 다 됐어요.</strong> 이 단계는 하지 않아도 괜찮아요.</p>
<div class="src-gate" id="src-gate" hidden><p>이 설교의 원고는 도우미 안에 없어요. 출처 확인은 도우미에서 쓴 원고에만 각주를 달아요.</p><div class="actions"><button type="button" class="btn primary" id="btn-gate-ms">원고 초안 단계로 가기</button><span id="src-gate-page"></span></div></div>
<p class="note" id="src-probe" role="status" aria-live="polite">주석 도구를 찾는 중이에요…</p>
<div class="src-host" id="src-host" hidden>
<p>목사님 컴퓨터의 주석 도구가 연결돼 있어요. 출처 확인하기를 누르면 이 본문을 다루는 주석에서 원고의 문장을 뒷받침하는 쪽을 찾아 각주를 달아 드려요. 인용은 주석의 그 쪽에 그대로 있는 것만 남기고, 교리는 개혁주의 주석으로만 뒷받침해요. 목사님 원고의 문장은 바꾸지 않아요.</p>
<p class="note" id="src-host-warn" hidden>주석 도구 점검에서 확인할 것이 있어요. 그래도 출처 확인은 해 볼 수 있어요.</p>
<p class="note" id="src-ai-off" hidden>이 화면에서는 AI를 쓸 수 없어서 출처 확인을 할 수 없어요.</p>
<div class="actions"><button type="button" class="btn primary" id="btn-source-check" data-ai>출처 확인하기</button><button type="button" class="btn" id="btn-source-stop" hidden>멈추기</button><button type="button" class="btn" id="btn-src-perm" hidden>권한 열기</button></div>
<div class="src-progress" id="src-progress" hidden>
<div class="src-ring" id="src-ring" hidden><div class="ring" id="src-ring-bar" role="progressbar" aria-label="출처 확인 진행률" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="ring-track" cx="50" cy="50" r="44"/><circle class="ring-fill" id="src-ring-fill" cx="50" cy="50" r="44" pathLength="100"/></svg><span class="ring-num" id="src-ring-num" aria-hidden="true">0%</span></div><p class="ring-stage" id="src-ring-stage"></p><p class="ring-wait" id="src-ring-wait" hidden></p></div>
<ol class="src-steps" id="src-steps" aria-label="출처 확인 진행" hidden></ol>
</div>
<p class="note" id="src-summary" role="status" aria-live="polite"></p>
<div class="src-result" id="src-result" hidden>
<article class="ol-read" aria-labelledby="src-read-h"><h3 class="ol-read-h" id="src-read-h" tabindex="-1">각주를 단 원고</h3><div id="src-read"></div></article>
<div class="fn-list" role="region" aria-labelledby="src-fn-h"><h3 id="src-fn-h" tabindex="-1">각주</h3><ol id="src-fns"></ol></div>
<div class="claim-list" id="src-claims" hidden role="region" aria-labelledby="src-claims-h"><h3 id="src-claims-h">확인이 필요한 문장</h3><p class="note">원고에 사실처럼 적힌 문장인데 목사님 주석에서 뒷받침을 찾지 못했어요. 직접 확인하시거나 원고에서 고쳐 주세요. 이 화면은 원고를 바꾸지 않아요.</p><ol id="src-claim-items"></ol></div>
<p class="actions"><button type="button" class="linkbtn" id="btn-source-again" data-ai>다시 확인하기</button></p>
</div>
</div>
<div class="src-fallback" id="src-fallback" hidden>
<p><strong>이 기능은 주석 도구가 연결된 Claude 데스크톱 앱에서 열면 바로 돼요.</strong></p>
<p>지금 화면에서 하시려면, 주석 자료를 연결해 둔 컴퓨터에서 Claude Code를 열고 아래 문장을 그대로 말씀해 주세요. 원고에 쓴 사실과 성경 구절을 하나하나 확인해 각주를 달고, 원고만 담은 설교 페이지를 만들어 드려요. 목사님이 고친 문장은 바꾸지 않아요.</p>
<div class="say-row"><p class="say" id="handoff-sentence"></p><button type="button" class="btn" id="btn-copy-sentence">문장 복사</button></div>
<p class="note" id="copy-status" role="status" aria-live="polite"></p>
<p class="src-state"><strong id="handoff-title"></strong> <span class="chip" id="handoff-status"></span> <span id="src-work"></span></p>
<p class="note">가지고 계신 주석을 쓰려면 먼저 <a href="#guide">내 자료 연결하기</a>를 봐 주세요.</p>
</div>
<div class="actions final-go"><button type="button" class="btn" id="btn-final">설교 원고 보기</button></div>
<div class="actions back-row"><button type="button" class="btn" data-back="manuscript">이전 단계</button></div>
</section>

<section class="final" id="final-view" hidden aria-labelledby="final-h">
<p class="eyebrow final-tools">설교 원고</p>
<h1 id="final-h" tabindex="-1"></h1>
<div class="actions final-tools" id="final-act"><button type="button" class="btn primary" id="btn-finish">${FINISH_BUTTON}</button><button type="button" class="btn" id="btn-final-back">출처 확인으로</button></div>
<div class="actions final-tools" id="final-done" hidden><a class="btn" id="final-page" href="#" target="_blank" rel="noopener" hidden>게시한 설교 페이지 열기</a><button type="button" class="btn" id="btn-reopen">준비 단계 다시 열기</button></div>
<p class="final-passage"><a class="bref" id="final-ref" href="#" target="_blank" rel="noopener"></a></p>
<section class="final-msg" id="final-msg" aria-labelledby="final-msg-k"><p class="final-msg-k" id="final-msg-k">한 문장 메시지</p><p class="final-one" id="final-one"></p></section>
<div class="final-body" id="final-body"></div>
<aside class="final-fns" id="final-fns" hidden aria-labelledby="final-fns-h"><h2 id="final-fns-h">각주</h2><ol id="final-fn-list"></ol></aside>
<p class="note final-tools">인쇄하면 원고만 종이에 맞게 나와요.</p>
</section>
</section>

<section id="drafts-view" hidden aria-labelledby="drafts-h">
<div class="view-head"><h1 id="drafts-h">준비중인 설교</h1><button type="button" class="btn" id="btn-new">새 설교 시작</button></div>
<ul class="rows" id="drafts-list"></ul>
</section>

<section id="guide-view" class="guide" hidden aria-labelledby="guide-h">
<div class="view-head"><h1 id="guide-h">내 자료 연결하기</h1></div>
<p class="lead">가지고 계신 주석·설교집 PDF를 연결해 두면, 본문연구 단계에서 그 본문에 맞는 책을 골라 쪽 번호와 함께 인용해요.</p>
<section aria-labelledby="g-what"><h2 id="g-what">쓸 수 있는 자료</h2>
<ul>
<li><strong>글자가 들어 있는 PDF</strong>가 가장 잘 돼요.</li>
<li><strong>스캔한 PDF</strong>(사진처럼 찍힌 쪽)도 글자 인식으로 읽을 수 있지만, 더 오래 걸리고 글자가 틀리게 읽힐 수 있어요.</li>
<li><strong>한글(HWP) 파일</strong>은 아직 읽지 못해요.</li>
</ul></section>
<section aria-labelledby="g-organise"><h2 id="g-organise">정리하는 법</h2>
<ul>
<li>주석을 <strong>폴더 하나</strong>에 모아 주세요. 그 안에 시리즈별 하위 폴더가 있어도 괜찮아요.</li>
<li>파일 이름에 <strong>성경 책 이름, 저자, 시리즈</strong>가 들어 있으면 잘 찾아요. 한 권이 책의 일부만 다루면 <strong>장 범위</strong>도 넣어 주세요.</li>
</ul>
<p class="eg-h">이름 예</p>
<ul class="eg">
<li><code>칼빈주석/칼빈주석 요한복음 1.pdf</code></li>
<li><code>핸드릭슨 주석/핸드릭슨주석-요한복음(하).pdf</code></li>
<li><code>카리스주석/카리스주석 신약 11 요한복음15-21장.pdf</code></li>
<li><code>NICNT/NICNT. 04 John - Leon Morris.pdf</code></li>
</ul></section>
<section aria-labelledby="g-connect"><h2 id="g-connect">연결하는 법</h2>
<ol>
<li>컴퓨터에서 Claude Code를 열어 주세요.</li>
<li>이렇게 말씀해 주세요: <span class="say-inline">내 주석 폴더는 &lt;폴더 경로&gt;야. 연결해 줘</span></li>
<li>폴더 안의 파일 수, PDF 수, 성경 책을 알아본 책 수를 알려 드려요. 폴더는 여러 개 연결할 수 있어요.</li>
</ol>
<p class="note" id="guide-host-state" hidden></p>
<div class="guide-libs" id="guide-libraries" hidden></div>
<p>구글 드라이브·iCloud·OneDrive 같은 클라우드 폴더도 괜찮아요. 목록은 파일 이름만 보고 만들고, 실제로 쓰는 책만 그때 내려받아져요.</p></section>
<section aria-labelledby="g-use"><h2 id="g-use">어떻게 쓰이나요</h2>
<ul>
<li>본문연구 단계에서 그 본문에 맞는 주석을 <strong>1~3권</strong> 골라요. 개혁주의 저자의 책을 먼저 골라요.</li>
<li>인용할 때는 <strong>저자, 책 이름, 쪽</strong>을 밝혀요.</li>
<li>주석의 글 자체는 설교 페이지에 싣거나 게시하지 않아요.</li>
</ul></section>
<section aria-labelledby="g-authors"><h2 id="g-authors">저자 분류</h2>
<ul>
<li>아직 분류되지 않은 저자의 책은 <strong>'비개혁주의 자료'</strong>로 표시하고 사실·원어·배경에만 써요.</li>
<li>개혁주의 저자라면 이렇게 말씀해 주세요: <span class="say-inline">&lt;저자&gt;는 개혁주의 저자로 등록해 줘</span> — 근거를 확인한 뒤에 등록해요.</li>
</ul></section>
<section aria-labelledby="g-app"><h2 id="g-app">설교준비 도우미에서 바로 출처 확인하기</h2>
<p>주석 도구를 Claude 데스크톱 앱에 한 번 등록해 두면, 이 페이지를 데스크톱 앱에서 열었을 때 출처 확인 단계에서 바로 각주를 달 수 있어요. Claude Code에 <span class="say-inline">주석 도구 등록 방법 알려 줘</span>라고 말씀하시면 넣을 내용을 알려 드려요. 등록한 뒤에는 앱을 완전히 닫았다가 다시 열어 주세요.</p></section>
<section aria-labelledby="g-search"><h2 id="g-search">웹 검색 키 (네이버)</h2>
<p>출처 확인의 '웹에서 찾기'와 예화의 '시사 예화 찾기'는 목사님 컴퓨터에서 네이버 검색을 써요. 네이버 클라우드 플랫폼의 NAVER API HUB에서 검색 API를 신청해 받은 Client ID와 Client Secret을 skills 폴더가 들어 있는 폴더의 .env.local 파일(설치하면 보통 macOS는 ~/.claude/.env.local, Windows는 <span class="path"><span>C:\\Users\\</span><wbr><span>&lt;사용자이름&gt;\\</span><wbr><span>.claude\\.env.local</span></span>, 자세한 순서는 설치 안내서 3-4)에 넣고, Claude 앱을 완전히 닫았다가 다시 열어 주세요. 키는 목사님 컴퓨터에만 있고 이 페이지로 보내지 않아요.</p>
<p class="note" id="guide-keys-file" hidden></p></section>
<section aria-labelledby="g-privacy"><h2 id="g-privacy">개인 정보</h2>
<p>연결한 폴더와 책에서 뽑은 글은 목사님 컴퓨터에만 남아요. 이 페이지나 다른 사람에게 보내지 않아요.</p></section>
<section aria-labelledby="g-platform"><h2 id="g-platform">지금 되는 환경</h2>
<p id="guide-platform">macOS와 Windows 11에서 설치·주석 도구 연결·서재 주석 읽기·스캔한 PDF 글자 인식·온라인 주석 읽기까지 확인을 마쳤어요. 먼저 Claude Code에 '주석 도구 점검해 줘'라고 말씀해 주시면 그 컴퓨터에서 되는지 바로 알려 드려요.</p></section>
<div class="actions"><a class="btn" href="#start">새 설교 시작으로</a></div>
</section>

<section id="style-view" class="style-view" hidden aria-labelledby="style-h">
<div class="view-head"><h1 id="style-h" tabindex="-1">${STYLE_NAME}</h1></div>
<p class="lead">지난 설교문 ${STYLE_MIN}~${STYLE_MAX}편을 올리시면 ${STYLE_NAME}을 익혀 두었다가 원고 초안을 쓸 때 따라요.</p>
<p class="note" id="style-login" hidden>로그인하면 ${STYLE_NAME}을 저장해 두고 쓸 수 있어요.</p>
<div class="style-input" id="style-input">
<p class="style-promise"><strong>올린 설교문은 저장하지 않고 스타일만 익혀 둬요.</strong></p>
<label for="style-paste">설교문 붙여 넣기</label>
<textarea id="style-paste" rows="6" placeholder="설교문 한 편을 그대로 붙여 넣어 주세요."></textarea>
<div class="actions"><button type="button" class="btn" id="btn-style-add">목록에 넣기</button><input type="file" id="style-file" class="sr" accept=".txt,.md,.docx,.pdf,.hwp,.hwpx,text/plain,text/markdown,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/pdf,application/x-hwp,application/haansofthwp,application/hwp+zip" multiple><label class="btn file-btn" for="style-file">파일 고르기</label></div>
<p class="note">.txt, .md, .docx, .pdf, .hwp, .hwpx 파일을 읽어요. 파일은 이 화면 안에서 글자로 바꿔요. 그 글은 스타일을 익힐 때 한 번 Claude에게 보내고(한 편에 ${STYLE_CHARS.toLocaleString('en-US')}자까지), 남기는 것은 익힌 스타일(대표 문장 5개까지)과 파일 이름·편수·글자 수뿐이에요.</p>
<ul class="style-files" id="style-files" aria-label="올린 설교문"></ul>
<div class="actions"><button type="button" class="btn primary" id="btn-style-run" data-ai disabled>내 스타일 익히기</button><button type="button" class="btn" id="btn-style-stop" hidden>멈추기</button><button type="button" class="linkbtn" id="btn-style-cancel" hidden>그만두기</button></div>
<p class="note" id="style-status" role="status" aria-live="polite"></p>
<div class="src-progress" id="style-progress" hidden>
<div class="src-ring" id="style-ring"><div class="ring" id="style-ring-bar" role="progressbar" aria-label="스타일 익히기 진행률" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><svg viewBox="0 0 100 100" aria-hidden="true"><circle class="ring-track" cx="50" cy="50" r="44"/><circle class="ring-fill" id="style-ring-fill" cx="50" cy="50" r="44" pathLength="100"/></svg><span class="ring-num" id="style-ring-num" aria-hidden="true">0%</span></div><p class="ring-stage" id="style-ring-stage" aria-live="polite"></p><p class="ring-wait" id="style-ring-wait"></p></div>
</div>
</div>
<div class="style-profile" id="style-profile" hidden>
<p class="note" id="style-from"></p>
<label class="style-toggle"><input type="checkbox" id="style-on"> 원고에 반영</label>
<div id="style-fields"></div>
<p class="note" id="style-saved" role="status" aria-live="polite"></p>
<div class="actions"><button type="button" class="btn" id="btn-style-again">다시 분석하기</button></div>
</div>
</section>

<section id="past-view" hidden aria-labelledby="past-h">
<div class="view-head"><h1 id="past-h">지난 설교 목록</h1><p class="note" id="past-count"></p></div>
<div class="filters" id="past-filters"></div>
<ul class="rows" id="past-list"></ul>
<details class="crit-box">
<summary>분류 기준 고치기</summary>
<p class="note">기준 이름과 값을 목사님 교회에 맞게 바꿀 수 있어요. 값 이름을 바꾸면 그 값을 쓰던 설교도 함께 바뀌어요.</p>
<ul class="crits" id="crit-list"></ul>
</details>
</section>
</main>
<footer class="site-foot"><p>${COPYRIGHT}</p></footer>
<dialog class="redo" id="redo" aria-labelledby="redo-h" aria-describedby="redo-desc">
<h2 id="redo-h"></h2>
<p id="redo-desc"></p>
<p class="redo-k">다시 하게 될 단계</p>
<ul class="list" id="redo-list"></ul>
<p>지금까지의 작업은 어떻게 할까요?</p>
<div class="redo-actions">
<button type="button" class="btn primary" data-redo="keep">이전 작업 남겨 두기</button>
<button type="button" class="btn" data-redo="clear">이전 작업 지우기</button>
<button type="button" class="btn" data-redo="cancel">취소</button>
</div>
<p class="note">남겨 두면 지금까지의 작업 전체가 '준비중인 설교'에 따로 저장돼요. 지우면 위 단계만 비워지고, 취소하면 바꾸기 전으로 돌아가요.</p>
</dialog>
<dialog class="redo confirm" id="confirm" aria-labelledby="confirm-h" aria-describedby="confirm-desc">
<h2 id="confirm-h"></h2>
<p id="confirm-desc"></p>
<div class="redo-actions"><button type="button" class="btn primary" data-confirm="ok"></button><button type="button" class="btn" data-confirm="cancel"></button></div>
</dialog>
</div>
</div>
<script type="application/json" id="bible-data">${jsonForScript({ books })}</script>
<script>
${core}
${docs}
${read('..', 'template', 'start.js')}</script>
`;
}
/** @deprecated name kept for older notes: the hub URL now serves the start page */
export const renderHub = renderStart;

const isMain = (() => {
  try { return !!process.argv[1] && realpathSync(process.argv[1]) === realpathSync(fileURLToPath(import.meta.url)); } catch { return false; }
})();
if (isMain) {
  const out = process.argv[2] ?? 'sermons/hub.html';
  const html = renderStart();
  writeFileSync(out, html);
  console.log(JSON.stringify({ wrote: out, bytes: Buffer.byteLength(html) }, null, 2));
}
